"""Replay named member selection on ordinary small files from a pinned project checkout."""
import argparse, csv, hashlib, os, random, shutil, statistics, subprocess, tempfile, time
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('source',type=Path)
parser.add_argument('main',type=Path)
parser.add_argument('change',type=Path)
parser.add_argument('receipt',type=Path)
parser.add_argument('--reps',type=int,default=7)
parser.add_argument('--prepare', action='store_true')
parser.add_argument('--control',action='store_true',help='insert a second execution of the same main executable in each round')
parser.add_argument('--workers',nargs='+',type=int,default=[1,4])
parser.add_argument('--label',default='')
parser.add_argument('--seed',type=int,default=1253164)
parser.add_argument('--counts',nargs='+',type=int,default=[1,16,128,512])
args=parser.parse_args(); E={k:v for k,v in os.environ.items() if not k.startswith('KOLMO_')}
B={'main':str(args.main.resolve()),'change':str(args.change.resolve())}
if args.control: B['main-AA']=B['main']
root=args.receipt.resolve()
root.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
def source_paths(src):
    skip={'build','.git','__pycache__'}
    return sorted(p for p in src.rglob('*') if p.is_file() and not p.is_symlink()
        and not skip.intersection(p.relative_to(src).parts) and 0<p.stat().st_size<=2048
        and p.suffix not in {'.kol','.gz','.png','.jpg','.zip'})
paths=source_paths(args.source)[:2048]
assert len(paths)==2048
datasets={}
for copies in (1,4):
    group=root/f'set-{copies}'; group.mkdir(exist_ok=True)
    wanted={}
    for c in range(copies):
        for p in paths:
            r=Path('versions')/f'v{c}'/p.relative_to(args.source)
            to=group/r
            if not to.exists():
                to.parent.mkdir(parents=True,exist_ok=True);to.write_bytes(p.read_bytes());to.chmod(0o644);os.utime(to,(1600000000,1600000000))
            wanted[str(r)]=sha(p.read_bytes())
    archive=root/f'set-{copies}.kol'
    if not archive.exists(): subprocess.run([B['main'],'archive','-1','-T','1',str(archive),'versions'],cwd=group,check=True)
    datasets[copies]=(wanted,archive)
if args.prepare: raise SystemExit(0)
cells=[(c,t,k) for c in datasets for t in args.workers for k in args.counts]
rng=random.Random(args.seed); rows=[]
for rep in range(-1,args.reps):
    rng.shuffle(cells)
    for copies,threads,k in cells:
        want,arc=datasets[copies];names=random.Random(9173+copies+k).sample(sorted(want),k)
        order=list(B); rng.shuffle(order)
        for arm in order:
            with tempfile.TemporaryDirectory(dir=root) as temp:
                argv=[B[arm],'extract','-T',str(threads),'-C',temp,str(arc),*names]
                tm=time.monotonic_ns(); pid=os.posix_spawn(argv[0],argv,E); _,status,u=os.wait4(pid,0);ms=(time.monotonic_ns()-tm)/1e6
                if status: raise RuntimeError((arm,rep,copies,k,status))
                actual={str(p.relative_to(temp)):sha(p.read_bytes()) for p in Path(temp).rglob('*') if p.is_file()}
                assert actual=={s:want[s] for s in names}
            row=dict(rep=rep,worker=threads,archive_members=len(want),archive_bytes=arc.stat().st_size,requested=k,arm=arm,order=order.index(arm),
                     wall_ms=ms,cpu_ms=1000*(u.ru_utime+u.ru_stime),rss=u.ru_maxrss,outputs=len(actual))
            with (root/(args.label+'raw.csv')).open('a' if rows else 'w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=row)
                if not rows:w.writeheader()
                w.writerow(row)
            rows.append(row)
    print('finished',rep,flush=True)
with (root/(args.label+'summary.csv')).open('w',newline='') as f:
    s=csv.writer(f);s.writerow(['members','threads','requested','baseline','candidate','pairs','main_ms','change_ms','paired_speedup','wins','paired_cpu_speedup'])
    for copies,t,k in sorted(cells):
        groups={a:sorted((r for r in rows if r['archive_members']==copies*2048 and r['worker']==t and r['requested']==k and r['arm']==a and r['rep']>=0),key=lambda r:r['rep']) for a in B}
        comparisons=[('main','change')]+([('main-AA','change'),('main','main-AA')] if args.control else [])
        for before,after in comparisons:
            old,cur=groups[before],groups[after]
            ratio=[a['wall_ms']/b['wall_ms'] for a,b in zip(old,cur)]
            s.writerow((copies*2048,t,k,before,after,len(ratio),statistics.median(r['wall_ms'] for r in old),statistics.median(r['wall_ms'] for r in cur),statistics.median(ratio),sum(x>1 for x in ratio),statistics.median(a['cpu_ms']/b['cpu_ms'] for a,b in zip(old,cur))))
