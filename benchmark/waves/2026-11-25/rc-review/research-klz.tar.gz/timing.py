"""Randomized within-pair A/B on the same executable, real KLZ-1 encode+stock decode."""
import collections,csv,hashlib,io,random,subprocess,statistics,sys
from pathlib import Path
here=Path(__file__).parent
tree=Path(sys.argv[2])
data=Path(sys.argv[1])
subprocess.run([sys.executable,str(here/'prototype.py'),str(tree)],check=True)
subprocess.run(['cc','-O3','-mcpu=native','-ffp-contract=off','-I'+str(tree/'src/algo'),
                str(here/'pairs.c'),str(here/'prototype.o'),str(tree/'build/libkolmo.a'),
                '-Wl,-dead_strip','-o',str(here/'pairs')],check=True)
names=['corpus/dickens','corpus-holdout/ld30.txt','corpus-holdout/owid-co2-data.csv',
       'corpus-holdout/llm_bf16_47mb.safetensors','corpus-holdout/mozilla','corpus-holdout/reymont']
cases=[(name,n,t) for name in names for n in [65536,262144] for t in [1,4]]
random.Random(61).shuffle(cases)
cols=['pair','order','candidate','total_compressed','iterations','encode_ns','decode_ns']
context=['name','n','lanes','hashes']
with (here/'timing-raw.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=context+cols); writer.writeheader()
    for name,n,lanes in cases:
        p=data/name
        hashes=[]
        with p.open('rb') as src:
            for i in range(lanes):
                src.seek((i*n)%(p.stat().st_size-n+1)); hashes.append(hashlib.sha256(src.read(n)).hexdigest())
        out=subprocess.run([str(here/'pairs'),str(p),str(n),str(lanes),'9'],
                           check=True,capture_output=True,text=True)
        for r in csv.DictReader(io.StringIO(out.stdout),fieldnames=cols):
            writer.writerow(dict(name=name,n=n,lanes=lanes,hashes='|'.join(hashes),**r))
        f.flush()
grouped=collections.defaultdict(lambda: collections.defaultdict(dict))
for r in csv.DictReader((here/'timing-raw.csv').open()):
    grouped[tuple(r[k] for k in context[:-1])][int(r['pair'])][int(r['candidate'])]=r
def phase(r,which):
    if which=='total': return int(r['encode_ns'])+int(r['decode_ns'])
    return int(r[which+'_ns'])
with (here/'timing-summary.csv').open('w',newline='') as out:
    w=csv.writer(out);w.writerow(context[:-1]+['base_bytes','candidate_bytes','size_delta_pct','encode_time_delta_pct','decode_time_delta_pct','total_time_delta_pct','product_gain_pct','product_wins','total_wins'])
    median=statistics.median
    for key,pairs in sorted(grouped.items()):
        a,b=pairs[0][0],pairs[0][1]
        fa,fb=map(int,[a['total_compressed'],b['total_compressed']])
        delta=[]
        for phase_name in ['encode','decode','total']:
            ratio=[phase(ab[1],phase_name)/phase(ab[0],phase_name) for ab in pairs.values()]
            delta.append(100*(median(ratio)-1))
        product=[(fa/fb)*(phase(ab[0],'total')/phase(ab[1],'total')) for ab in pairs.values()]
        w.writerow([*key,fa,fb,100*(fb/fa-1),*delta,(median(product)-1)*100,sum(p>1 for p in product),sum(r<1 for r in ratio)])
