#define _POSIX_C_SOURCE 200809L
#include "klz.h"
#include <assert.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
size_t probe_kolmo_klz_compress(const uint8_t*,size_t,uint8_t*,size_t,int);
typedef struct { uint8_t *src,*coded,*decoded; size_t n,cn,cap; unsigned count; int decode,candidate,ok; } Job;
static uint64_t now(void) {
    struct timespec t; clock_gettime(CLOCK_MONOTONIC,&t);
    return (uint64_t)t.tv_sec*1000000000+t.tv_nsec;
}
static void *run(void *arg) {
    Job *j=arg;
    for (unsigned k=0;k<j->count;k++) {
        if (j->decode) {
            if (kolmo_klz_decompress(j->coded,j->cn,j->decoded,j->n)) j->ok=0;
        } else {
            j->cn=(j->candidate ? probe_kolmo_klz_compress : kolmo_klz_compress)(j->src,j->n,j->coded,j->cap,1);
            if (!j->cn) j->ok=0;
        }
    }
    return NULL;
}
static uint64_t stage(Job *jobs,int threads,int cand,int decode) {
    pthread_t ids[4]; uint64_t start=now();
    for (int i=0;i<threads;i++) {
        jobs[i].decode=decode; jobs[i].candidate=cand;
        if (threads==1) run(&jobs[i]); else assert(!pthread_create(&ids[i],NULL,run,&jobs[i]));
    }
    if (threads>1) for (int i=0;i<threads;i++) assert(!pthread_join(ids[i],NULL));
    return now()-start;
}
int main(int argc,char **argv) {
    assert(argc==5); int threads=atoi(argv[3]); assert(threads==1 || threads==4);
    size_t n=strtoul(argv[2],NULL,10); unsigned pairs=atoi(argv[4]);
    Job jobs[4]={0}; FILE *f=fopen(argv[1],"rb"); assert(f);
    assert(!fseek(f,0,SEEK_END)); size_t filelen=(size_t)ftell(f); assert(filelen>=n);
    size_t base_cn[4]={0};
    for (int i=0;i<threads;i++) {
        Job *j=&jobs[i]; j->ok=1; j->n=n; j->cap=kolmo_klz_bound(n)+64;
        j->src=malloc(n); j->coded=malloc(j->cap); j->decoded=malloc(n);
        assert(j->src && j->coded && j->decoded);
        size_t at=(i*n)%(filelen-n+1); assert(!fseek(f,(long)at,SEEK_SET));
        assert(fread(j->src,1,n,f)==n); j->count=(unsigned)((1u<<20)/n); if (!j->count) j->count=1;
    }
    fclose(f);
    unsigned rng=27419823;
    for (int rep=-1;rep<(int)pairs;rep++) {
        rng=rng*1664525u+1013904223u; int swap=rep<0?0:(rng>>16)&1;
        for (int k=0;k<2;k++) {
            int arm=k^swap;
            uint64_t et=stage(jobs,threads,arm,0), dt=stage(jobs,threads,arm,1);
            size_t total=0;
            for (int i=0;i<threads;i++) {
                Job *j=&jobs[i]; assert(j->ok && !memcmp(j->src,j->decoded,n));
                if (rep<0 && !arm) base_cn[i]=j->cn;
                assert(j->cn<=base_cn[i]);
                total+=j->cn;
            }
            if (rep>=0) printf("%d,%d,%d,%zu,%u,%"PRIu64",%"PRIu64"\n",rep,k,arm,total,jobs[0].count,et,dt);
        }
    }
}
