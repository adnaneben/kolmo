#include "klz.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
size_t probe_kolmo_klz_compress(const uint8_t*,size_t,uint8_t*,size_t,int);
int main(void) {
    uint8_t src[2048]={0}, coded[4096], decoded[2048], base[4096];
    size_t cases=0; uint32_t seq=43521;
    for(size_t n=0; n<=1024; n = n<19 ? n+1 : n<255 ? n+17 : n<769 ? n+1 : n+63) {
        for(unsigned style=0;style<7;style++) {
            for(size_t i=0;i<n;i++) {
                seq=1664525*seq+1013904223;
                src[i]=style==0?0:style==1?(uint8_t)i:style==2?(uint8_t)(i%7):
                       style==3?(uint8_t)(seq>>30):style==4?(uint8_t)(seq>>24):
                       style==5?(uint8_t)(i<255?i:i%255):(uint8_t)(i/19);
            }
            size_t cap=kolmo_klz_bound(n);
            size_t old=kolmo_klz_compress(src,n,base,cap,1);
            size_t len=probe_kolmo_klz_compress(src,n,coded,cap,1);
            assert(old && len && len<=old && !kolmo_klz_decompress(coded,len,decoded,n));
            assert(!memcmp(src,decoded,n)); cases++;
        }
    }
    printf("%zu exact bounded cases\n",cases);
}
