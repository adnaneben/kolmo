"""Build an isolated, encoder-only single-pass experiment from the current KLZ-1 source."""
from pathlib import Path
import re, subprocess,sys
here=Path(__file__).resolve().parent
tree=Path(sys.argv[1])
original=(tree/'src/algo/klz.c').read_text()
new=original
begin=new.index('static size_t kz_klz1(')
new=new[:begin]+'''
/* One four-byte candidate per bucket; search only already-priced literal runs. The
 * primary parser and its rep state are left alone, so an accepted repair never
 * lengthens the raw payload and introduces no decoder state. */
static size_t repair_extensions(size_t n, size_t t) {
    return n < t ? 0 : 1 + (n - t)/255;
}
static uint8_t *repair_emit(uint8_t *out, const uint8_t *input, size_t start,
                            size_t literals, size_t offset, size_t match, uint32_t *table) {
    const size_t end = start + literals;
    size_t best=0, best_at=0, best_len=0, best_dist=0;
    if (table && literals >= 4) for (size_t at=start; at+4<=end; at++) {
        uint32_t h=kz_h4(input+at,14), slot=table[h];
        table[h]=(uint32_t)at+1;
        if (!slot) continue;
        size_t prev=slot-1, dist=at-prev;
        if (dist>KLZ_WINDOW || kz_r32(input+at)!=kz_r32(input+prev)) continue;
        size_t limit=end-at; if (limit>64) limit=64;
        size_t len=4;
        while (len<limit && input[at+len]==input[prev+len]) len++;
        size_t gross=len+repair_extensions(literals,7);
        size_t cost=3+(dist>65535)+repair_extensions(len-4,15)
                    +repair_extensions(at-start,7)+repair_extensions(end-at-len,7);
        if (gross>cost && gross-cost>best) {
            best=gross-cost; best_at=at; best_len=len; best_dist=dist;
        }
    }
    if (best) {
        out=kz_emit(out,input+start,best_at-start,best_dist,best_len);
        start=best_at+best_len;
    }
    if (table && match>=4) table[kz_h4(input+end,14)]=(uint32_t)end+1;
    return kz_emit(out,input+start,end-start,offset,match);
}
'''+new[begin:]
begin=new.index('static size_t kz_klz1(')
end=new.index('size_t kolmo_klz_compress(',begin)
body=new[begin:end]
body=body.replace('const uint8_t *ie =','uint32_t *repair = calloc(1u<<14, sizeof *repair);\n    const uint8_t *ie =')
body=body.replace('free(ht);','free(repair); free(ht);')
body=body.replace('kz_emit(op, in + anchor, start - anchor, off, ml)', 'repair_emit(op, in, anchor, start - anchor, off, ml, repair)')
body=body.replace('kz_emit(op, in + anchor, n - anchor, 0, 0)', 'repair_emit(op, in, anchor, n - anchor, 0, 0, repair)')
assert body.count('repair_emit(')==2
new=new[:begin]+body+new[end:]
(here/'klz-prototype.c').write_text(new)
import difflib
(here/'frozen-literal-run.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile='a/src/algo/klz.c',tofile='b/src/algo/klz.c')))
names=set(re.findall(r'^(?:size_t|int) (kolmo_[a-z0-9_]+)\(',new,re.M))
subprocess.run(['cc','-O3','-mcpu=native','-ffp-contract=off','-ffunction-sections','-fdata-sections','-std=c11', '-I'+str(tree/'src/algo'),*['-D'+s+'=probe_'+s for s in sorted(names)],
                '-c',str(here/'klz-prototype.c'),'-o',str(here/'prototype.o')],check=True)
