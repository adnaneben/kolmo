#!/usr/bin/env python3
"""Usage: python3 run.py /path/to/review-data /path/to/kolmo/source
Low-priority, bounded raw-codec wire measurement. Raw input bytes stay local."""
import csv
import hashlib
import io
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
data, source = map(Path, sys.argv[1:])
subprocess.run(["cc", "-O2", "-std=c11", "-Wall", "-Wextra", "-Werror",
                "-I" + str(source / "src/algo"), str(root / "reparse.c"),
                str(source / "build/libkolmo.a"), "-o", str(root / "reparse")], check=True)
files = {'dev': ['dickens', 'api.json', 'esc50-1-100032-A-0.wav', 'ooffice', 'x-ray',
                 'magika.onnx', 'SRR835775.fastq', 'loghub_all.log'],
         'transfer': ['reymont', 'ld30.txt', 'mozilla', 'osdb', 'llm_bf16_47mb.safetensors',
                      'owid-co2-data.csv', 'foreman_cif.y4m', 'SRR2584863.fastq']}
columns = ['arm','old_bytes','new_bytes','matches','literal_bytes','wide','narrowed',
           'added_matches','probes','recovered_literal_bytes','split_saved_bytes','input_bytes']
with (root / 'raw.csv').open('w',newline='') as sink:
    writer = csv.DictWriter(sink, fieldnames=['group','name','offset','sha256'] + columns)
    writer.writeheader()
    for group, names in files.items():
        folder = 'corpus' if group=='dev' else 'corpus-holdout'
        for name in names:
            path = data / folder / name
            size = path.stat().st_size
            for offset,n in [(0,64<<10),(0,256<<10),(1<<20,256<<10),(2<<20,1<<20)]:
                if size-offset<n:
                    continue
                with path.open('rb') as f:
                    f.seek(offset)
                    sha = hashlib.sha256(f.read(n)).hexdigest()
                result = subprocess.run([str(root/'reparse'),str(path),str(n),str(offset)],
                                        capture_output=True,text=True,check=True)
                for r in csv.DictReader(io.StringIO(result.stdout),fieldnames=columns):
                    writer.writerow(dict(group=group,name=name,offset=offset,sha256=sha,**r))
