/* Research diagnostic for KLZ-1. Call only on bytes emitted by the linked stock encoder.
   All candidate streams must also pass that encoder's unmodified decoder and memcmp. */
#include "klz.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct { size_t matches, literals, wide, narrow, extra, probes, matched_bytes, pure_gain; } Stats;
static size_t extension(size_t length, size_t threshold) {
    return length < threshold ? 0 : 1 + (length - threshold) / 255;
}
static void put_extension(uint8_t **p, size_t length, size_t threshold) {
    if (length < threshold) return;
    size_t left = length - threshold;
    while (left >= 255) { *(*p)++ = 255; left -= 255; }
    *(*p)++ = (uint8_t)left;
}
static size_t read_extension(const uint8_t **p) {
    size_t total = 0; uint8_t x;
    do { x = *(*p)++; total += x; } while (x == 255);
    return total;
}
static void emit(uint8_t **p, const uint8_t *src, size_t ll, size_t distance, size_t ml) {
    unsigned lit = ll < 7 ? (unsigned)ll : 7;
    unsigned match = ml ? (ml < 19 ? (unsigned)ml-4 : 15) : 0;
    *(*p)++ = (uint8_t)(lit | match << 3 | (distance > 65535 ? 128 : 0));
    put_extension(p,ll,7);
    memcpy(*p,src,ll); *p += ll;
    if (!ml) return;
    *(*p)++ = (uint8_t)distance; *(*p)++ = (uint8_t)(distance >> 8);
    if (distance > 65535) *(*p)++ = (uint8_t)(distance >> 16);
    put_extension(p,ml-4,15);
}
static unsigned hash4(const uint8_t *src) {
    uint32_t v; memcpy(&v,src,4); return (v * 2654435761u) >> 16;
}
static void index_span(uint32_t *table, const uint8_t *src, size_t begin, size_t end, size_t n, size_t stride) {
    size_t p = begin + (stride - begin % stride) % stride;
    for (; p < end && p+4 <= n; p += stride) table[hash4(src+p)] = (uint32_t)p;
}
static size_t rewrite(const uint8_t *src,size_t n,const uint8_t *wire,size_t cn,uint8_t *out,
                      size_t min_literal,size_t min_gain,size_t stride,int narrow,int split,Stats *s) {
    uint32_t table[65536]; memset(table,0xff,sizeof table);
    const uint8_t *ip=wire; uint8_t *op=out; size_t p=0;
    while (ip < wire+cn) {
        unsigned token=*ip++; size_t ll=token&7u, ml=0, distance=0;
        if (ll==7) ll+=read_extension(&ip);
        assert(p+ll<=n && !memcmp(ip,src+p,ll)); ip+=ll;
        size_t end=p+ll;
        if (end<n) {
            size_t width=2+(token>>7); distance=ip[0]|(size_t)ip[1]<<8;
            if (width==3) distance|=(size_t)ip[2]<<16;
            ip+=width; ml=4+((token>>3)&15);
            if (ml==19) ml+=read_extension(&ip);
            assert(distance && distance<=end && ml<=n-end);
            s->matches++; s->wide+=width==3;
        }
        s->literals+=ll;
        size_t win_gain=0, win_start=0, win_ml=0, win_d=0;
        if (split && ll>=min_literal) {
            for (size_t at=p;at<end && at+4<=n;at++) {
                unsigned h=hash4(src+at); size_t prev=table[h];
                if (prev<at && at-prev<=KLZ_WINDOW && at+4<=end) {
                    size_t len=0; s->probes++;
                    if (!memcmp(src+at,src+prev,4)) {
                        len=4;
                        /* Bounded comparison work and a reproducible research choice. */
                        while (len<64 && len<end-at && src[at+len]==src[prev+len]) len++;
                        size_t overhead=1+2+(at-prev>65535)+extension(len-4,15)
                            +extension(at-p,7)+extension(end-at-len,7);
                        size_t gross=len+extension(ll,7);
                        if (gross>overhead && gross-overhead>win_gain && gross-overhead>=min_gain) {
                            win_gain=gross-overhead; win_start=at; win_ml=len; win_d=at-prev;
                        }
                    }
                }
                if (at%stride==0) table[h]=(uint32_t)at;
            }
        } else index_span(table,src,p,end,n,stride);
        if (win_gain) {
            emit(&op,src+p,win_start-p,win_d,win_ml); s->extra++;
            p=win_start+win_ml; s->matched_bytes+=win_ml; s->pure_gain+=win_gain;
        }
        if (narrow && distance>65535 && ml<=64) {
            size_t prev=table[hash4(src+end)]; s->probes++;
            if (prev<end && end-prev<=65535 && !memcmp(src+prev,src+end,ml)) {
                distance=end-prev; s->narrow++;
            }
        }
        emit(&op,src+p,end-p,distance,ml);
        index_span(table,src,end,end+ml,n,stride);
        p=end+ml;
    }
    assert(p==n && (size_t)(op-out)+s->pure_gain+s->narrow==cn);
    return (size_t)(op-out);
}
int main(int argc,char **argv) {
    if (argc!=4) return 1;
    size_t n=strtoul(argv[2],NULL,10), offset=strtoul(argv[3],NULL,10), cap=kolmo_klz_bound(n)+64;
    FILE *f=fopen(argv[1],"rb"); assert(f && !fseek(f,(long)offset,SEEK_SET));
    uint8_t *src=malloc(n),*baseline=malloc(cap),*candidate=malloc(cap),*decoded=malloc(n);
    assert(src && baseline && candidate && decoded && fread(src,1,n,f)==n); fclose(f);
    size_t cn=kolmo_klz_compress(src,n,baseline,cap,1); assert(cn);
    assert(!kolmo_klz_decompress(baseline,cn,decoded,n) && !memcmp(src,decoded,n));
    const struct { const char *name; int lit,gain,stride,narrow,split; } modes[]={
        {"identity",0,0,1,0,0}, {"near",0,0,1,1,0}, {"split",4,1,1,0,1},
        {"split32",32,3,4,0,1}, {"combined",4,1,1,1,1}};
    for (size_t i=0;i<sizeof modes/sizeof modes[0];i++) {
        Stats s={0};
        size_t z=rewrite(src,n,baseline,cn,candidate,modes[i].lit,modes[i].gain,modes[i].stride,
                         modes[i].narrow,modes[i].split,&s);
        assert(!kolmo_klz_decompress(candidate,z,decoded,n) && !memcmp(src,decoded,n));
        if (i==0) assert(cn==z && !memcmp(candidate,baseline,z));
        printf("%s,%zu,%zu,%zu,%zu,%zu,%zu,%zu,%zu,%zu,%zu,%zu\n",
               modes[i].name,cn,z,s.matches,s.literals,s.wide,s.narrow,s.extra,s.probes,
               s.matched_bytes,s.pure_gain,n);
    }
    free(decoded); free(candidate); free(baseline); free(src);
}
