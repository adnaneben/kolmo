import argparse, csv, hashlib, os, random, shutil, statistics, subprocess, sys, tempfile, time
from pathlib import Path
BASE=Path(__file__).resolve().parent
EXE=Path('/tmp/kolmo-w2-archive/build')
parser=argparse.ArgumentParser(description='Measure verified atomic extraction cost on regular flat file trees.')
parser.add_argument('--baseline', type=Path, default=EXE/'kolmo-baseline')
parser.add_argument('--original-atomic', type=Path, default=EXE/'kolmo')
parser.add_argument('replacement', nargs='?', type=Path)
opts=parser.parse_args()
ARMS={'PR59base':opts.baseline.resolve(strict=True),'PR59':opts.original_atomic.resolve(strict=True)}
if opts.replacement: ARMS['reuse']=opts.replacement.resolve(strict=True)
prefix='repaired-' if 'reuse' in ARMS else ''
STATS_FIELDS=['count','size','threads','rep','order','arm','wall_ms','cpu_ms','rss_bytes','archive_bytes','archive_sha256']
rng=random.Random(2026112519)
def hashbytes(b): return hashlib.sha256(b).hexdigest()
def content(root): return {p.name:(hashbytes(p.read_bytes()),int(p.stat().st_mtime),p.stat().st_mode&0o777) for p in root.iterdir()}
def run(exe,threads,archive,dest):
    command=[str(exe),'extract','-T',str(threads),'-C',str(dest),str(archive)]
    actions=[(os.POSIX_SPAWN_OPEN,1,os.devnull,os.O_WRONLY,0o600)]
    t=time.monotonic_ns()
    pid=os.posix_spawn(command[0],command,os.environ,file_actions=actions)
    _,s,u=os.wait4(pid,0)
    assert s==0
    rss_scale = 1 if sys.platform == 'darwin' else 1024
    return (time.monotonic_ns()-t)/1e6,1000*(u.ru_stime+u.ru_utime),rss_scale*u.ru_maxrss
with tempfile.TemporaryDirectory(dir=BASE) as tmp:
    root=Path(tmp);cases=[]
    for count in (64,256):
        for size in (512,32768):
            src=root/f'source-{count}-{size}';src.mkdir()
            for k in range(count):
                p=src/f'{k:04}.txt';p.write_bytes(hashlib.shake_256(f'stage-{k}'.encode()).digest(size))
                p.chmod(0o644);os.utime(p,(1600000000,1600000000))
            names=sorted(p.name for p in src.iterdir()); want=content(src)
            a=root/f'archive-{count}-{size}'
            subprocess.run([ARMS['PR59base'],'archive','-1','-T','1',a,*names],cwd=src,check=True)
            for t in (1,4):cases.append((count,size,t,want,a,hashbytes(a.read_bytes())))
    rows=[]
    with (BASE/(prefix+'stage-raw.csv')).open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=STATS_FIELDS);writer.writeheader()
        for rep in range(-1,11):
            rng.shuffle(cases)
            for count,size,t,want,a,h in cases:
                ar=list(ARMS);rng.shuffle(ar)
                for o,arm in enumerate(ar):
                    d=root/'restore';d.mkdir()
                    wall,cpu,rss=run(ARMS[arm],t,a,d);assert content(d)==want
                    row=dict(zip(STATS_FIELDS,[count,size,t,rep,o,arm,wall,cpu,rss,a.stat().st_size,h]))
                    writer.writerow(row);f.flush()
                    if rep>=0:rows.append(row)
                    shutil.rmtree(d)
    with (BASE/(prefix+'stage-summary.csv')).open('w',newline='') as f:
        fields=['count','size','threads','from_arm','to_arm','med_before_ms','med_after_ms','median_paired_time_multiplier','after_slower_pairs','pairs']
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for count,size,t,_,_,_ in sorted(cases,key=lambda c:c[:3]):
            g={arm:{r['rep']:r['wall_ms'] for r in rows if (r['count'],r['size'],r['threads'],r['arm'])==(count,size,t,arm)} for arm in ARMS}
            for b,a in [('PR59base','PR59')]+([('PR59','reuse'),('PR59base','reuse')] if 'reuse' in ARMS else []):
                v=[x/g[b][i] for i,x in g[a].items()]
                w.writerow(dict(zip(fields,[count,size,t,b,a,statistics.median(g[b].values()),statistics.median(g[a].values()),statistics.median(v),sum(x>1 for x in v),len(v)])))
