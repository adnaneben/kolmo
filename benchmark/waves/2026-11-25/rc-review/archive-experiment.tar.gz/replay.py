"""End-to-end archive product benchmark. See README.md for command and definitions."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import re
import shutil
import statistics
import subprocess
import sys
import tarfile
import tempfile
import time

R = Path(__file__).resolve().parent
PARSER=argparse.ArgumentParser()
PARSER.add_argument('--silesia-tar', type=Path, required=True)
PARSER.add_argument('--main', type=Path, required=True)
PARSER.add_argument('--wave2', type=Path, required=True)
PARSER.add_argument('--candidate', type=Path, required=True)
PARSER.add_argument('--clean-candidate', type=Path)
PARSER.add_argument('--enwik8', type=Path)
PARSER.add_argument('--reps', type=int, default=7)
PARSER.add_argument('--seed', type=int, default=20261125)
PARSER.add_argument('--contexts', nargs='+', help='explicit workload@threads cells')
PARSER.add_argument('--label', default='')
PARSER.add_argument('--workloads', nargs='+', default=['Silesia 12 files','Silesia gzip member','768 small members'])
PARSER.add_argument('--arms', nargs='+', default=['main','PR73','PR90','tar+LZ4','tar+zstd'])
args=PARSER.parse_args()
K={'main':str(args.main.resolve()),'PR73':str(args.wave2.resolve()),'PR90':str(args.candidate.resolve())}
if args.clean_candidate: K['direct-main']=str(args.clean_candidate.resolve(strict=True))
K['main-AA']=K['main']
TAR=shutil.which('tar'); LZ4=shutil.which('lz4'); ZSTD=shutil.which('zstd')
E={k:v for k,v in os.environ.items() if not k.startswith(('KOLMO_','ZSTD_','LZ4_'))}
E['COPYFILE_DISABLE']='1'
seed=random.Random(args.seed)
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()
def metadata(p):
    st=p.stat()
    return (st.st_size,st.st_mode & 0o777,int(st.st_mtime),sha(p))
def timer(cmds,cwd,output,errfile):
    old=os.getcwd()
    pids=[]
    os.chdir(cwd)
    try:
        out=os.open(output,os.O_WRONLY|os.O_TRUNC|os.O_CREAT,0o600)
        err=os.open(errfile,os.O_WRONLY|os.O_TRUNC|os.O_CREAT,0o600)
        if len(cmds)==2: rd,wr=os.pipe()
        start=time.perf_counter_ns()
        for i,cmd in enumerate(cmds):
            actions=[(os.POSIX_SPAWN_DUP2,err,2),(os.POSIX_SPAWN_DUP2,(wr if len(cmds)==2 and i==0 else out),1)]
            if i==1: actions.append((os.POSIX_SPAWN_DUP2,rd,0))
            if len(cmds)==2: actions.extend([(os.POSIX_SPAWN_CLOSE,rd),(os.POSIX_SPAWN_CLOSE,wr)])
            pids.append(os.posix_spawn(cmd[0],list(map(str,cmd)),E,file_actions=actions))
        if len(cmds)==2:
            os.close(rd); os.close(wr)
        usage=[os.wait4(p,0) for p in pids]
        elapsed=(time.perf_counter_ns()-start)/1e6
        os.close(err); os.close(out)
        for _,code,_ in usage:
            if code: raise RuntimeError((cmds,code,errfile.read_text()))
        rss_scale = 1 if sys.platform == 'darwin' else 1024
        return elapsed,1000*sum(x.ru_utime+x.ru_stime for _,_,x in usage),rss_scale*max(x.ru_maxrss for _,_,x in usage)
    finally:
        os.chdir(old)
def summary(allrows):
    groups={}
    for row in allrows:
        if row['rep']>=0:
            groups.setdefault((row['workload'],row['requested_threads'],row['arm']),[]).append(row)
    out=[]
    for group,rows in groups.items():
        row=rows[0]; n=row['input_bytes']; a=set(x['archive_bytes'] for x in rows)
        assert len(a)==1
        archive=a.pop()
        item=dict(workload=group[0], requested_threads=group[1],arm=group[2],input_bytes=n,archive_bytes=archive,
                  ratio=n/archive,reps=len(rows),members=row['members'])
        for k in ('encode_ms','decode_ms','total_ms','encode_cpu_ms','decode_cpu_ms','encode_rss_bytes','decode_rss_bytes'):
            item[k]=statistics.median(x[k] for x in rows)
        for dest,key in [('encode_MBps','encode_ms'),('decode_MBps','decode_ms'),('combined_MBps','total_ms')]:
            item[dest]=n/1000/item[key]
        out.append(item)
    with (R/(args.label+'summary.csv')).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
def prepare(root):
    inputs={}
    tree=root/'silesia'; tree.mkdir()
    with tarfile.open(args.silesia_tar) as t:
        for item in t:
            assert item.isfile() and Path(item.name).name==item.name
            dest=tree/item.name
            with t.extractfile(item) as src,dest.open('wb') as out: shutil.copyfileobj(src,out)
            dest.chmod(0o644); os.utime(dest,(1600000000,1600000000))
    inputs['Silesia 12 files']=tree
    comp=root/'compressed'; comp.mkdir()
    gzip=comp/'silesia.tar.gz'
    with gzip.open('wb') as out:
        subprocess.run([shutil.which('gzip'),'-n','-6','-c',args.silesia_tar],stdout=out,check=True)
    os.utime(gzip,(1600000000,1600000000)); gzip.chmod(0o644)
    inputs['Silesia gzip member']=comp
    sm=root/'small'; sm.mkdir()
    with args.silesia_tar.open('rb') as f: source=f.read(4<<20)
    for k in range(768):
        off=(75917*k)%((4<<20)-8192); p=sm/f'{k:04}.bin'
        suffix=hashlib.shake_256(f'kolmo-archive-fixture-v1/{k}'.encode()).digest(1024)
        p.write_bytes(source[off:off+7168]+suffix); p.chmod(0o644);os.utime(p,(1600000000,1600000000))
    inputs['768 small members']=sm
    if args.enwik8:
        wiki=root/'wiki'; wiki.mkdir(); member=wiki/'enwik8.gz'
        with member.open('wb') as out:
            subprocess.run([shutil.which('gzip'),'-n','-6','-c',args.enwik8],stdout=out,check=True)
        os.utime(member,(1600000000,1600000000)); member.chmod(0o644)
        assert member.stat().st_size>=32<<20
        inputs['enwik8 gzip member']=wiki
    return inputs
with tempfile.TemporaryDirectory(dir=R) as tmp:
    root=Path(tmp); inputs=prepare(root)
    expected={k:{p.name:metadata(p) for p in sorted(v.iterdir())} for k,v in inputs.items()}
    (R/(args.label+'inputs.json')).write_text(json.dumps(expected,indent=1))
    arm_frames={}; rows=[]
    raw=R/(args.label+'raw.csv')
    for rep in range(-1,args.reps):
        contexts=[(k,t) for k in args.workloads for t in (1,4)]
        if args.contexts:
            contexts=[(name,int(t)) for name,t in (x.rsplit('@',1) for x in args.contexts)]
        seed.shuffle(contexts)
        for workload,threads in contexts:
            src=inputs[workload]; members=sorted(expected[workload])
            n=sum(x[0] for x in expected[workload].values())
            arms=args.arms[:];seed.shuffle(arms)
            # Include process-start, content reads, compressed writes, restore writes;
            # verification runs after timers and outside the timed restoration.
            for order,arm in enumerate(arms):
                output=root/'archive'; restored=root/'restore';restored.mkdir()
                worker='--single-thread' if threads==1 else f'-T{threads}'
                if arm in K:
                    enc=[[K[arm],'archive','-1','-T',str(threads),'--stats',output,*members]]
                    dec=[[K[arm],'extract','-T',str(threads),'-C',restored,output]]
                    dest=os.devnull
                else:
                    comp=LZ4 if arm=='tar+LZ4' else ZSTD
                    switches=['-B7'] if arm=='tar+LZ4' else []
                    enc=[[TAR,'-cf','-',*members],[comp,'-q','-1',*switches,worker,'-c']]
                    dec=[[comp,'-d','-q','-c',output],[TAR,'-xf','-','-C',restored]]
                    dest=output
                em,ec,er=timer(enc,src,dest,root/'stderr')
                counts=None
                if arm in K:
                    x=re.search(r'(\d+) chunks, (\d+) distinct \((\d+) bytes', (root/'stderr').read_text()); assert x
                    counts=list(map(int,x.groups()))
                    if workload.endswith('gzip member'): assert counts[0]==counts[1] and counts[2]==n
                dm,dc,dr=timer(dec,root,os.devnull,root/'stderr')
                actual={p.name:metadata(p) for p in sorted(restored.iterdir())}
                if actual!=expected[workload]: raise ValueError((workload,threads,arm,'restore mismatch'))
                frame=sha(output)
                if arm in K:
                    key=(workload,threads,'kolmo')
                    if key in arm_frames and arm_frames[key]!=frame: raise ValueError((key,'frame mismatch'))
                    arm_frames[key]=frame
                row=dict(workload=workload,requested_threads=threads,arm=arm,rep=rep,order=order,
                         members=len(members),input_bytes=n,archive_bytes=output.stat().st_size,archive_sha256=frame,
                         encode_ms=em,decode_ms=dm,total_ms=em+dm,encode_cpu_ms=ec,decode_cpu_ms=dc,
                         encode_rss_bytes=er,decode_rss_bytes=dr,chunks=counts[0] if counts else '',
                         distinct_chunks=counts[1] if counts else '',unique_bytes=counts[2] if counts else '')
                if not rows:
                    with raw.open('w',newline='') as f: csv.DictWriter(f,fieldnames=list(row)).writeheader()
                with raw.open('a',newline='') as f: csv.DictWriter(f,fieldnames=list(row)).writerow(row)
                rows.append(row);output.unlink();shutil.rmtree(restored)
        if rep>=0: summary(rows)
        print('completed repetition',rep,flush=True)
