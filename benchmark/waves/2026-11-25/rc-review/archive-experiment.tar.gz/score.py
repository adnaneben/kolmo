"""Compute per-repetition paired speed ratios, sign counts and bootstrap medians."""
import csv
import random
import statistics as S
import sys
from pathlib import Path
R=Path(__file__).resolve().parent
prefix=sys.argv[1] if len(sys.argv)>1 else ''
candidate=sys.argv[2] if len(sys.argv)>2 else 'PR90'
rng=random.Random(20261125)
data={}
with (R/(prefix+'raw.csv')).open() as f:
    for r in csv.DictReader(f):
        i=int(r['rep'])
        if i>=0: data.setdefault((r['workload'],int(r['requested_threads'])),{}).setdefault(i,{})[r['arm']]=r
allrows=[]
for (ws,t),pairs in sorted(data.items()):
    for metric in ('encode_ms','decode_ms','total_ms','encode_cpu_ms','decode_cpu_ms','encode_rss_bytes','decode_rss_bytes'):
        for base in ('PR73','main','main-AA','tar+LZ4','tar+zstd'):
            if base==candidate: continue
            vals=[float(r[base][metric])/float(r[candidate][metric]) for r in pairs.values() if candidate in r and base in r]
            if not vals: continue
            n=len(vals)
            boot=sorted(S.median(rng.choices(vals,k=n)) for _ in range(10000))
            allrows.append(dict(workload=ws,requested_threads=t,baseline=base,metric=metric,
                                median_paired_speedup=S.median(vals),wins=sum(x>1 for x in vals),
                                ties=sum(x==1 for x in vals),pairs=n,
                                lo95=boot[249],hi95=boot[9749]))
assert allrows
with (R/(prefix+'paired.csv')).open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
