"""Real CZN1 Ultra block selection, bounded rerun, and stock v0.0.2 cross decoder."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import random
import struct
import tarfile
import tempfile
import time

p=argparse.ArgumentParser()
p.add_argument('corpus', type=Path)
p.add_argument('binary', type=Path)
p.add_argument('released', type=Path)
p.add_argument('out', type=Path)
p.add_argument('--set',choices=['small','threshold','natural','speed','all'],default='all')
args=p.parse_args()
mi=1<<20
root=args.out;root.mkdir(exist_ok=True)
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(mi),b''):h.update(b)
    return h.hexdigest()
def read_off(p,start,length):
    with p.open('rb') as f:f.seek(start);b=f.read(length)
    assert len(b)==length
    return b
def timed(exe,opts):
    argv=[str(exe)]+[str(x) for x in opts]
    start=time.perf_counter()
    pid=os.posix_spawn(str(exe),argv,os.environ)
    _,rc,r=os.wait4(pid,0)
    return dict(code=os.waitstatus_to_exitcode(rc),wall_s=time.perf_counter()-start,cpu_s=r.ru_stime+r.ru_utime,rss_bytes=r.ru_maxrss)
def frameinfo(p):
    with p.open('rb') as f:
        h=f.read(32)
        assert h[:4]==b'CZN1' and h[4]==12
        count=struct.unpack_from('<I',h,20)[0];assert 0<count<4096
        idx=f.read(16*count)
        blocks=[]
        for i in range(count):
            n,z,_,cid,tf=struct.unpack_from('<IIIBB',idx,16*i);body=f.read(z)
            assert len(body)==z
            blocks.append(dict(raw=n,stored=z,codec=cid,tflag=tf,plan=list(body[:4]),prefix=body[4:18].hex()))
        return dict(blocks=blocks,header_block=struct.unpack_from('<I',h,24)[0],bytes=p.stat().st_size,raw=struct.unpack_from('<Q',h,12)[0],sha256=sha(p))
binary,release=map(Path.resolve,(args.binary,args.released))
manifest=dict(binary=sha(binary),released=sha(release),platform=os.uname().machine,inputs={},source_geometry={})
with tempfile.TemporaryDirectory(dir=root) as temp:
    td=Path(temp)
    docs=args.corpus/'mkt/data';imp=args.corpus/'impact/corpus/holdout'
    chars=docs/'enwik8';sile=docs/'silesia.tar'
    inputs={}
    def add(name,data,geometry):
        path=td/name;path.write_bytes(data);inputs[name]=path
        manifest['inputs'][name]=dict(size=len(data),sha256=sha(path));manifest['source_geometry'][name]=geometry
    add('enwik-offset-256k',read_off(chars,262144,262144),'enwik8 [262144,524288)')
    add('reymont-offset-256k',read_off(imp/'text__reymont',262144,262144),'text__reymont [262144,524288)')
    # A deterministic normal archive; stock parser should emit separate larger text-member segments.
    output=io.BytesIO()
    with tarfile.open(fileobj=output,mode='w',format=tarfile.USTAR_FORMAT) as t:
        for name in ['text__reymont','code__jxl-cc']:
            data=read_off(imp/name,131072,mi+65536)
            member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0
            t.addfile(member,io.BytesIO(data))
    add('two-real-members-ustar',output.getvalue(),'Python USTAR, two actual 1,114,112-byte spans starting at offset 131072 of text__reymont and code__jxl-cc. TarInfo regular 0644, mtime/uid/gid zero, name = source basename.')
    add('stock-build-MachO',binary.read_bytes(),'Complete unmodified arm64 Kolmo executable used in this replay. See exact binary SHA and source tree pin.')
    add('jxl-offset-256k',read_off(imp/'code__jxl-cc',262144,262144),'code__jxl-cc [262144,524288)')
    n=8*mi+512*1024
    add('enwik-threshold',read_off(chars,mi,n),f'enwik8 [{mi},{mi+n})')
    with tarfile.open(sile) as f:
        fo=f.extractfile('dickens');fo.read(mi); data=fo.read(n);assert len(data)==n
    add('dickens-threshold',data,f'silesia.tar/dickens [{mi},{mi+n})')
    (root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    small=['enwik-offset-256k','reymont-offset-256k']
    # 256 MiB grows the normal 128 MiB file block target, independently of -T.
    cells_small=[(name,arm,t,[],block) for name in small for (arm,block) in [('ordinary',None),('larger-256M','256'),('short-64K','0.0625')] for t in (1,4)]
    cells_small += [('two-real-members-ustar',arm,t,[],block) for arm,block in [('ordinary',None),('larger-256M','256')] for t in (1,4)]
    cells_cap=[(name,arm,t,['-M','256M'],block) for name in ['enwik-threshold','dickens-threshold'] for arm,block in [('capped-default',None),('capped-larger-16M','16')] for t in (1,4)]
    suites=([('small',cells_small,2)] if args.set in ('small','all') else [])+([('threshold',cells_cap,1)] if args.set in ('threshold','all') else [])
    if args.set in ('natural','all'):
        suites.append(('natural',[('stock-build-MachO',arm,t,[],block) for arm,block in [('ordinary',None),('larger-256M','256')] for t in (1,4)],1))
    if args.set in ('speed','all'):
        suites.append(('speed',[(name,arm,4,[],block) for name in small+['jxl-offset-256k'] for arm,block in [('ordinary',None),('short-64K','0.0625')]],7))
    for suite,cells,reps in suites:
        raw=root/(suite+'.jsonl')
        rows=[json.loads(l) for l in raw.read_text().splitlines()] if raw.exists() else []
        done={(r['name'],r['arm'],r['t'],r['rep']) for r in rows}
        verified={r['frame']['sha256'] for r in rows if r.get('stock_read')}
        rng=random.Random(2559188)
        with raw.open('a',buffering=1) as sink:
            for rep in range(reps):
                for name,arm,t,mem,block in rng.sample(cells,len(cells)):
                    if (name,arm,t,rep) in done:continue
                    path=inputs[name];frame=td/'output.czn';out=td/'restored'
                    frame.unlink(missing_ok=True);out.unlink(missing_ok=True)
                    enc=timed(binary,['-U','-T',t]+mem+(['--block-size',block] if block else [])+['-f','-q',path,'-o',frame])
                    r=dict(name=name,arm=arm,t=t,rep=rep,enc=enc,stock_read=False)
                    if enc['code']==0:
                        fi=frameinfo(frame);r['frame']=fi
                        r['dec']=timed(binary,['-d','-T',t,'-f','-q',frame,'-o',out])
                        if r['dec']['code'] or sha(out)!=manifest['inputs'][name]['sha256']:raise RuntimeError((name,arm,t,'self'))
                        if fi['sha256'] not in verified:
                            out.unlink()
                            r['stock']=timed(release,['-d','-T',t,'-f','-q',frame,'-o',out])
                            if r['stock']['code'] or sha(out)!=manifest['inputs'][name]['sha256']:raise RuntimeError((name,arm,t,'stock'))
                            r['stock_read']=True;verified.add(fi['sha256'])
                    print(json.dumps(r),file=sink)
