from collections import defaultdict
from pathlib import Path
import csv,json,statistics
base=Path(__file__).resolve().parent
rows=list(csv.DictReader((base/'summary.csv').open()))
g={(r['name'],r['t'],r['arm']):r for r in rows}
s=['# Ultra physical-block experiment','',
'Ordinary native Ultra already used one stateful codec-7/model-4 block on each tested 256 KiB file. Increasing its 128 MiB target to 256 MiB changed no output size. A single CM4 stream saved bytes versus specifically forcing 64 KiB blocks. The four smaller blocks exposed an independent parallel user option with a different ratio and peak RSS. The capped and metadata workloads below show why the standalone savings cannot be credited to ordinary Ultra+.', '',
'## Capped 8.5 MiB real text spans','','Both arms use the same 256 MiB encoder admission cap. The automatic target in the CZN1 header is 8 MiB under this cap. The larger-arm target is explicitly 16 MiB. Tests verify source and stock-v12 decode SHA. Each timing is a single full run for that arm; no stable speed or memory win is claimed.', '',
'| Source | Requested T | Physical blocks | Frame B, default → larger | Size change | Total s, default → larger | Combined speed change | Peak encoder / decoder MiB, default → larger |','| --- | ---: | --- | ---: | ---: | ---: | ---: | --- |']
for name in ['enwik-threshold','dickens-threshold']:
    for t in ['1','4']:
        if (name,t,'capped-larger-16M') not in g or (name,t,'capped-default') not in g:continue
        a=g[name,t,'capped-default'];b=g[name,t,'capped-larger-16M']
        s.append(f"| {name.split('-')[0]} | {t} | {a['physical_sizes'].replace(' ',' + ')} → {b['physical_sizes']} | {int(a['frame_bytes']):,} → {int(b['frame_bytes']):,} | {(float(b['frame_bytes'])/float(a['frame_bytes'])-1)*100:+.2f}% | {float(a['combined_s']):.2f} → {float(b['combined_s']):.2f} | {(float(b['combined_MBps'])/float(a['combined_MBps'])-1)*100:+.2f}% | {float(a['encode_peak_MiB']):.1f} / {float(a['decode_peak_MiB']):.1f} → {float(b['encode_peak_MiB']):.1f} / {float(b['decode_peak_MiB']):.1f} |")
s+=['','## Independent member and region boundaries','','| Producer | Requested T | Default/256 MiB bytes | Default/256 MiB blocks | Native codecs |', '| --- | ---: | ---: | ---: | --- |']
for n in ['two-real-members-ustar','stock-build-MachO']:
    for t in ['1','4']:
        if (n,t,'ordinary') not in g or (n,t,'larger-256M') not in g:continue
        a=g[n,t,'ordinary'];b=g[n,t,'larger-256M']
        s.append(f"| {n} | {t} | {int(a['frame_bytes']):,} / {int(b['frame_bytes']):,} | {a['blocks']} / {b['blocks']} | {a['codec_ids']} |")
s+=['','## Repeated short-block throughput tradeoff','','For each source, compare ordinary T4 with four forced 64 KiB blocks at T4. Each independently repeated trial measures a full raw-file encode and decode on the same machine; requested threads remain fixed. Ratios below use paired per-repetition sums of native encode and decode wall time. Byte counts include the complete CZN1 frame. A speed increase with larger output is a point on a tradeoff curve.','',
'| 256 KiB source span | Trials per arm | Stored bytes, ordinary → four | Extra output | Paired combined speed | Ratio × combined speed | Faster trials | Peak RSS encode/decode MiB, ordinary → four |','| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
f=base/'speed.jsonl'
if f.exists():
    rr=[json.loads(l) for l in f.read_text().splitlines()]
    cells=defaultdict(dict)
    for r in rr:cells[r['name'],r['rep']][r['arm']]=r
    for n in sorted({k[0] for k in cells}):
        a=[];b=[];speed=[]
        for (name,rep),cell in cells.items():
            if name!=n or set(cell)!={'ordinary','short-64K'}:continue
            x=cell['ordinary'];y=cell['short-64K'];a.append(x);b.append(y)
            speed.append(sum(x[p]['wall_s'] for p in ['enc','dec'])/sum(y[p]['wall_s'] for p in ['enc','dec']))
        if not a:continue
        aa=a[0]['frame']['bytes'];bb=b[0]['frame']['bytes'];v=statistics.median(speed)
        def rss(rs,p):return max(z[p]['rss_bytes'] for z in rs)/2**20
        s.append(f"| {n} | {len(a)} | {aa:,} → {bb:,} | {(bb/aa-1)*100:+.2f}% | {v:.2f}× | {v*aa/bb:.2f}× | {sum(k>1 for k in speed)}/{len(speed)} | {rss(a,'enc'):.1f} / {rss(a,'dec'):.1f} → {rss(b,'enc'):.1f} / {rss(b,'dec'):.1f} |")
s+=['','No default change or cross-architecture claim follows. When a whole file already has one physical block, a different advertised target cannot remove another reset. In a capped text stream the benefit depends on capacity-dependent table size, history and the second block’s fraction of input, and T4 versus a virtually serial code path. Separately evaluate the existing explicit small-block option for a latency-prioritized multi-core policy on a sealed population; report its storage and memory costs and compare the neighboring native levels and rival settings at equal bytes and equal speed.','',
'See PROTOCOL.md, summary.csv for all phase metrics, the per-study JSONL receipts with frame and model headers, and replay.py. None of these tests compares full-corpus PAQ8PX or CMIX.']
(base/'README.md').write_text('\n'.join(s)+'\n')
