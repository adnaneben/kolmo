from pathlib import Path
import csv
import hashlib
import json
import statistics
import sys
from collections import defaultdict
base=Path(__file__).resolve().parent
groups=defaultdict(list); cross=set()
for p in ['small.jsonl','threshold.jsonl','natural.jsonl','speed.jsonl']:
    f=base/p
    if not f.exists():continue
    for line in f.read_text().splitlines():
        r=json.loads(line);groups[(r['name'],r['t'],r['arm'])].append(r)
        if r['stock_read']:cross.add(r['frame']['sha256'])
rows=[]
for (name,t,arm),rs in sorted(groups.items()):
    good=[r for r in rs if r['enc']['code']==0]
    if not good:
        rows.append(dict(name=name,t=t,arm=arm,success=0,trials=len(rs)));continue
    assert len(good)==len(rs) and len({r['frame']['sha256'] for r in rs})==1
    f=good[0]['frame'];bl=f['blocks']; enc=[r['enc'] for r in rs]; dec=[r['dec'] for r in rs]
    def mid(a,k):return statistics.median(x[k] for x in a)
    sec=statistics.median(e['wall_s']+d['wall_s'] for e,d in zip(enc,dec))
    rows.append(dict(name=name,t=t,arm=arm,success=len(rs),trials=len(rs),input_bytes=f['raw'],frame_bytes=f['bytes'],ratio=f['raw']/f['bytes'],header_block_MiB=f['header_block']/2**20,blocks=len(bl),cm_blocks=sum(b['codec']==7 for b in bl),codec_ids=' '.join(str(b['codec']) for b in bl),physical_sizes=' '.join(str(b['raw']) for b in bl),frame_sha256=f['sha256'],stock_sha_verified=f['sha256'] in cross,encode_s=mid(enc,'wall_s'),decode_s=mid(dec,'wall_s'),combined_s=sec,encode_MBps=f['raw']/1e6/mid(enc,'wall_s'),decode_MBps=f['raw']/1e6/mid(dec,'wall_s'),combined_MBps=f['raw']/1e6/sec,cpu_combined_s=statistics.median(e['cpu_s']+d['cpu_s'] for e,d in zip(enc,dec)),encode_peak_MiB=max(e['rss_bytes'] for e in enc)/2**20,decode_peak_MiB=max(d['rss_bytes'] for d in dec)/2**20))
keys=list(dict.fromkeys(key for r in rows for key in r))
with (base/'summary.csv').open('w') as out:
    w=csv.DictWriter(out,fieldnames=keys);w.writeheader();w.writerows(rows)
if 'table' in sys.argv:
    print('| Input | Requested T | Block policy | Coded bytes | Ratio | Physical / codec-7 blocks | Encode / decode s | Combined MB/s | RSS encode / decode MiB |')
    print('| --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: |')
    for r in rows:
        if not r['success']:print(f"| {r['name']} | {r['t']} | {r['arm']} | refused | | | | | |");continue
        print(f"| {r['name']} | {r['t']} | {r['arm']} | {r['frame_bytes']:,} | {r['ratio']:.3f} | {r['blocks']} / {r['cm_blocks']} | {r['encode_s']:.3f} / {r['decode_s']:.3f} | {r['combined_MBps']:.3f} | {r['encode_peak_MiB']:.1f} / {r['decode_peak_MiB']:.1f} |")
