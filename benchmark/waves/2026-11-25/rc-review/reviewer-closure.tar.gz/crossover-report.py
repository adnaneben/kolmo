from pathlib import Path
import json
base=Path(__file__).resolve().parent
p=base/'recheck'
report=json.loads((p/'crossover-summary.json').read_text())
raw=[json.loads(r) for r in (p/'crossover.jsonl').read_text().splitlines()]
assert len(raw)==180
for k in report:
    rows=[r for r in raw if r['case']==k]
    assert len(rows)==45 and len({(r['source_sha256'],r['frame_sha256']) for r in rows})==1
res=['# Transfer context A/A and A/B confirmation', '', 'Four transfer settings, 15 interleaved trips apiece. A and AA are two fresh invocations of Wave 1; B is Wave 2. In each trip and for each metric, candidate time is divided by the arithmetic mean of the two baseline times. The table displays the median of those ratios minus one. The A/A column is the median of AA divided by A minus one. Both phase costs are included in each timed trip. Input and frame bytes were identical across every arm in a setting.', '', '| Workload and requested threads | Baseline A/A wall | Candidate wall | Candidate CPU | Candidate slower wall trips |','| --- | ---: | ---: | ---: | ---: |']
for key,cell in sorted(report.items()):
    z=cell['B/mean(A,AA)'];aa=cell['A/A']
    res.append(f"| {key} | {(aa['wall']['median']-1)*100:+.2f}% | {(z['wall']['median']-1)*100:+.2f}% | {(z['cpu']['median']-1)*100:+.2f}% | {z['wall']['slower']}/15 |")
res+=['','Report archives include all 180 exact round trips, the randomized run, separate enc/dec wall/CPU/RSS per arm and reference binary provenance in manifest.json. These experiments revisit existing materials on one machine. They are separate from the independent release backport experiment.']
(p/'crossover-results.md').write_text('\n'.join(res)+'\n')
