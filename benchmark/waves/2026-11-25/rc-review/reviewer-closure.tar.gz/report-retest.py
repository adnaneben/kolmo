"""Summarize actual paired trials; no promotion inferred from a nonsignificant difference."""
from pathlib import Path
import json, statistics, math
p=Path(__file__).resolve().parent/'recheck'
raw=[json.loads(s) for s in (p/'rerun.jsonl').read_text().splitlines()]
data=json.loads((p/'rerun-summary.json').read_text())
keyed={(r['case'],r['pair'],r['arm']):r for r in raw}
assert len(raw)==168 and len(keyed)==168 and len(data)==12
def med(a):return statistics.median(a)
def signprob(w,n):
    return min(1,2*sum(math.comb(n,k) for k in range(min(w,n-w)+1))/(2**n))
def line(row): return '| '+' | '.join(str(c) for c in row)+' |'
ordered=sorted(data)
out=['# Specialist and earlier-wave regression recheck','','Seven fresh, paired randomized file-to-file comparisons per setting. The numerator is the later arm. Each speed value compares the sum of encode and decode times from one matched trial. The median of paired time ratios and the two independently tabulated wall medians can differ. CPU uses the sum of user and system time in the two subprocesses. The table retains the number of slower paired wall times and the exact two-sided sign-test p-value, conditional on independence of paired signs. They are descriptive on one shared host, with no multiple-comparison adjustment or cross-host inference.','','| Context | Pairs | Archive bytes | Combined wall, before → after ms | Paired wall change | Paired CPU change | Slower pairs | Sign p |','| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: |']
for name in ordered:
    d=data[name]
    assert d['pairs']==7
    rows=[keyed[(name,i,v)] for i in range(7) for v in ('before','after')]
    assert len({(r['raw_sha256'],r['frame_sha256'],r['stored_bytes']) for r in rows})==1
    out.append(line([name,7,f"{rows[0]['stored_bytes']:,}",f"{d['before_ms']:.2f} → {d['after_ms']:.2f}",f"{100*(d['after_before_wall']-1):+.2f}%",f"{100*(d['after_before_cpu']-1):+.2f}%",d['wall_slower'],f"{signprob(d['wall_slower'],7):.3f}"]))
out += ['','A total of 168 encodes and 168 decodes produced the input SHA-256 and the same compressed SHA-256 for all 84 paired comparisons. Original binary SHA-256 identities match the wave manifests. Both historical settings with the largest specialist flags were repeated exactly. Controls change accession, tensor producer and size, or thread count. `one-qwen-bf16.safetensors` is a freshly constructed valid single-tensor container taken from model.layers.0.self_attn.o_proj.weight in the recorded Qwen checkpoint. The project download manifest identifies its 988,097,824-byte Qwen checkpoint by SHA-256 88c142557820ccad55bb59756bfcfcf891de9cc6202816bd346445188a0ed342. This is a previously available engineering transfer control. The replay script identifies the exact tensor and hashes; no training or corpus payload is distributed.','', 'Original exploratory results remain in regression-screen.csv. BGL L1 had a separate existing 15-pair retest in #85. Paired run order, individual phase wall/CPU/RSS and raw/frame hashes remain in rerun.jsonl.']
(p/'results.md').write_text('\n'.join(out)+'\n')
