"""Interleaved fresh-process file-to-file specialist regression retest on the original binaries."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import struct
import tempfile
import time

P = argparse.ArgumentParser()
P.add_argument('source', type=Path)
P.add_argument('builds', type=Path)
P.add_argument('original_main', type=Path)
P.add_argument('results', type=Path)
args = P.parse_args()
args.results.mkdir(parents=True, exist_ok=True)
def sha(p):
    with p.open('rb') as f:
        h = hashlib.sha256()
        for b in iter(lambda:f.read(1024*1024), b''):
            h.update(b)
    return h.hexdigest()

def qwen_fixture(src, dest):
    with src.open('rb') as f:
        hlen = struct.unpack('<Q',f.read(8))[0]
        hdr = json.loads(f.read(hlen))
        entry, obj = next((name,v) for name,v in hdr.items() if isinstance(v,dict) and v.get('dtype')=='BF16' and 1<<20 <= v['data_offsets'][1]-v['data_offsets'][0] <= 4<<20)
        start,end = obj['data_offsets']
        rep = json.dumps({entry:dict(dtype='BF16',shape=obj['shape'],data_offsets=[0,end-start])},separators=(',',':')).encode()
        rep += b' '*(-len(rep)%8)
        f.seek(8+hlen+start)
        payload=f.read(end-start)
        assert len(payload)==end-start
        dest.write_bytes(struct.pack('<Q',len(rep))+rep+payload)
        return entry

def call(path,argv):
    start = time.perf_counter()
    pid = os.posix_spawn(str(path),[str(path)]+[str(x) for x in argv],os.environ)
    _,status,usage=os.wait4(pid,0)
    if status: raise RuntimeError((argv,status))
    return dict(wall_s=time.perf_counter()-start,cpu_s=usage.ru_utime+usage.ru_stime,rss_bytes=usage.ru_maxrss)

def summarize(rows):
    by={}
    for r in rows:
        by.setdefault((r['case'],r['pair']),{})[r['arm']]=r
    ans={}
    for k,v in by.items():
        if len(v)!=2:continue
        x,y=[v[n] for n in ('before','after')]
        assert x['raw_sha256']==y['raw_sha256'] and x['frame_sha256']==y['frame_sha256']
        dest=ans.setdefault(k[0],dict(wall=[],cpu=[],before=[],after=[],ts=[]))
        for met,target in [('wall_s','wall'),('cpu_s','cpu')]:
            s=sum(x[p][met] for p in ('enc','dec'))
            t=sum(y[p][met] for p in ('enc','dec'))
            dest[target].append(t/s)
            if target=='wall':
                dest['before'].append(s)
                dest['after'].append(t)
        dest['ts'].append(k[1])
    return {name:dict(pairs=len(d['ts']),after_before_wall=statistics.median(d['wall']),after_before_cpu=statistics.median(d['cpu']),wall_slower=sum(x>1 for x in d['wall']),before_ms=1000*statistics.median(d['before']),after_ms=1000*statistics.median(d['after']),wall_ratios=d['wall'],cpu_ratios=d['cpu']) for name,d in ans.items()}

builds=dict(main=args.original_main,wave1=args.builds/'wave1/build/kolmo',wave2=args.builds/'wave2/build/kolmo')
wave2=('wave1','wave2')
wave1=('main','wave1')
hold=args.source/'corpus-holdout'
domain=args.source/'corpus-domain'
panel=args.source/'impact/corpus/holdout'
bf47=hold/'llm_bf16_47mb.safetensors'
bf10=args.source/'corpus/llm_bf16_10mb.safetensors'
fq=hold/'SRR2584863.fastq'
fq2=domain/'SRR835775_norm.fastq'
qwen=args.results/'one-qwen-bf16.safetensors'
selected=qwen_fixture(args.source/'bench-page/data/weights/qwen2.5-0.5b-bf16.safetensors',qwen)
cases=[
    ('w2-fq-l3-t10',fq,3,10,wave2),
    ('w2-fq-l3-t1',fq,3,1,wave2),
    ('w2-fq2-l3-t4',fq2,3,4,wave2),
    ('w2-bf47-l9-t10',bf47,9,10,wave2),
    ('w2-bf10-l9-t4',bf10,9,4,wave2),
    ('w2-qwen-l9-t1',qwen,9,1,wave2),
    ('w1-img16-l5-t1',panel/'img16__mr',5,1,wave1),
    ('w1-img16-l5-t4',panel/'img16__mr',5,4,wave1),
    ('w1-bgl-l2-t1',panel/'log__bgl',2,1,wave1),
    ('w1-bgl-l3-t1',panel/'log__bgl',3,1,wave1),
    ('w1-bgl-l6-t1',panel/'log__bgl',6,1,wave1),
    ('w1-bgl-l3-t4',panel/'log__bgl',3,4,wave1)]
shared={p:sha(p) for _,p,_,_,_ in cases}
expected=json.loads((args.builds/'wave2.manifest.json').read_text())
hashes={k:sha(v) for k,v in builds.items()}
m1=json.loads((args.builds/'wave1.manifest.json').read_text())
assert all(sha(p)==s for k,s in expected['binaries'].items() for p in [builds[k]])
assert hashes['main']==m1['binaries']['main']
assert all(shared[p]==expected['inputs'][p.name] for p in shared if p.name in expected['inputs'])
meta=dict(binaries=hashes,inputs={p.name:s for p,s in shared.items()},qwen_tensor=selected,seeds=[59812,44019],metrics='paired sum of per-process wall and separately CPU, SHA256 both restored raw and identical frames for A/B; seven pairs; fresh CLI, warm filesystem; no warmup discarded',host=os.uname().machine)
(args.results/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
f=args.results/'rerun.jsonl'
rows=[json.loads(l) for l in f.read_text().splitlines()] if f.exists() else []
seen={(r['case'],r['pair'],r['arm']) for r in rows}
r1=random.Random(59812)
r2=random.Random(44019)
frame_digests={}
with tempfile.TemporaryDirectory(dir=args.results) as t, f.open('a',buffering=1) as out:
    t=Path(t)
    for round_id in range(7):
        for name,source,lv,nt,arms in r1.sample(cases,len(cases)):
            for arm,binary in r2.sample(list(zip(('before','after'),arms)),2):
                if (name,round_id,arm) in seen:continue
                frame, dest=t/'t.ko',t/'t.out'
                frame.unlink(missing_ok=True);dest.unlink(missing_ok=True)
                load=os.getloadavg()
                enc=call(builds[binary],['--level',lv,'-T',nt,'-q','-f',source,'-o',frame])
                dec=call(builds[binary],['-d','-T',nt,'-q','-f',frame,'-o',dest])
                fs=sha(frame)
                if sha(dest)!=shared[source] or frame_digests.setdefault(name,fs)!=fs:raise ValueError(f'bytes changed {name}')
                d=dict(case=name,source=source.name,raw_sha256=shared[source],raw_bytes=source.stat().st_size,stored_bytes=frame.stat().st_size,frame_sha256=fs,level=lv,threads=nt,arm=arm,binary=binary,pair=round_id,enc=enc,dec=dec,load=load)
                rows.append(d)
                print(json.dumps(d),file=out)
        (args.results/'rerun-summary.json').write_text(json.dumps(summarize(rows),indent=2)+'\n')
