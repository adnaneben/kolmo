"""Fifteen randomized A/A/B triplets for two transfer flags and alternate thread controls."""
from pathlib import Path
import hashlib, json, os, random, statistics, sys, tempfile, time
out, source, builds = map(Path,sys.argv[1:])
meta=json.loads((out/'manifest.json').read_text())
variants={'A':'wave1','AA':'wave1','B':'wave2'}
paths={key:builds/name/'build/kolmo' for key,name in variants.items()}
def sha(p):
    with p.open('rb') as f:
        h=hashlib.sha256()
        for piece in iter(lambda:f.read(2**20),b''):h.update(piece)
    return h.hexdigest()
assert all(sha(p)==meta['binaries'][variants[k]] for k,p in paths.items())
q=out/'one-qwen-bf16.safetensors'
fq=source/'corpus-domain/SRR835775_norm.fastq'
cases=[('qwen-t1',q,9,1),('qwen-t4',q,9,4),('fq2-t1',fq,3,1),('fq2-t4',fq,3,4)]
assert all(sha(p)==meta['inputs'][p.name] for _,p,_,_ in cases)
def run(exe, args):
    argv=[str(exe)]+[str(a) for a in args]
    t=time.perf_counter()
    pid=os.posix_spawn(str(exe),argv,os.environ)
    _,rc,ru=os.wait4(pid,0)
    if rc:raise RuntimeError(argv)
    return [time.perf_counter()-t,ru.ru_utime+ru.ru_stime,ru.ru_maxrss]
rng=random.Random(908875); records=[]; hashes={}
with tempfile.TemporaryDirectory(dir=out) as td, (out/'crossover.jsonl').open('w',buffering=1) as fp:
    dest=Path(td)/'output'; frame=Path(td)/'frame'
    for n in range(15):
        for key,p,l,t in rng.sample(cases,len(cases)):
            for arm in rng.sample(list(variants),3):
                exe=paths[arm]
                frame.unlink(missing_ok=True); dest.unlink(missing_ok=True)
                e=run(exe,['--level',l,'-q','-T',t,'-f',p,'-o',frame])
                d=run(exe,['-d','-q','-T',t,'-f',frame,'-o',dest])
                h=sha(frame);assert hashes.setdefault(key,h)==h and sha(dest)==meta['inputs'][p.name]
                r=dict(case=key,pair=n,arm=arm,enc=e,dec=d,frame_sha256=h,source_sha256=meta['inputs'][p.name],stored_bytes=frame.stat().st_size)
                records.append(r);print(json.dumps(r),file=fp)
d={(r['case'],r['pair'],r['arm']):r for r in records}
report={}
def total(k,n,arm,i):return d[k,n,arm]['enc'][i]+d[k,n,arm]['dec'][i]
for k,*_ in cases:
    arr={}
    for label,calculate in [('A/A',lambda a,aa,b:aa/a),('B/A',lambda a,aa,b:b/a),('B/AA',lambda a,aa,b:b/aa),('B/mean(A,AA)',lambda a,aa,b:b/((a+aa)/2))]:
        stats={}
        for m,i in [('wall',0),('cpu',1)]:
            ratios=[calculate(*(total(k,n,arm,i) for arm in ['A','AA','B'])) for n in range(15)]
            stats[m]=dict(median=statistics.median(ratios),slower=sum(r>1 for r in ratios),ratios=ratios)
        arr[label]=stats
    report[k]=arr
(out/'crossover-summary.json').write_text(json.dumps(report,indent=2)+'\n')
