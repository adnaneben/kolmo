# Transfer context A/A and A/B confirmation

Four transfer settings, 15 interleaved trips apiece. A and AA are two fresh invocations of Wave 1; B is Wave 2. In each trip and for each metric, candidate time is divided by the arithmetic mean of the two baseline times. The table displays the median of those ratios minus one. The A/A column is the median of AA divided by A minus one. Both phase costs are included in each timed trip. Input and frame bytes were identical across every arm in a setting.

| Workload and requested threads | Baseline A/A wall | Candidate wall | Candidate CPU | Candidate slower wall trips |
| --- | ---: | ---: | ---: | ---: |
| fq2-t1 | -1.16% | -1.99% | -1.74% | 6/15 |
| fq2-t4 | +0.72% | +0.48% | -1.14% | 8/15 |
| qwen-t1 | +0.75% | -2.66% | -3.26% | 6/15 |
| qwen-t4 | +3.60% | +3.52% | -0.23% | 8/15 |

Report archives include all 180 exact round trips, the randomized run, separate enc/dec wall/CPU/RSS per arm and reference binary provenance in manifest.json. These experiments revisit existing materials on one machine. They are separate from the independent release backport experiment.
