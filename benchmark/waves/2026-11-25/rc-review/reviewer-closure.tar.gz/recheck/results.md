# Specialist and earlier-wave regression recheck

Seven fresh, paired randomized file-to-file comparisons per setting. The numerator is the later arm. Each speed value compares the sum of encode and decode times from one matched trial. The median of paired time ratios and the two independently tabulated wall medians can differ. CPU uses the sum of user and system time in the two subprocesses. The table retains the number of slower paired wall times and the exact two-sided sign-test p-value, conditional on independence of paired signs. They are descriptive on one shared host, with no multiple-comparison adjustment or cross-host inference.

| Context | Pairs | Archive bytes | Combined wall, before → after ms | Paired wall change | Paired CPU change | Slower pairs | Sign p |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| w1-bgl-l2-t1 | 7 | 395,298 | 10.77 → 10.57 | -2.94% | -1.70% | 2 | 0.453 |
| w1-bgl-l3-t1 | 7 | 129,517 | 20.15 → 18.75 | -1.01% | -0.31% | 3 | 1.000 |
| w1-bgl-l3-t4 | 7 | 129,517 | 12.89 → 12.43 | +2.06% | +0.30% | 4 | 1.000 |
| w1-bgl-l6-t1 | 7 | 96,200 | 110.12 → 108.95 | -1.56% | -0.71% | 2 | 0.453 |
| w1-img16-l5-t1 | 7 | 912,606 | 225.69 → 221.69 | -0.05% | +0.59% | 3 | 1.000 |
| w1-img16-l5-t4 | 7 | 912,606 | 143.99 → 149.82 | +0.95% | +0.81% | 5 | 0.453 |
| w2-bf10-l9-t4 | 7 | 6,965,938 | 1725.91 → 1734.77 | -0.16% | -1.95% | 2 | 0.453 |
| w2-bf47-l9-t10 | 7 | 27,186,418 | 5242.86 → 5142.41 | +0.04% | +0.68% | 4 | 1.000 |
| w2-fq-l3-t1 | 7 | 12,597,365 | 217.71 → 210.02 | -1.36% | -1.46% | 3 | 1.000 |
| w2-fq-l3-t10 | 7 | 12,597,365 | 106.18 → 104.55 | -0.75% | -1.33% | 3 | 1.000 |
| w2-fq2-l3-t4 | 7 | 6,581,477 | 66.49 → 66.65 | +3.48% | -1.14% | 4 | 1.000 |
| w2-qwen-l9-t1 | 7 | 1,070,228 | 345.01 → 366.71 | +4.26% | +3.68% | 5 | 0.453 |

A total of 168 encodes and 168 decodes produced the input SHA-256 and the same compressed SHA-256 for all 84 paired comparisons. Original binary SHA-256 identities match the wave manifests. Both historical settings with the largest specialist flags were repeated exactly. Controls change accession, tensor producer and size, or thread count. `one-qwen-bf16.safetensors` is a freshly constructed valid single-tensor container taken from model.layers.0.self_attn.o_proj.weight in the recorded Qwen checkpoint. The project download manifest identifies its 988,097,824-byte Qwen checkpoint by SHA-256 88c142557820ccad55bb59756bfcfcf891de9cc6202816bd346445188a0ed342. This is a previously available engineering transfer control. The replay script identifies the exact tensor and hashes; no training or corpus payload is distributed.

Original exploratory results remain in regression-screen.csv. BGL L1 had a separate existing 15-pair retest in #85. Paired run order, individual phase wall/CPU/RSS and raw/frame hashes remain in rerun.jsonl.
