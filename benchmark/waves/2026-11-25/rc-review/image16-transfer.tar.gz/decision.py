"""Print per-domain Pareto counts, adversarial examples and pass-through effects."""
from pathlib import Path
import collections,csv,sys
rows=list(csv.DictReader((Path(sys.argv[1])/'summary.csv').open()))
for src in sorted({r['source'] for r in rows}):
    for base in ['6','7']:
        rr=[r for r in rows if r['source']==src and r['from']==base]
        if not rr:continue
        values=[float(r['change_pct']) for r in rr]
        speeds=[float(r['speedup']) for r in rr]
        flips=[r for r in rr if int(r['new_bytes'])>int(r['old_bytes'])]
        print(src,base,'n=',len(rr),'byte_regressions=',len(flips),
              'size_delta=',round(min(values),3),round(max(values),3),
              'speed=',round(min(speeds),2),round(max(speeds),2))
        if flips:
            r=max(flips,key=lambda r:float(r['change_pct']))
            print('most adverse',r['fixture'],r['threads'],r['old_bytes'],r['new_bytes'],
                  r['old_plans'],r['new_plans'])
