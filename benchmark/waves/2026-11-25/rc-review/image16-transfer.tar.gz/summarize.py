from pathlib import Path
import csv,statistics,sys,collections
root=Path(sys.argv[1])
cases=collections.defaultdict(lambda:collections.defaultdict(dict))
for r in csv.DictReader((root/'raw.csv').open()):
    cases[(r['source'],r['fixture'],r['threads'])][r['repeat']][int(r['level'])]=r
with (root/'summary.csv').open('w',newline='') as out:
    w=csv.writer(out)
    w.writerow(['source','fixture','threads','from','to','old_bytes','new_bytes','change_pct','speedup','product_gain_pct','wins_total','rounds','old_plans','new_plans'])
    for k,pairs in sorted(cases.items()):
        for base,alt in [(7,3),(6,5)]:
            d=[rec for rec in pairs.values() if base in rec and alt in rec]
            if not d:continue
            b,n=d[0][base],d[0][alt]
            osize,nsize=map(int,(b['frame_n'],n['frame_n']))
            assert all(int(r[base]['frame_n'])==osize and int(r[alt]['frame_n'])==nsize for r in d)
            def duration(rec,l): return sum(float(rec[l][key]) for key in ('encode_ms','decode_ms'))
            ratios=[duration(r,base)/duration(r,alt) for r in d]
            speed=statistics.median(ratios)
            w.writerow([*k,base,alt,osize,nsize,100*(nsize/osize-1),speed,100*((osize/nsize)*speed-1),sum(x>1 for x in ratios),len(d),b['layout_raw_plan_tflag_codec'],n['layout_raw_plan_tflag_codec']])
