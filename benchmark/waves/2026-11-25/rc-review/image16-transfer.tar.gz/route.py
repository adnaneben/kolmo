"""Frozen-route, real image16 transfer test; all temporary files below private workspace."""
import argparse, collections, csv, hashlib, json, os, random, statistics, struct, tempfile, time
from pathlib import Path
p=argparse.ArgumentParser()
for k in ['dataset','dicom','encoder','release','out']: p.add_argument(k,type=Path)
p.add_argument('--repeats',type=int,default=5)
a=p.parse_args()
a.out.mkdir(exist_ok=True)
jobs=[
 ('MR','mr-prefix512k','corpus-holdout/mr',0,512<<10,None),
 ('MR','mr-tail2m','corpus-holdout/mr',5<<20,2<<20,0.5),
 ('MR','mr-prefix4m','corpus-holdout/mr',0,4<<20,None),
 ('XR','xray-prefix512k','corpus/x-ray',0,512<<10,None),
 ('XR','xray-tail2m','corpus/x-ray',5<<20,2<<20,0.5),
 ('XR','xray-prefix4m','corpus/x-ray',0,4<<20,None),
 ('NM','nm-first256k',None,0,256<<10,None),
 ('NM','nm-entire',None,0,a.dicom.stat().st_size,None)]
def timed(cmd):
    st=time.monotonic_ns()
    acts=[(os.POSIX_SPAWN_OPEN,k,os.devnull,os.O_WRONLY,0) for k in (1,2)]
    pid=os.posix_spawn(str(cmd[0]),list(map(str,cmd)),os.environ,file_actions=acts)
    _,status,usage=os.wait4(pid,0)
    elapsed=(time.monotonic_ns()-st)/1e6
    if status:
        raise RuntimeError((status,cmd))
    return elapsed,usage.ru_utime+usage.ru_stime,usage.ru_maxrss
def digest(data): return hashlib.sha256(data).hexdigest()
def plans(frame):
    assert frame[:5]==b'CZN1\x0c'
    cnt,=struct.unpack_from('<I',frame,20); off=32+16*cnt
    res=[]
    for i in range(cnt):
        raw,cn,_,codec,tflag=struct.unpack_from('<III2B',frame,32+16*i)
        res.append(f'{raw}/{frame[off]}/{tflag}/{codec}');off+=cn
    assert off==len(frame)
    return '|'.join(res)
seen={}
with tempfile.TemporaryDirectory(dir=a.out) as directory, (a.out/'raw.csv').open('w',newline='') as out:
    w=csv.writer(out);w.writerow(['source','fixture','input_sha','offset','input_n','block_mib','threads','repeat','order','level','frame_n','frame_sha','layout_raw_plan_tflag_codec','encode_ms','decode_ms','encode_cpu_s','decode_cpu_s','encode_rss','decode_rss','release_checked'])
    tmp=Path(directory); rng=random.Random(811207)
    prepared=[]
    for group,name,rel,offset,n,block in jobs:
        src = (a.dataset/rel if rel else a.dicom)
        with src.open('rb') as f: f.seek(offset); raw=f.read(n)
        assert len(raw)==n
        inp=tmp/name; inp.write_bytes(raw)
        for t in [1,4]: prepared.append((group,name,inp,offset,n,block,t,digest(raw)))
    for repeat in range(a.repeats):
        rng.shuffle(prepared)
        for group,name,inp,offset,n,block,t,sha in prepared:
            levels=[3,5,6,7]; rng.shuffle(levels)
            for order,level in enumerate(levels):
                frame,output=tmp/'frame.kolmo',tmp/'restore'
                ecmd=[a.encoder,f'-{level}',f'-T{t}','-f','-o',frame]
                if block: ecmd.extend(['--block-size',str(block)])
                et,ec,er=timed(ecmd+[inp])
                dt,dc,dr=timed([a.encoder,'-d',f'-T{t}','-f','-o',output,frame])
                assert digest(output.read_bytes())==sha
                fr=frame.read_bytes(); fsha=digest(fr)
                release=fsha not in seen
                if release:
                    timed([a.release,'-d',f'-T{t}','-f','-o',output,frame])
                    assert digest(output.read_bytes())==sha
                    seen[fsha]=sha
                assert seen[fsha]==sha
                w.writerow([group,name,sha,offset,n,block or 'auto',t,repeat,order,level,len(fr),fsha,plans(fr),et,dt,ec,dc,er,dr,int(release)])
            out.flush()
        print(f"completed repeat {repeat}",flush=True)
