#!/usr/bin/env python3
"""Cross-check private stage caching when adjacent members share few parents."""
import csv,hashlib,os,random,shutil,statistics,subprocess,sys,tempfile,time
from pathlib import Path
root=Path(__file__).resolve().parent
baseline,candidate=map(Path,sys.argv[1:3])
rng=random.Random(219967)
def manifest(d):
    return {str(p.relative_to(d)):(hashlib.sha256(p.read_bytes()).hexdigest(),int(p.stat().st_mtime),p.stat().st_mode&511) for p in d.rglob('*') if p.is_file()}
rows=[]
with tempfile.TemporaryDirectory(dir=root) as tmp, (root/'tree.csv').open('w',newline='') as f:
    tmp=Path(tmp);cases=[]
    w=csv.writer(f);w.writerow(['layout','threads','repeat','arm','wall_ns','archive_sha256'])
    for layout in ('alternating','singleton'):
        src=tmp/(layout+'-src');src.mkdir()
        names=[]
        for i in range(64):
            group=i if layout=='singleton' else i%8 if layout=='alternating' else i//8
            name=f'd{group}/file{i:03}';names.append(name)
            p=src/name;p.parent.mkdir(exist_ok=True);p.write_bytes(hashlib.shake_256(str(i).encode()).digest(1024))
            p.chmod(0o640);os.utime(p,(1600000000,1600000000))
        archive=tmp/(layout+'.ddp');subprocess.run([baseline,'archive','-1',archive,*names],cwd=src,check=True)
        for t in (1,4): cases.append((layout,archive,manifest(src),t,hashlib.sha256(archive.read_bytes()).hexdigest()))
    for rep in range(-1,15):
        rng.shuffle(cases)
        for layout,a,expect,t,sha in cases:
            arms=[('PR59',baseline),('AA',baseline),('reuse',candidate)];rng.shuffle(arms)
            for tag,exe in arms:
                dest=tmp/'out';dest.mkdir()
                now=time.perf_counter_ns();subprocess.run([exe,'extract','-T',str(t),'-C',dest,a],check=True)
                elapsed=time.perf_counter_ns()-now
                assert manifest(dest)==expect
                actual={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_dir()}
                assert actual=={str(Path(k).parent) for k in expect}
                w.writerow([layout,t,rep,tag,elapsed,sha]);f.flush()
                rows.append((layout,t,rep,tag,elapsed));shutil.rmtree(dest)
with (root/'tree-summary.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['layout','threads','arm','paired_time_multiplier','slower_pairs','pairs'])
    for layout,_,_,t,_ in sorted(cases,key=lambda x:(x[0],x[3])):
        for target in ('AA','reuse'):
            times=[{r:v for l,k,r,a,v in rows if l==layout and k==t and r>=0 and a==tag} for tag in ('PR59',target)]
            paired=[times[1][i]/v for i,v in times[0].items()]
            w.writerow([layout,t,target,statistics.median(paired),sum(x>1 for x in paired),len(paired)])
