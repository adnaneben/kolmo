"""Collect final per-context outcomes from the original evidence tables."""
import csv
from pathlib import Path
root=Path(__file__).resolve().parent
for filename in ['ungated/repaired-stage-summary.csv','ungated/tree-summary.csv','gated-stage-summary.csv','tree-summary.csv']:
    print(filename)
    with (root/filename).open() as f:
        for r in csv.DictReader(f):
            if 'from_arm' in r and (r['from_arm'], r['to_arm']) != ('PR59','reuse'): continue
            print(' | '.join(str(x) for x in r.values()))
