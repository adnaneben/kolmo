"""Four fixed block boundaries, one vs four actual workers, for all observed sign flips."""
from concurrent.futures import ThreadPoolExecutor
import csv
import hashlib
import io
import json
import os
import subprocess
import sys
from pathlib import Path
from replay import FIELDS

exe, folder, dest = Path(sys.argv[1]).resolve(), Path(sys.argv[2]), Path(sys.argv[3])
env = {**os.environ, "KOLMO_CPU": "c"}
names = ["dev/json__api","holdout/json__gharchive","holdout/log__nasa"]
def one(task):
    path, offset, block_size = task
    with path.open("rb") as stream:
        stream.seek(offset)
        sha = hashlib.sha256(stream.read(block_size)).hexdigest()
    output = subprocess.check_output([str(exe),str(path),str(offset),str(block_size)],env=env,text=True)
    rows = list(csv.DictReader(io.StringIO(output),fieldnames=FIELDS))
    return {"offset":offset,"sha256":sha,"base_bytes":int(rows[0]["payload_bytes"]),
            "candidate_bytes":int(rows[1]["payload_bytes"]),
            "candidate_log_bits":[rows[1][f"{k}_ideal_bits"] for k in ("none","weak","medium","strong")]}
with dest.open("w",buffering=1) as out:
    for f in names:
        for n in (16<<10,64<<10):
            tasks=[(folder/f,(256<<10)+i*n,n) for i in range(4)]
            control=None
            for workers in (1,4):
                with ThreadPoolExecutor(max_workers=workers) as ex: rows=list(ex.map(one,tasks))
                if workers == 1: control=rows
                elif rows != control: raise RuntimeError("worker count influenced result")
                print(json.dumps(dict(file=f,block_bytes=n,physical_worker_limit=workers,
                                      base=sum(r["base_bytes"] for r in rows),
                                      candidate=sum(r["candidate_bytes"] for r in rows),
                                      blocks=rows)),file=out)
