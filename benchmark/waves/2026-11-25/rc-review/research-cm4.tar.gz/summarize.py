import collections
import csv
import json
import sys
from pathlib import Path
root = Path(sys.argv[1])
rows = [json.loads(line) for name in ("results.jsonl","fresh.jsonl") for line in (root/name).read_text().splitlines()]
groups=collections.defaultdict(list)
for row in rows:
    groups[row["split"],row["file"],row["layout"]].append(row)
fields=["split","file","layout","n","control","candidate","saved","gain_pct","allowed_time_pct","coverage_pct","strong_bits_pct","no_weak_bits_pct","source_no_weak_pct","observed_core_cpu_delta_pct"]
out=[]
for (split,file,layout),batch in groups.items():
    sums=[]
    for arm in (0,1):
        rs=[x for x in batch if x["arm"]==arm]
        sums.append({key:sum(x[key] for x in rs) for key in rs[0] if isinstance(rs[0][key],(int,float))})
    base,candidate=sums
    n=base["source_bytes"]
    b=base["payload_bytes"]; c=candidate["payload_bytes"]
    total_bits=sum(base[x+"_ideal_bits"] for x in ("none","weak","medium","strong"))
    weak=base["none_ideal_bits"]+base["weak_ideal_bits"]
    out.append(dict(split=split,file=file,layout=layout,n=n,control=b,candidate=c,saved=b-c,gain_pct=100*(1-c/b),
                    allowed_time_pct=100*(b/c-1),coverage_pct=100*candidate["eligible"]/n,
                    strong_bits_pct=100*base["strong_ideal_bits"]/total_bits,
                    no_weak_bits_pct=100*weak/total_bits,
                    source_no_weak_pct=100*(base["none_source_bytes"]+base["weak_source_bytes"])/n,
                    observed_core_cpu_delta_pct=100*((candidate["enc_cpu_s"]+candidate["dec_cpu_s"])/(base["enc_cpu_s"]+base["dec_cpu_s"])-1)))
with (root/"summary.csv").open("w") as stream:
    w=csv.DictWriter(stream,fieldnames=fields); w.writeheader(); w.writerows(out)
