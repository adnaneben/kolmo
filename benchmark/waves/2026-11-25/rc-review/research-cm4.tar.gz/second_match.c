/* Standalone research harness. No alternate bytes enter a Kolmo archive. */
#include "kolmo.c"
#include <time.h>

enum { SLOTS = 65536, CLASSES = 64, SCALE = 4096 };
typedef struct {
    uint32_t positions[SLOTS];
    uint16_t weights[CLASSES];
    uint64_t eligible, prefix_bits, class_bytes[4];
    double class_bits[4];
} research_state;

static double loss_table[SCALE];
static double cpu_seconds(void) { return (double)clock() / CLOCKS_PER_SEC; }

static int sparse_byte(research_state *state, const cm_t *m) {
    const uint8_t *data = m->buf;
    size_t i = (size_t)m->pos;
    if (i < 7) return -1;
    uint32_t key = 2166136261u;
    for (int d = 7; d >= 1; --d)
        if (d != 4) key = (key ^ data[i - d]) * 16777619u;
    unsigned slot = cm_hmix(key) & (SLOTS - 1u);
    size_t previous = state->positions[slot];
    state->positions[slot] = (uint32_t)i;
    if (!previous || m->mlen >= 16) return -1;
    for (int d = 7; d >= 1; --d)
        if (d != 4 && data[i-d] != data[previous-d]) return -1;
    int value = data[previous];
    if (m->mlen && value == data[m->mptr]) return -1;
    ++state->eligible;
    return value;
}

static int blend(research_state *state, int base, int guess, int bit,
                 int live, int *class_id, int *strong) {
    int suggested = (guess >> bit) & 1;
    int confidence = suggested ? base : SCALE - base;
    int boosted = (4 * confidence * SCALE) / (3 * SCALE + confidence);
    if (boosted >= SCALE) boosted = SCALE - 1;
    if (boosted < 1) boosted = 1;
    *strong = suggested ? boosted : SCALE - boosted;
    *class_id = (live * 8 + bit) * 4 + confidence / 1024;
    int w = state->weights[*class_id];
    ++state->prefix_bits;
    return ((SCALE-w) * base + w * *strong + SCALE/2) / SCALE;
}

static void learn(research_state *s, int cls, int p0, int p1, int y) {
    int a = y ? p0 : SCALE-p0, b = y ? p1 : SCALE-p1;
    uint64_t w = s->weights[cls];
    uint64_t z = (SCALE-w) * a + w * b;
    unsigned update = (unsigned)((SCALE*w*b + z/2) / z);
    s->weights[cls] = update < 16 ? 16 : update > SCALE-16 ? SCALE-16 : update;
}

/* A stream payload is only accessed in-process. The class accounting at byte start
   uses CM4 state before any current bit is read. */
static size_t process(const uint8_t *original, uint8_t *packed, size_t capacity,
                      uint8_t *history, size_t n, int arm, int decode,
                      research_state *state, int collect) {
    uint32_t mask = CM4_MASK_TEXT;
    cm_t *m = cm_new_xm(history, cm4_shift_for(n, mask), 4, cm4_chain(n), 1, mask, n);
    if (!m) return 0;
    cm_tune_t tune = cm4_tune;
    tune.b2 = cm4_prior_for(mask);
    cm_set_tune(m, tune);
    memset(state, 0, sizeof *state);
    for (int i = 0; i < CLASSES; ++i) state->weights[i] = SCALE/2;
    cm_ac ac = {0, UINT32_MAX};
    uint32_t code = 0;
    size_t j = 0;
    if (decode) {
        if (capacity < 4) goto fail;
        for (int k = 0; k < 4; ++k) code = (code << 8) | packed[j++];
    }
    for (size_t i = 0; i < n; ++i) {
        int guess = arm ? sparse_byte(state, m) : -1;
        int live = !!m->mlen, band = !live ? 0 : m->mlen < 16 ? 1 : m->mlen < 64 ? 2 : 3;
        ++state->class_bytes[band];
        for (int bit = 7; bit >= 0; --bit) {
            int p0 = cm_predict(m, 4), cls = -1, strong = 0;
            int p = guess < 0 ? p0 : blend(state, p0, guess, bit, live, &cls, &strong);
            uint32_t mid = cm_ac_mid(&ac, p);
            int y = decode ? code <= mid : ((original[i] >> bit) & 1);
            if (collect) state->class_bits[band] += loss_table[y ? p : SCALE-p];
            if (y) ac.high = mid; else ac.low = mid + 1;
            if (cls >= 0) {
                learn(state, cls, p0, strong, y);
                if (((guess >> bit) & 1) != y) guess = -1;
            }
            cm_update(m, y, 4);
            for (; cm_ac_settled(&ac); cm_ac_shift(&ac)) {
                if (j >= capacity) goto fail;
                if (decode) code = (code << 8) | packed[j++];
                else packed[j++] = (uint8_t)(ac.high >> 24);
            }
        }
    }
    if (!decode) {
        if (capacity-j < 4) goto fail;
        packed[j++] = (uint8_t)(ac.low >> 24);
        memset(packed+j, 255, 3);
        j += 3;
    }
    cm_free(m);
    return j;
fail:
    cm_free(m);
    return 0;
}

int main(int argc, char **argv) {
    if (argc != 4) return 2;
    size_t offset = (size_t)strtol(argv[2], NULL, 10);
    size_t n = (size_t)strtol(argv[3], NULL, 10);
    if (n < 64 || n > (1u<<24)) return 2;
    FILE *f = fopen(argv[1], "rb");
    if (!f || fseek(f, (long)offset, SEEK_SET)) return 3;
    size_t capacity = 2*n + 32;
    uint8_t *data = malloc(n), *out = malloc(n+8), *packed = malloc(capacity), *native = malloc(capacity);
    research_state *s = malloc(sizeof *s);
    if (!data || !out || !packed || !native || !s || fread(data, 1, n, f) != n) return 4;
    fclose(f);
    for (int k = 1; k < SCALE; ++k) loss_table[k] = -log2((double)k / SCALE);
    size_t stock = cm_compress_raced(data, n, native, capacity, 4, 0, 1, CM4_MASK_TEXT);
    if (!stock) return 5;
    for (int arm = 0; arm < 2; ++arm) {
        double start = cpu_seconds();
        size_t z = process(data, packed, capacity, out, n, arm, 0, s, 1);
        double enc = cpu_seconds()-start;
        if (!z || (!arm && (z+12 != stock || memcmp(packed, native+12, z)))) return 6;
        uint64_t eligible = s->eligible, prefix_bits = s->prefix_bits;
        double bits[4]; memcpy(bits, s->class_bits, sizeof bits);
        memset(out, 0x5a, n+8);
        start = cpu_seconds();
        size_t used = process(NULL, packed, z, out, n, arm, 1, s, 0);
        double dec = cpu_seconds()-start;
        if (used != z || memcmp(data,out,n)) return 7;
        printf("%d,%zu,%llu,%llu,%.6f,%.6f",arm,z,(unsigned long long)eligible,
               (unsigned long long)prefix_bits,enc,dec);
        for (int i=0;i<4;i++) printf(",%llu,%.4f",(unsigned long long)s->class_bytes[i],bits[i]);
        putchar('\n');
    }
    free(data); free(out); free(native); free(packed); free(s);
    return 0;
}
