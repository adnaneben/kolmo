#!/usr/bin/env python3
"""Measure independent CM4 raw payloads; KOLMO_CPU=c is fixed across both arms."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess

CASES = {
    "dev": ["dev/code__flac-c", "dev/json__api", "dev/text__dickens"],
    "transfer": ["holdout/code__py-stdlib", "holdout/text__reymont",
                 "holdout/html__bashref", "holdout/json__gharchive",
                 "holdout/log__bgl", "holdout/log__nasa", "holdout/xml__enwik8"],
}
FIELDS = ["arm", "payload_bytes", "eligible", "active_bits", "enc_cpu_s", "dec_cpu_s"]
for band in ("none", "weak", "medium", "strong"):
    FIELDS += [f"{band}_source_bytes", f"{band}_ideal_bits"]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("exe", type=Path)
    parser.add_argument("corpus", type=Path)
    parser.add_argument("out", type=Path)
    args = parser.parse_args()
    env = {**os.environ, "KOLMO_CPU": "c"}
    with args.out.open("w", buffering=1) as dest:
        for split, files in CASES.items():
            for filename in files:
                path = args.corpus / filename
                # Same 256 KiB span for one-block and four-block comparisons.
                # Start at 256 KiB to omit repeat file headers across dev/transfer.
                start = 256 << 10
                layouts = [("64k", 64 << 10, [start]), ("256k", 256 << 10, [start]),
                           ("four64k", 64 << 10, [start + k*(64 << 10) for k in range(4)])]
                for layout, n, offsets in layouts:
                    for block, off in enumerate(offsets):
                        with path.open("rb") as f:
                            f.seek(off)
                            digest = hashlib.sha256(f.read(n)).hexdigest()
                        output = subprocess.check_output([str(args.exe.resolve()), str(path),
                                                          str(off), str(n)], env=env, text=True)
                        for r in csv.DictReader(io.StringIO(output), fieldnames=FIELDS):
                            row = {k: float(v) if "cpu" in k or "ideal" in k else int(v)
                                   for k, v in r.items()}
                            row.update(split=split,file=filename,layout=layout,block=block,
                                       offset=off,source_bytes=n,sha256=digest,roundtrip=True)
                            print(json.dumps(row), file=dest)
if __name__ == "__main__":
    main()
