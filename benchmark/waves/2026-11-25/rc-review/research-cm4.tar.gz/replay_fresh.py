#!/usr/bin/env python3
"""Use producer-disjoint machine-supplied inputs after pinning whole-file hashes."""
import hashlib
import sys
from pathlib import Path
import replay

spec = {
    "usr/share/dict/web2": "be41ad97963bf8dabedd5871d5d691596175269d540956b0f9965a885c2bbab9",
    "Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sqlite3.h": "08e576e228c73762fe31d6db3aa9fb445be8a4cd7ad9ba7d872c3df984bdcdaa",
}
for name, digest in spec.items():
    if hashlib.sha256((Path(sys.argv[2]) / name).read_bytes()).hexdigest() != digest:
        raise ValueError(f"unexpected file content for {name}")
replay.CASES = {"fresh": list(spec)}
replay.main()
