.section .text.boot,"ax"
.code32
.align 4
header:
.long 0x1badb002,0x00010000,-(0x1badb002+0x10000)
.long header,0x100000,data_end,mem_end,start
start:
    cli
    mov $stack_end,%esp
    mov %cr4,%eax
    or $0x20,%eax
    mov %eax,%cr4
    mov $pdpt,%eax
    or $3,%eax
    mov %eax,pml4
    mov $pd,%eax
    or $3,%eax
    mov %eax,pdpt
    movl $0x83,pd
    mov $pml4,%eax
    mov %eax,%cr3
    mov $0xc0000080,%ecx
    rdmsr
    or $0x100,%eax
    wrmsr
    lgdt gdtr
    mov %cr0,%eax
    or $0x80000001,%eax
    mov %eax,%cr0
    ljmp $8,$long_start
.code64
long_start:
    mov $16,%ax
    mov %ax,%ds
    mov %ax,%es
    mov %ax,%ss
    mov $stack_end,%esp
    mov $66,%al
    out %al,$0xe9
    call parity
    mov %eax,%ebx
    add $80,%al
    out %al,$0xe9
    mov %ebx,%eax
    out %eax,$0xf4
    hlt
.balign 8
gdt:
    .quad 0,0x00af9a000000ffff,0x00cf92000000ffff
gdtr:
    .word 23
    .long gdt
.section .bss,"aw",@nobits
.balign 4096
pml4: .skip 4096
pdpt: .skip 4096
pd: .skip 4096
.skip 32768
stack_end:
