SECTIONS {
 . = 0x100000;
 .text : { *(.text.boot) *(.text*) }
 .rodata : { *(.rodata*) }
 .data : { *(.data*) }
 data_end = .;
 .bss : { *(.bss*) *(COMMON) }
 mem_end = .;
 /DISCARD/ : { *(.note*) *(.comment*) *(.eh_frame*) }
}
