typedef unsigned long u64;
typedef unsigned char byte;
extern u64 kolmo_gear_x86_64(const byte *, u64, const u64 *, u64, u64 *);
static u64 seed=0x32946471ad33feull;
static u64 random64(void) {seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;return seed;}
int parity(void) {
    u64 table[256],masks[]={0,1,3,0x85,~0ull,0x912a507100000000ull,0x8124508124400000ull};
    byte data[272];
    for(int i=0;i<256;i++)table[i]=random64();
    for(int i=0;i<272;i++)data[i]=(byte)random64();
    for(int a=0;a<16;a++)for(int n=0;n<=256;n++)for(int m=0;m<7;m++) {
        u64 h=random64(),got=h,cut=0;
        for(int i=0;i<n;i++){h=2*h+table[data[i+a]];if(!(h&masks[m])){cut=i+1;break;}}
        if(kolmo_gear_x86_64(data+a,n,table,masks[m],&got)!=cut || got!=h)return 2;
    }
    return 0;
}
