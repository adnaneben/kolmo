#!/bin/sh
# Run from the extracted receipt, passing the absolute repository path.
# Requires clang, ld.lld and qemu-system-x86_64. Override paths as needed.
set -eu
repo=$1
cc=${CLANG:-clang}
lld=${LLD:-ld.lld}
qemu=${QEMU:-qemu-system-x86_64}
"$cc" -target x86_64-unknown-none-elf -c -ffreestanding -mno-sse -mno-red-zone -fno-stack-protector -O2 check.c -o check.o
"$cc" -target x86_64-unknown-none-elf -c boot.S -o boot.o
sed 's/leaq (%r10,%r9,4)/leaq (%r10,%r9,2)/' "$repo/src/arch/x86_64/gear_x86_64.S" > broken.S
for variant in pass fail; do
    file="$repo/src/arch/x86_64/gear_x86_64.S"
    if [ "$variant" = fail ]; then file=broken.S; fi
    "$cc" -target x86_64-unknown-none-elf -I"$repo/src/arch/x86_64" -c "$file" -o scan.o
    "$lld" -m elf_x86_64 --oformat=binary -T link.ld -o guest.bin boot.o check.o scan.o
    # UTM's embeddable runner can return zero, standalone QEMU uses debug-exit
    # status. The guest marker is emitted immediately after both comparisons.
    "$qemu" -M pc,accel=tcg -cpu qemu64 -m 32M -display none -nodefaults -nic none -serial none -monitor none -no-reboot -device isa-debug-exit,iobase=0xf4,iosize=4 -debugcon file:"$variant.txt" -kernel guest.bin || true
    case "$variant" in pass) test "$(cat pass.txt)" = BP;; fail) test "$(cat fail.txt)" = BR;; esac
done
