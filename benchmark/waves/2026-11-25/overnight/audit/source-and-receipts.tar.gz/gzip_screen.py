"""Three development members and deterministic first four files per installed-manpage producer."""
import csv, gzip, hashlib, io, os, pathlib, random, statistics, sys, time, zlib
from gzip_recipe import codec, encode, decode, sha, MAGIC
apath=pathlib.Path(sys.argv[1]); historical=pathlib.Path(sys.argv[2]);out=pathlib.Path(sys.argv[3])
jobs=[('development',p.name,p.read_bytes()) for p in (historical/x for x in ['dickens.6.gz','xml.9.gz','osdb.1.gz'])]
for tag,root in [('system-man','/usr/share/man/man1'),('brew-man','/opt/homebrew/share/man/man1')]:
    for p in sorted(pathlib.Path(root).glob('*.gz'))[:4]:
        jobs.append((tag,p.name,p.read_bytes()))
# Transfer controls: members with metadata, wrong hint, trailing bytes,
# concatenation, incompressible interior, already-small file.
payload=(b'2026: signal temperature 273.15 pressure 730 humidity 77.80\n'*1024)
fg=io.BytesIO()
with gzip.GzipFile('forecast.log','wb',fileobj=fg,compresslevel=6,mtime=1764000000) as f:f.write(payload)
named=fg.getvalue()
for tag,d in [('fname+mtime',named),('concatenated',named+named),('wrong_hint',named[:8]+b'\x04'+named[9:]),
              ('trailing',named+b'extra'),('tiny',gzip.compress(b'x',mtime=0)),('noise',gzip.compress(random.Random(123).randbytes(8192),mtime=0))]:
    jobs.append(('control',tag,d))
rows=[]
rng=random.Random(20261125)
for split,name,d in jobs:
    for repeat in range(3):
        order=['main','recipe'];rng.shuffle(order)
        for arm in order:
            t=time.perf_counter()
            if arm=='main': frame,reason=codec(apath,'e',d),'baseline'
            else: frame,reason=encode(apath,d)
            e=time.perf_counter()-t
            t=time.perf_counter();back=decode(apath,frame) if arm=='recipe' else codec(apath,'d',frame);dec=time.perf_counter()-t
            assert back==d
            rows.append(dict(split=split,name=name,repeat=repeat,arm=arm,reason=reason,input_bytes=len(d),stored_bytes=len(frame),
                input_sha256=sha(d).hex(),frame_sha256=sha(frame).hex(),encode_s=e,decode_s=dec,combined_MB_s=len(d)/(e+dec)/1e6,
                zlib_runtime=zlib.ZLIB_RUNTIME_VERSION,restore_sha256=sha(back).hex()))
with out.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
