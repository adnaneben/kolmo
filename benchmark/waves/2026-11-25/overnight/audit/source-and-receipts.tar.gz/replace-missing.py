"""Independent verification for the two first-run reviewers missing final reports."""
import argparse, gzip, hashlib, json, os, pathlib, shutil, subprocess, tempfile

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(args, cwd=None, data=None):
    return subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          cwd=cwd, input=data, check=True).stdout

def archive(cli, source, names, dest, scratch):
    run([cli, 'archive', '-3', '-T', '1', dest, *names], cwd=source)
    with tempfile.TemporaryDirectory(dir=scratch) as out:
        run([cli, 'extract', '-T', '1', '-C', out, dest])
        restored = {p.name: sha(p.read_bytes()) for p in pathlib.Path(out).rglob('*') if p.is_file()}
    expected = {k:sha((source/k).read_bytes()) for k in names}
    if restored != expected:
        raise RuntimeError('archive member or content mismatch')
    return {'archive_bytes': dest.stat().st_size, 'archive_sha256': sha(dest.read_bytes()), 'files':expected}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('cli',type=pathlib.Path)
    ap.add_argument('assessor_work',type=pathlib.Path)
    args=ap.parse_args()
    receipts={'binary_sha256':sha(args.cli.read_bytes()), 'source':'a1d39559686a9ec17c8614b9154a64d7b5b98672', 'R11':[], 'R13':[]}
    with tempfile.TemporaryDirectory() as d:
        temp=pathlib.Path(d)
        for group in ['ssh-4k','hadoop-4k','openstack-4k','samba-c','samba-html']:
            source=args.assessor_work/'assess-R11'/'sets'/group
            files=sorted(f.name for f in source.iterdir() if f.is_file())
            rest=files[len(files)//2:]; selected=rest[::max(1,len(rest)//24)][:24]
            with tempfile.TemporaryDirectory(dir=temp) as rd:
                root=pathlib.Path(rd)
                merged=archive(args.cli,source,selected,root/'batch',root)
                singles=[archive(args.cli,source,[n],root/f'single{i}',root) for i,n in enumerate(selected)]
            receipts['R11'].append({'group':group,'level':3,'threads':1,'members':len(selected),
                'raw_bytes':sum((source/n).stat().st_size for n in selected),'single_archive_bytes':sum(r['archive_bytes'] for r in singles),
                'batch_archive_bytes':merged['archive_bytes'],'batch_receipt':merged,'single_archive_sha256':[r['archive_sha256'] for r in singles]})
        source=args.assessor_work/'assess-R13'/'data'
        for filename in ['dickens.6.gz','xml.9.gz','osdb.1.gz']:
            packed=(source/filename).read_bytes()
            plain=gzip.decompress(packed)
            if plain != (source/filename.split('.')[0]).read_bytes():
                raise RuntimeError('original pair mismatch')
            row={'file':filename,'gzip_bytes':len(packed),'gzip_sha256':sha(packed),'plain_bytes':len(plain),'plain_sha256':sha(plain),'level':5,'threads':1}
            for tag,dat in [('gzip',packed),('plain',plain)]:
                stream=run([args.cli,'-5','-T','1','-c'],data=dat)
                restored=run([args.cli,'-d','-T','1','-c'],data=stream)
                assert restored==dat
                row[tag+'_kolmo_bytes']=len(stream);row[tag+'_kolmo_sha256']=sha(stream)
            repacked=gzip.compress(plain,compresslevel=int(filename.split('.')[1]),mtime=0)
            row['ordinary_gzip_reencoding_sha256']=sha(repacked)
            row['ordinary_gzip_reencoding_identical']=repacked==packed
            receipts['R13'].append(row)
    print(json.dumps(receipts,indent=2))
if __name__=='__main__':
    main()
