"""Validate archived per-trial identities, pairing and phase fields against the named source manifests."""
import collections,hashlib,json,pathlib,re,statistics,sys
d=pathlib.Path(sys.argv[1])
out=[]
for n in (1,2):
    man=json.loads((d/f'wave{n}.manifest.json').read_text())
    rows=[json.loads(l) for l in (d/f'wave{n}.jsonl').read_text().splitlines()]
    keys=set();group=collections.defaultdict(list)
    for r in rows:
        key=(r['input'],r['level'],r['threads'],r['arm'],r['repeat'])
        assert key not in keys and r['input_sha256']==man['inputs'][r['input']] and re.fullmatch('[a-f0-9]{64}',r['frame_sha256'])
        assert r['arm'] in man['binaries'] and all(r[p]['wall_s']>0 and r[p]['rss_bytes']>0 for p in ['enc','dec'])
        keys.add(key);group[key[:3]].append(r)
    assert all(len(x)==6 and len({r['frame_sha256'] for r in x})==1 and len({r['stored_bytes'] for r in x})==1 and sorted(r['repeat'] for r in x)==[0,0,1,1,2,2] for x in group.values())
    out.append({'wave':n,'settings':len(group),'trials':len(rows),'inputs':len(set(r['input'] for r in rows)),
                'input_thread_combinations':len(set((r['input'],r['threads']) for r in rows)),'preset_thread_counts':sorted(set(r['threads'] for r in rows)), 'levels':sorted(set(r['level'] for r in rows)),'receipt_sha256':hashlib.sha256((d/f'wave{n}.jsonl').read_bytes()).hexdigest(),
                'source_manifest_sha256':hashlib.sha256((d/f'wave{n}.manifest.json').read_bytes()).hexdigest(),'bench_script_matches_manifest':man['bench_sha256']==hashlib.sha256((d/'wave-replay.py').read_bytes()).hexdigest()})
print(json.dumps(out,indent=2))
