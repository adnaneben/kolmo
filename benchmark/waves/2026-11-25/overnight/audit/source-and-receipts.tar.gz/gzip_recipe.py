"""Research-only byte-exact single-member gzip recipe. Outputs require this wrapper.

A normal Kolmo frame is the fallback. KGR1 is a separate experimental wire
format containing a stock frame of the inflated bytes, a gzip header, original
digest, original length, level, and exact zlib runtime version. No installed
decoder changes. A build which reproduces different bytes fails the digest.
"""
import argparse, binascii, hashlib, pathlib, struct, subprocess, tempfile, zlib
MAGIC=b'KGR1'
LIMIT=32<<20
PREFIX=struct.Struct('<4sBBII32s')

def sha(b):
    return hashlib.sha256(b).digest()

def codec(cli, mode, data):
    args=[str(cli), '-T', '1', '-c', '-d' if mode=='d' else '-5']
    if mode!='d':
        return subprocess.run(args,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
    if len(data)>LIMIT+65536:raise ValueError('frame cap exceeded')
    with tempfile.TemporaryFile() as source:
        source.write(data);source.seek(0)
        with subprocess.Popen(args,stdin=source,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL) as proc:
            try:
                buf=proc.stdout.read(LIMIT+1)
                if len(buf)>LIMIT:raise ValueError('decoded byte cap exceeded')
                if proc.wait():raise ValueError('stock decoder rejected input')
                return buf
            finally:
                if proc.poll() is None: proc.kill()

def unpack_gzip(data):
    if len(data)<18 or data[:3]!=b'\x1f\x8b\x08' or data[3]&0xe0:return None
    i=10
    if data[3]&4:
        if i+2>len(data)-8:return None
        i+=2+int.from_bytes(data[i:i+2],'little')
    for flag in [8,16]:
        if data[3]&flag:
            pos=data.find(b'\0',i,min(65537,len(data)-8))
            if pos<0:return None
            i=pos+1
    if data[3]&2:i+=2
    if i>65536 or i>=len(data)-8:return None
    try:
        d=zlib.decompressobj(31); raw=d.decompress(data,LIMIT+1)
    except zlib.error:
        return None
    if len(raw)>LIMIT or not d.eof or d.unused_data or d.unconsumed_tail:return None
    return data[:i],raw

def reassemble(h,raw,level):
    c=zlib.compressobj(level,wbits=-15)
    return h+c.compress(raw)+c.flush()+struct.pack('<II',binascii.crc32(raw),len(raw))

def encode(cli,data):
    if len(data)>LIMIT:raise ValueError('research input cap exceeded')
    baseline=codec(cli,'e',data)
    decoded=unpack_gzip(data)
    if not decoded:return baseline,'fallback: ineligible'
    h,raw=decoded
    # One indicated setting per file; the header gives only a hint.
    level={2:9,4:1}.get(data[8],6)
    if reassemble(h,raw,level)!=data:return baseline,'fallback: recompression differs'
    ver=zlib.ZLIB_RUNTIME_VERSION.encode('ascii')
    wrapped=PREFIX.pack(MAGIC,level,len(ver),len(h),len(data),sha(data))+ver+h+codec(cli,'e',raw)
    return (wrapped,'recipe') if len(wrapped)<len(baseline) else (baseline,'fallback: size')

def decode(cli,frame):
    if not frame.startswith(MAGIC):return codec(cli,'d',frame)
    if len(frame)<PREFIX.size:raise ValueError('truncated recipe')
    _,lv,nv,nh,norig,digest=PREFIX.unpack(frame[:PREFIX.size])
    i=PREFIX.size
    if lv not in (1,6,9) or not 10<=nh<=65536 or norig>LIMIT or i+nv+nh>=len(frame):raise ValueError('invalid recipe')
    if frame[i:i+nv]!=zlib.ZLIB_RUNTIME_VERSION.encode('ascii'):raise ValueError('zlib runtime mismatch')
    i+=nv
    raw=codec(cli,'d',frame[i+nh:])
    if len(raw)>LIMIT:raise ValueError('inflated size exceeds experiment cap')
    original=reassemble(frame[i:i+nh],raw,lv)
    if len(original)!=norig or sha(original)!=digest:raise ValueError('original could not be reconstructed')
    return original

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('action',choices=['encode','decode']);ap.add_argument('kolmo',type=pathlib.Path)
    ap.add_argument('input',type=pathlib.Path);ap.add_argument('output',type=pathlib.Path)
    args=ap.parse_args()
    with args.input.open('rb') as f:data=f.read(LIMIT+65537)
    if len(data)>LIMIT+65536:raise ValueError('experiment input cap exceeded')
    out=encode(args.kolmo,data)[0] if args.action=='encode' else decode(args.kolmo,data)
    with args.output.open('xb') as f:f.write(out)
