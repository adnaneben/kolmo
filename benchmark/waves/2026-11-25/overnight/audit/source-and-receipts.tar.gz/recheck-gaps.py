"""Reopen original A/B scopes without an implementation citation and locate current source for each."""
import csv,hashlib,pathlib,subprocess,sys
src=pathlib.Path(sys.argv[1])
# Scope, target document/source and a concrete acceptance test for each outstanding ledger item.
items = [
('A25 B37','src/core/pool.c','Across 1→T→1 calls, measure helper wakeups, returned bytes, CPU, RSS after trim and fork correctness before changing pool lifetime.'),
('A27 B12 B53','src/core/memory.c','Compare v1 and v2 leaf, nested parent and mount-root headroom in real Linux cgroups, including one-job progress. macOS cannot validate Linux accounting.'),
('A29 B14','src/arch/cpu.h','Independently count actual scalar, SSE and AVX execution for decimal, graph, word and CRC. Compare emitted streams with the scalar reference and test on native x86.'),
('A30','src/experimental/krc_cli.c','Compare equivalent CPU and GPU paths with device startup, transfers, compute and full stock decoder recovery charged.'),
('A32','integration/hdf5/tests/test_h5py.py','Use independently installed wheels and plugins across HDF5, Blosc2 and Zarr. Run actual read/write round trips and inspect shared library versions.'),
('A38 B17','src/plan/target.c','For held-out inputs compare returned solution with exhaustive feasible choices and report unattainable floors; count failed trials in CPU and RSS.'),
('B21','src/transforms/x86.c','Measure x86 branch scan against existing e8e9 path on native x86 code and data controls, with identical final frames.'),
('B23','src/plan/meta.c','Preserve exact original Wasm encodings; test a section-aware candidate on two producers and compare header plus payload and fallback.'),
('B24','src/transforms/graph.c','Pin disjoint tensor/checkpoint families; compare whole-model stored bytes and E+D against stock and a matched ZipNN pipeline.'),
('B25','bench/repro/panel.py','Retest OpenZL typed integers at levels 6/7/9 with learned and training-free runs separate, counting model bytes and full decode.'),
('B26','src/plan/planner.c','Replay the selected candidate and its alternatives on the same offsets and complete framed file; measure selection regret including probe cost.'),
('B27','src/plan/meta.c','Collect genuine independent KV-cache pages first; include header and lookup cost, page-read amplification and identical reconstruction.'),
('B29','src/algo/klz.c','Compare repeated-byte fills versus current match copy on native run-heavy and unrelated inputs; verify output and measure the whole CLI.'),
('B30','src/codecs/fastq.c','Use disjoint sequencing runs with quality shifts and stable controls. Compare read-aligned job sizing, phase latency and final archive bytes.'),
('B33','src/transforms/graph.c','Measure peak live bytes of successful, valid supported graphs, including retained views and decimal scratch, under a documented limit.'),
('B35','src/algo/krans.c','Benchmark setup versus decode cost from tiny to large valid rANS blocks. Verify tables, decoded bytes, full-file crossover and fallback.'),
('B36','src/algo/klz.c','Compare current classify/pass cost with cached hashes or exact reciprocal remainder on real content and negative controls; ensure same frames.'),
('B40','src/transforms/table.c','Include no-group as a candidate. Test complete stored CSV sizes, sampled group regret and exact rows on independent producers.'),
('B44','src/core/stream.c','Measure owned compressed-member buffers on valid seekable and pipe inputs. Keep codec scratch, caller storage, process RSS and optional spill accounting separate.'),
('B46','src/api/api.c','Compare public size bound with all supported settings and checked representation limits; include small blocks, metadata-split files and memory-limited round trips.'),
('B50','src/transforms/graph_typed.c','Verify dtype, endian and shape on independent rank-1 NPY producers and eligible Arrow columns; verify original container bytes, NaN payloads and signed zero.'),
('B52','src/core/pool.c','Measure retained capacity and peak RSS after alternating large and small successful calls; compare reuse/trim costs, faults and subsequent latencies.'),
('B56','Makefile','Build and run the ordinary memory API and frozen-frame subset on a real Windows UCRT runner; preserve explicit platform exclusions.'),
('B57','src/kolmo.h','Build a memory-only single-thread wasm32 reader; prove same known v12 outputs in two JS engines with bounded memory.'),
('B59','src/core/stream.c','Retained first-segment pack already covers 504 exact trials. Reject the broad small-first default and retain separate first-byte/first-prefix/total measurements.'),
('B60','Makefile','Audit named resource-failure injection and cleanup on documented valid capped inputs across entry points, retaining distinct per-site results.'),
]
hist={r['lane']:r for r in csv.DictReader(open('assignment-audit.csv'))}
rows=[]
for ids,p,gate in items:
    blob=(src/p).read_bytes()
    for lane in ids.split():
        rows.append(dict(lane=lane,topic=hist[lane]['topic'],current_source=p,current_source_sha256=hashlib.sha256(blob).hexdigest(),disposition='reopened for qualification' if lane!='B59' else 'negative experiment located',concrete_gate=gate))
without={lane for lane,r in hist.items() if lane[0] in 'AB' and not r['linked_pr_status']}
assert without=={r['lane'] for r in rows} and len(rows)==len(without)
with open('reopened-gates.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(sorted(rows,key=lambda r:r['lane']))
