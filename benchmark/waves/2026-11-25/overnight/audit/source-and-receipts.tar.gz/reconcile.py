"""Independently reconcile immutable #91 ledgers against original reports, receipts, PRs and source paths."""
import argparse, collections, csv, gzip, hashlib, io, json, re, subprocess, tarfile, zipfile
from pathlib import Path

def digest(b):
    return hashlib.sha256(b).hexdigest()
def gitblob(b):
    return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
def lines(b):
    return b.decode().splitlines()
def csvrows(b):
    return list(csv.DictReader(io.StringIO(b.decode())))
def write_csv(path, rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
def packed(b):
    with tarfile.open(fileobj=io.BytesIO(b),mode='r:*') as tf:
        return {m.name.removeprefix('./'):tf.extractfile(m).read() for m in tf if m.isfile()}
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('repo',type=Path)
    ap.add_argument('archive',type=Path)
    ap.add_argument('closure',type=Path)
    ap.add_argument('legacy_root',type=Path)
    ap.add_argument('--out',type=Path,default=Path('.'))
    a=ap.parse_args()
    def git(*args):
        return subprocess.run(['git','-C',a.repo,*args],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
    arc=a.archive.read_bytes()
    assert gitblob(arc)=='7b4cfed0cdd6cce28b97da5ab6fabe4383f136e1'
    cl=a.closure.read_bytes()
    assert gitblob(cl)=='5b818af689c2194a0c087a40f31537d9e23f0899'
    files=packed(cl)
    for line in lines(files['SHA256SUMS']):
        h,k=line.split('  ',1); assert digest(files[k])==h,k
    assert gitblob(files['review-map.csv'])=='eb5c79ff7dd1808d9bc8281699b9a8555a3d4d7f'
    assert gitblob(files['claude-legacy-claims.csv'])=='0e9a03cdd211d7e4bf9aa9a61cb18d5d23a1bd82'
    issues={i['n']:i for i in json.loads((a.out/'pr-snapshot.json').read_text()) if 'sha' in i}
    evidence=zipfile.ZipFile(io.BytesIO(arc))
    assert evidence.testzip() is None
    md=lines(evidence.read('reviewers.md'))
    indexed=[(i+1,[x.strip() for x in row.strip().strip('|').split('|')]) for i,row in enumerate(md) if re.match(r'^\| \d\d \|',row)]
    assert len(indexed)==112
    coverage=json.loads(files['coverage.json'])
    rows=csvrows(files['review-map.csv'])
    groups=collections.defaultdict(list)
    for r in rows: groups[r['shared_work_item']].append(r['lane'])
    manifest=[]; data={}
    for pack in evidence.namelist():
        if not pack.startswith('packs/'):continue
        bb=evidence.read(pack)
        for name,content in packed(bb).items():
            if Path(name).name.startswith('._'): continue
            ent=[(name,content)]
            if name.endswith('.tar.gz'):
                ent.extend((f'{name}!{k}',v) for k,v in packed(content).items() if not Path(k).name.startswith('._'))
            for member,b in ent:
                kind='file'; records=0; fails=0
                if member.endswith(('.jsonl','.jsonl.gz')):
                    kind='jsonl'
                    raw=gzip.decompress(b) if member.endswith('.gz') else b
                    records_data=[json.loads(z) for z in raw.splitlines() if z.strip()]
                    records=len(records_data);fails=sum(x.get('ok') is False for x in records_data)
                    data[(pack,member)]=records_data
                manifest.append(dict(pack=pack,member=member,sha256=digest(b),bytes=len(b),type=kind,rows=records,explicit_false_ok=fails))
    write_csv(a.out/'receipt-index.csv',manifest)
    roll=[]; read={}
    pinned='4db0425b361012523d8074ca6f2a760d9466e9f4'
    modern_links={'A01':'93','A02':'93','A03':'94','A22':'92','A39':'97','B01':'93','B02':'94','B08':'93','B20':'93','B42':'97','B65':'93','B66':'93','B67':'94','C/fast_archive':'97'}
    for j,r in enumerate(rows):
        lane=r['lane']; src_refs=[]; src_gaps=[]
        if j<112:
            lineno,fields=indexed[j]
            assert fields[0]==lane[1:] and (fields[2] if j<40 else fields[1])==r['finding'].strip()
            loc=f'UltraPlus-and-Archive-Evidence.zip!reviewers.md#L{lineno}'
            h=digest(md[lineno-1].encode());note='assignment text matched; individual worker transcript unavailable'
            if j<40:
                for path,spans in re.findall(r'`([\w./-]+):([\d,–-]+)`',r['finding']):
                    if path not in read:
                        out=git('show',pinned+':'+path)
                        read[path]=len(out.stdout.splitlines()) if out.returncode==0 else 0
                    end=max(map(int,re.findall(r'\d+',spans)))
                    target=f'{path}:{spans}'
                    (src_refs if 0<end<=read[path] else src_gaps).append(target)
        else:
            loc=r['evidence_location'];bb=evidence.read(loc);h=digest(bb)
            assert h==coverage['last_evidence'][lane[2:]]['sha256']
            note='design memo examined' if loc=='security.md' else 'packed receipt inventory checked; per-result scope in review map'
        nums=list(map(int,r['github_pr_numbers'].split()))
        for n in nums:assert issues[n]['sha'] and issues[n]['files']>0
        extra=modern_links.get(lane,'')
        if any(k in lane for k in ['B59']): extra='C/fast_first_segment'
        source='; '.join(f"#{n} {issues[n]['state']} {'merged' if issues[n]['merged'] else 'unmerged'} {issues[n]['sha'][:12]}" for n in nums)
        conclusion=r['disposition']
        if j<112 and not nums: conclusion='proposal only; no distinct implementation in this ledger' if extra=='' else 'cross-referenced follow-up; no independent implementation credit'
        elif j<112 and nums: conclusion+='; PR identity verified, complete scope needs individual evidence'
        else: conclusion+='; source fingerprint verified'
        if lane in ('A22','A39','B42','C/fast_archive'):conclusion+='; scoped landing on main also recorded in #47/#91'
        roll.append(dict(lane=lane,topic=r['shared_work_item'],record_locator=loc,sha256=h,original_disposition=r['disposition'],receipt_result=note,checked_source_refs=' '.join(src_refs),unresolved_source_refs=' '.join(src_gaps),linked_pr_status=source,additional_followup=extra,also_grouped_with=' '.join(x for x in groups[r['shared_work_item']] if x!=lane),result=conclusion,next_gate=r['qualification_or_original_status']))
    write_csv(a.out/'assignment-audit.csv',roll)
    byid=csvrows(files['claude-legacy-claims.csv']); ridx={r['lane']:r for r in csvrows(files['claude-legacy-index.csv'])}
    original=a.legacy_root/'review40b'
    aclaims=[json.loads(l) for l in (original/'claims.jsonl').read_text().splitlines()]
    bclaims=[json.loads(l) for l in (a.legacy_root/'review40c'/'claims.jsonl').read_text().splitlines()]
    assert len(aclaims)==178 and all({k:v for k,v in e.items() if k!='campaign'}=={k:v for k,v in f.items() if k!='campaign'} for e,f in zip(aclaims,bclaims)) and len(aclaims)==len(bclaims)
    assert digest((original/'claims.jsonl').read_bytes())==coverage['legacy_claim_ledger_sha256']
    reports={}
    for k,entry in ridx.items():
        path=original/entry['source_report']; h=digest(path.read_bytes());assert h==entry['report_sha256'];reports[k]=path.read_text().splitlines()
    out=[]
    for row in byid:
        n=int(row['claim_id']); claim=aclaims[n-1];k=row['historical_reviewer'];assert (claim['n'],claim['slug'],claim['reviewer'],claim['tier'])==(n,row['topic'],k,row['historical_campaign_tier'])
        ref=ridx[k];assert str(n) in ref['claim_ids'].split()
        pat=re.compile(r'(?<!\w)#'+str(n)+r'(?!\d)|^\|\s*'+str(n)+r'\s*\|')
        hits=[i+1 for i,s in enumerate(reports[k]) if row['topic'].lower() in s.lower()]
        match='slug'
        if not hits:
            hits=[i+1 for i,s in enumerate(reports[k]) if pat.search(s)];match='number' if hits else 'reviewer-level only'
        # Propagate only verified ancestry, separately from whether a PR implemented the whole claim.
        nums=[int(v) for v in row['source_or_followup'].split('/') if v];prs=[]
        for p in nums:
            pr=issues[p]
            commit=pr.get('merge')
            check=(git('merge-base','--is-ancestor',commit,'a1d3955').returncode==0) if pr['merged'] and commit else False
            prs.append(f"#{p} " + ('merge ancestor' if check else 'merged; ancestry unconfirmed' if pr['merged'] else 'unmerged'))
        out.append(dict(claim_id=n,reviewer=k,topic=row['topic'],tier=row['historical_campaign_tier'],record_type=ref['record_type'],report=ref['source_report'],report_sha256=ref['report_sha256'],claim_locator=match,report_lines=' '.join(map(str,hits[:8])),prior_grade=row['evidence_grade'],checked_links='; '.join(prs),fresh_replacement='replace-missing.py, replacements.json' if k in ('R11','R13') else '',production_qualification='requires scope-specific evidence; registration or report alone is insufficient'))
    write_csv(a.out/'legacy-claim-audit.csv',out)
    totals=dict(assignment_rows=len(rows),unique_group_labels=len(groups),labels_shared_by_multiple_rows=sum(len(v)>1 for v in groups.values()),a_b_no_original_pr=sum(i<112 and not r['github_pr_numbers'] for i,r in enumerate(rows)),a_b_static_breadcrumbs=sum(bool(r['checked_source_refs']) for r in roll[:40]),out_of_range_source_refs=[(r['lane'],r['unresolved_source_refs']) for r in roll if r['unresolved_source_refs']],legacy_claims=len(out),legacy_claim_anchors=dict(collections.Counter(r['claim_locator'] for r in out)),legacy_report_types=dict(collections.Counter(r['record_type'] for r in ridx.values())),legacy_grades=dict(collections.Counter(r['evidence_grade'] for r in byid)),historical_c_rows=len(bclaims),historical_c_reports=len(list((a.legacy_root/'review40c'/'reviews').glob('*.md'))),zip_sha256=digest(arc),published_closure_sha256=digest(cl),closure_manifest_entries=len(lines(files['SHA256SUMS'])),receipt_inventory=len(manifest),receipt_rows=sum(r['rows'] for r in manifest),explicit_false=sum(r['explicit_false_ok'] for r in manifest),pr_count=len(issues))
    (a.out/'summary.json').write_text(json.dumps(totals,indent=2)+'\n')
if __name__=='__main__': main()
