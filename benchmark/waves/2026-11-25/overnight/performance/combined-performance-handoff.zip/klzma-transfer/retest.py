"""Cross-size follow-up of the three 256 KiB source families showing mixed results."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'klzma-evidence'))
import verify
verify.sources=[('exe__wasmtime-arm64',1048576,'wasmtime-1m'),('numeric__ncep-nc',1048576,'ncep-1m'),('img16__mr',1048576,'mr-1m')]
if __name__=='__main__':verify.main()
