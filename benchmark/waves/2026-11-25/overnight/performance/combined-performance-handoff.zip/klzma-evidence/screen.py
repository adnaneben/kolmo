"""Find ordinary CLI routes emitting native KLZMA blocks on bounded real samples."""
import csv, hashlib, subprocess, sys
from pathlib import Path
from collections import Counter
root=Path(__file__).resolve().parent
corpus=Path(sys.argv[1])
binary=Path(sys.argv[2]).resolve()
sources=['exe__osdb','exe__wasmtime-arm64','numeric__ncep-nc','numeric__sao','img16__mr','weights__smollm2-bf16','tar__samba','container__highway-pdf','img8__coffee','code__jxl-cc','log__bgl','video__foreman']
(root/'inputs').mkdir(exist_ok=True)
with (root/'screen.csv').open('w',newline='') as f:
 w=csv.writer(f); w.writerow(['source','source_sha256','source_bytes','input_bytes','input_sha256','level','codec_counts','stored_bytes','frame_sha256'])
 for name in sources:
  raw=(corpus/name).read_bytes(); data=raw[:262144]; ip=root/'inputs'/name; ip.write_bytes(data)
  for level in ('8','9'):
   out=root/'screen.kolmo'
   subprocess.run([binary,'--level',level,'-T1','-q','-f',ip,'-o',out],check=True)
   framed=out.read_bytes(); nb=int.from_bytes(framed[20:24],'little')
   codecs=Counter(framed[32+16*i+12]&63 for i in range(nb))
   listed=subprocess.check_output([binary,'--list',out],text=True)
   print(name,level,codecs,listed.splitlines()[-1],flush=True)
   w.writerow([name,hashlib.sha256(raw).hexdigest(),len(raw),len(data),hashlib.sha256(data).hexdigest(),level,dict(codecs),len(framed),hashlib.sha256(framed).hexdigest()])
