"""Paired CLI summary. Distribution-free median intervals on repetition-level pairs."""
import csv, json, statistics
from pathlib import Path
from collections import defaultdict
root=Path(__file__).resolve().parent
rows=list(csv.DictReader((root/'rounds.csv').open()))
routes={(r['input'],str(r['level']),r['threads']):r for r in json.loads((root/'cli-routes.json').read_text()) if r['arm']=='before'}
n_expected=json.loads((root/'manifest.json').read_text())['rounds']
def gettime(row,phase):
    return (int(row['encode_ns'])+int(row['decode_ns'])) if phase=='combined' else int(row[phase+'_ns'])
def pct(times): return (statistics.median(times)-1)*100
cells=defaultdict(dict)
for r in rows:
    k=(r['input'],r['level'],int(r['threads']))
    assert r['restored_sha256']==r['input_sha256']==routes[k]['input_sha256']
    assert r['frame_sha256']==routes[k]['frame_sha256'] and int(r['bytes_out'])==routes[k]['frame_bytes']
    key=(r['arm'],int(r['rep']))
    assert key not in cells[k]
    cells[k][key]=r
assert len(cells)==len(routes)
scores=[]
for k, values in sorted(cells.items()):
    assert len(values)==(n_expected+1)*3
    init=routes[k]
    row={fld:init[fld] for fld in ['input','input_sha256','bytes','level','threads','klzma_blocks','frame_bytes','frame_sha256']}
    n=init['bytes']
    row['scored_triplets']=n_expected
    for phase in ('encode','decode','combined'):
        paired={}
        for arm in ('before','control','after'):
            ns=[gettime(values[(arm,i)],phase) for i in range(1,n_expected+1)]
            row[f'{arm}_{phase}_MBps']=n*1000/statistics.median(ns)
        for den,num in [('after','before'),('after','control'),('control','before')]:
            times=[gettime(values[num,i],phase)/gettime(values[den,i],phase) for i in range(1,n_expected+1)]
            prefix=f'{den}_vs_{num}_{phase}'
            row[prefix+'_pct']=pct(times)
            row[prefix+'_wins']=sum(t>1 for t in times)
            # Conservative 98.8% distribution-free median CI with 11 pairs (2nd, 10th order statistics).
            row[prefix+'_median_lo_pct']=(sorted(times)[1]-1)*100
            row[prefix+'_median_hi_pct']=(sorted(times)[-2]-1)*100
        for arm in ('before','control','after'):
            if phase!='combined':
                row[f'{arm}_{phase}_rss_B']=statistics.median(int(values[arm,i][phase+'_rss_B']) for i in range(1,n_expected+1))
    scores.append(row)
with (root/'score.csv').open('w',newline='') as of:
    w=csv.DictWriter(of,fieldnames=scores[0]);w.writeheader();w.writerows(scores)
print('input level threads codec24 blocks  encode% vs A and AA | combined% vs A and AA | A/A combined% | combined win counts vs A/AA')
for r in scores:
    print(r['input'],r['level'],r['threads'],r['klzma_blocks'],' ',
          *[round(r[c],2) for c in ('after_vs_before_encode_pct','after_vs_control_encode_pct','after_vs_before_combined_pct','after_vs_control_combined_pct','control_vs_before_combined_pct')],
          r['after_vs_before_combined_wins'],r['after_vs_control_combined_wins'])
