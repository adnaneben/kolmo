"""Ordinary CLI KLZMA check. Select by emitted codec and source family, before timing."""
import argparse
import hashlib
import json
import sys
import tempfile
import subprocess
from collections import Counter
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'evidence'))
import transfer

sources=[('exe__wasmtime-arm64',262144,'wasmtime-256k'),('numeric__ncep-nc',262144,'ncep-256k'),('img16__mr',262144,'mr-256k'),('container__highway-pdf',None,'highway-pdf-whole')]
def main():
    ap=argparse.ArgumentParser()
    for nm in ['before','after','out','corpus']: ap.add_argument('--'+nm,type=Path,required=True)
    ap.add_argument('--rounds',type=int,default=11)
    args=ap.parse_args()
    out=args.out
    checks=[]
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        for src,limit,ident in sources:
            data=(args.corpus/src).read_bytes()[:limit]
            in_file=td/'in'
            in_file.write_bytes(data)
            for level in [8,9]:
                for threads in [1,4]:
                    receipts=[]
                    for arm,binary in [('before',args.before),('after',args.after)]:
                        frame=td/'frame'
                        subprocess.run([binary.resolve(),'--level',str(level),'-T',str(threads),'-q','-f',in_file,'-o',frame],check=True)
                        v=frame.read_bytes()
                        blocks=int.from_bytes(v[20:24],'little')
                        counts=Counter(v[44+16*i]&63 for i in range(blocks))
                        receipts.append({'input':ident,'input_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'arm':arm,'level':level,'threads':threads,'codec_counts':dict(counts),'klzma_blocks':counts[24],'frame_bytes':len(v),'frame_sha256':hashlib.sha256(v).hexdigest()})
                    assert receipts[0]['frame_sha256']==receipts[1]['frame_sha256']
                    checks.extend(receipts)
    (out/'cli-routes.json').write_text(json.dumps(checks,indent=2)+'\n')
    transfer.LEVELS=['8','9']
    transfer.SOURCES=sources
    transfer.SEED=259128
    transfer.main()
if __name__=='__main__':main()
