# Native KLZMA, ordinary CLI qualification

Candidate commit 4c7d729cfd1739e0ab1d6340ec0c3a33d623273b changes KLZMA encoder price-table construction. The control binary is qualified main a1d39559686a9ec17c8614b9154a64d7b5b98672. The executable hashes are in manifest.json. This independent run uses ordinary public CLI compression and decompression rather than forcing a codec.

The routing prescreen compressed 12 different #48 corpus prefixes (256 KiB) using L8 and L9 and inspected the frame header/block records. Those assessments used the original main and did not use candidate timings. From the families that actually emitted KLZMA, qualification selected executable (Wasmtime), numeric (NCEP), medical image (MR) prefixes and the full 1,313,237-byte Highway PDF. All 16 selected combinations used native codec 24 for the full single block under both releases. The baseline and candidate frame hashes match in all 16 settings. Requested T4 doesn't mean four concurrent compression blocks.

One warmup and eleven scored A/A/B triplets per setting over levels 8/9 and T1/T4 yielded 576 successful fresh round trips. All three arms performed complete file-to-file CLI encode, decode and unmeasured byte verification. CLI sizes were unchanged. Candidate median paired round-trip speed changes ranged from −4.20% to +3.60% against the primary control and from −7.43% to +7.45% against the second identical control. Same-binary A/A ranged from −10.28% to +7.14% across the cells. Three examples show why a blanket speed claim would be premature:

| Workload, options | Combined speed change vs baseline A | Vs baseline AA | Wins out of 11 vs A/AA |
|---|---:|---:|---:|
| Highway PDF, L9 T4 | +3.60% | +1.95% | 7 / 9 |
| NCEP 256 KiB, L9 T1 | +0.93% | −7.43% | 6 / 1 |
| Wasmtime 256 KiB, L9 T1 | −4.20% | −1.49% | 3 / 3 |

Under the shared-host conditions these results support bit identity and leave the CLI performance hypothesis open. Retain the algorithm and kernel evidence in an isolated branch. Qualifying a general default needs reproducible improvement in production paths and independent hardware, including other sizes and multi-block inputs. Generated test inputs and frames are intentionally omitted from the public evidence archive; the source records and SHA-256 identify them.

The adjacent score.csv contains size and independent before/control/after encode, decode and combined throughput for every cell. Outcomes include repetition-level speed comparisons against both baseline arms, win counts, and distribution-free per-cell median intervals (98.8% nominal with n=11, no multiple-comparisons adjustment). rounds.csv retains every timed arm and tracers. cli-routes.json records all 32 preflight arm-specific frame inspections. screen.csv lists all 24 original route screens. verify.py uses the parent evidence/transfer.py runner; run score.py inside this directory after the test.
