"""Measure typed PCM preset substitutions before considering a production router."""
import argparse,csv,hashlib,io,json,math,os,random,statistics,struct,subprocess,sys,tempfile,wave
from collections import Counter,defaultdict
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'evidence'))
from transfer import run,digest

def real_sources(holdout):
    return {p.name:p.read_bytes() for p in sorted(holdout.glob('esc50-*.wav'))}
def synthetic_sources():
    rng=random.Random(66820)
    samples={'silence':[0]*32768,'uniform-noise':[rng.randrange(-32768,32768) for _ in range(32768)],
             'repeated-period':[12000,-12000,500,-500,24,-24,2,-2]*4096}
    result={}
    for name,data in samples.items():
        out=io.BytesIO()
        with wave.open(out,'wb') as w:
            w.setparams((1,2,44100,0,'NONE','not compressed'));w.writeframes(struct.pack('<%dh'%len(data),*data))
        result[name]=out.getvalue()
    return result

def main():
    p=argparse.ArgumentParser()
    for s in ('holdout','binary','out'):p.add_argument('--'+s,type=Path,required=True)
    a=p.parse_args()
    source=real_sources(a.holdout)
    assert len(source)==4,'expected four full ESC-50 clips'
    source.update(synthetic_sources())
    levels=['2','7','8','9','ultra']
    rng=random.Random(251132)
    groups=defaultdict(list)
    details={k:{'sha256':digest(v),'bytes':len(v)} for k,v in source.items()}
    (a.out/'inputs.json').write_text(json.dumps({'binary_sha256':digest(a.binary.read_bytes()),'sources':details,'randomization_seed':251132,'noise_seed':66820},indent=2)+'\n')
    with tempfile.TemporaryDirectory(dir=a.out) as dirname,(a.out/'raw.csv').open('x',newline='',buffering=1) as f:
        d=Path(dirname)
        for name,data in source.items(): (d/name).write_bytes(data)
        w=None
        for rep in range(6):
            keys=list(source);rng.shuffle(keys)
            for name in keys:
                lvs=list(levels);rng.shuffle(lvs)
                for level in lvs:
                    frame=d/'frame';out=d/'out'
                    enc=run([a.binary.resolve(),'--level',level,'-T1','-q','-f',d/name,'-o',frame])
                    dec=run([a.binary.resolve(),'-d','-T1','-q','-f',frame,'-o',out])
                    data=source[name];v=frame.read_bytes()
                    assert out.read_bytes()==data
                    n=int.from_bytes(v[20:24],'little'); codes=','.join(str(v[44+16*i]&63) for i in range(n))
                    # The plan + payload bytes can be compared independently of the mode in the frame header.
                    body=v[32+16*n:]
                    r={'source':name,'level':level,'repeat':rep,'input_bytes':len(data),'input_sha256':digest(data),'frame_bytes':len(v),'frame_sha256':digest(v),'payload_sha256':digest(body),'codec_ids':codes,'encode_ns':enc[0],'decode_ns':dec[0],'load1':os.getloadavg()[0]}
                    if not w:w=csv.DictWriter(f,fieldnames=r);w.writeheader()
                    w.writerow(r)
                    if rep:groups[name,level].append(r)
            print('pass',rep,'complete',flush=True)
    with (a.out/'score.csv').open('w',newline='') as f:
        w=None
        for name in source:
            for base,select in [('7','2'),('9','8'),('ultra','8')]:
                x=sorted(groups[name,base],key=lambda r:r['repeat']);y=sorted(groups[name,select],key=lambda r:r['repeat'])
                times=lambda r:r['encode_ns']+r['decode_ns']
                gains=[(times(old)/times(new)-1)*100 for old,new in zip(x,y)]
                r={'source':name,'requested':base,'substitute':select,'baseline_bytes':x[0]['frame_bytes'],'substitute_bytes':y[0]['frame_bytes'],'byte_delta':y[0]['frame_bytes']-x[0]['frame_bytes'],'codec_before':x[0]['codec_ids'],'codec_after':y[0]['codec_ids'],'payload_identical':x[0]['payload_sha256']==y[0]['payload_sha256'],'paired_combined_gain_pct':statistics.median(gains),'wins':sum(g>0 for g in gains),'pairs':len(gains)}
                if not w:w=csv.DictWriter(f,fieldnames=r);w.writeheader()
                w.writerow(r)
if __name__=='__main__':main()
