"""Interleave native CLIs on identical named input and redirected output descriptors."""
import argparse
import csv
import json
import os
import random
import shutil
import tempfile
import time
import statistics
import subprocess
from pathlib import Path
from transfer import SOURCES,digest

def run(command, path):
    with path.open('wb') as stream:
        argv=list(map(str,command))
        before=time.perf_counter_ns()
        pid=os.posix_spawn(argv[0],argv,os.environ,file_actions=[(os.POSIX_SPAWN_DUP2,stream.fileno(),1)])
        _,status,usage=os.wait4(pid,0)
        ns=time.perf_counter_ns()-before
    if status: raise RuntimeError((status,argv))
    return ns,usage.ru_utime+usage.ru_stime,usage.ru_maxrss

def main():
    parser=argparse.ArgumentParser()
    for fld in ['kolmo','corpus','out']:
        parser.add_argument('--'+fld,type=Path,required=True)
    args=parser.parse_args()
    programs={'kolmo':str(args.kolmo.resolve()),**{p:shutil.which(p) for p in ['xz','lz4','zstd']}}
    products = {}
    for l in ['1','3','9','ultra']:
        products[f'kolmo-{l}']=('kolmo',['--level',l,'-T1','-q','-c'],['-d','-T1','-q','-c'])
    products.update({'lz4-1':('lz4',['-1','--single-thread','-q','-c'],['-d','-q','-c']),
                     'zstd-1':('zstd',['-1','--single-thread','-q','-c'],['-d','-q','-c']),
                     'zstd-9':('zstd',['-9','--single-thread','-q','-c'],['-d','-q','-c']),
                     'xz-6':('xz',['-6','-T1','-c'],['-d','-T1','-c'])})
    sources=[(file,limit,label) for file,limit,label in SOURCES]
    sources.extend([('csv__gaia',16384,'gaia16k'),('csv__gaia',None,'gaia-whole')])
    manifest={'product_argv':products,'versions':{k:subprocess.run([p,'--version'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True).stdout.strip() for k,p in programs.items()},
              'binaries':{k:digest(Path(p).read_bytes()) for k,p in programs.items()},'seed':661723,
              'sources':{},'rounds':7}
    rows=[]
    target=args.out/'competitors-raw.csv'
    rng=random.Random(manifest['seed'])
    with tempfile.TemporaryDirectory(dir=args.out) as d,target.open('x',newline='',buffering=1) as file:
        d=Path(d)
        for src,limit,label in sources:
            original=(args.corpus/src).read_bytes()
            data=original[:limit]
            (d/label).write_bytes(data)
            manifest['sources'][label]={'source_file':src,'offset':0,'original_sha256':digest(original),'input_sha256':digest(data),'input_bytes':len(data),'original_bytes':len(original)}
        (args.out/'competitors-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        frame=d/'frame'
        out=d/'out'
        writer=None
        for rep in range(8):
            labels=list(manifest['sources'])
            rng.shuffle(labels)
            for label in labels:
                order=list(products)
                rng.shuffle(order)
                for i,product in enumerate(order):
                    while (args.out/'pause').exists():
                        time.sleep(1)
                    name,enc_opts,dec_opts=products[product]
                    binary=programs[name]
                    load=os.getloadavg()[0]
                    en=run([binary,*enc_opts,d/label],frame)
                    de=run([binary,*dec_opts,frame],out)
                    recovered=digest(out.read_bytes())
                    source=manifest['sources'][label]
                    if recovered!=source['input_sha256']: raise RuntimeError((product,label))
                    r={'input':label,'product':product,'rep':rep,'order':i,'raw_bytes':source['input_bytes'],'stored_bytes':frame.stat().st_size,'frame_sha256':digest(frame.read_bytes()),'restored_sha256':recovered,'encode_ns':en[0],'decode_ns':de[0],'encode_cpu_s':en[1],'decode_cpu_s':de[1],'encode_rss_B':en[2],'decode_rss_B':de[2],'load1':load}
                    if not writer:
                        writer=csv.DictWriter(file,fieldnames=r)
                        writer.writeheader()
                    writer.writerow(r)
                    if rep: rows.append(r)
            print('pass',rep,'complete',flush=True)
    w=None
    with (args.out/'competitors-score.csv').open('w',newline='') as f:
        for label in sorted(manifest['sources']):
            for product in products:
                cells=[r for r in rows if r['input']==label and r['product']==product]
                sizes={r['stored_bytes'] for r in cells}
                assert len(cells)==7 and len(sizes)==1 and len({r['frame_sha256'] for r in cells})==1
                n=cells[0]['raw_bytes']
                c=next(iter(sizes))
                m=lambda values:statistics.median(values)
                r={'input':label,'product':product,'raw_bytes':n,'stored_bytes':c,'ratio':n/c,
                   'encode_MBps':n*1e3/m([q['encode_ns'] for q in cells]),'decode_MBps':n*1e3/m([q['decode_ns'] for q in cells]),
                   'combined_MBps':n*1e3/m([q['encode_ns']+q['decode_ns'] for q in cells]),'encode_rss_B':m([q['encode_rss_B'] for q in cells]),'decode_rss_B':m([q['decode_rss_B'] for q in cells])}
                if not w: w=csv.DictWriter(f,fieldnames=r);w.writeheader()
                w.writerow(r)
if __name__=='__main__': main()
