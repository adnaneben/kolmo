"""Write the product frontiers for a completed competition CSV."""
import csv
from pathlib import Path
root=Path(__file__).resolve().parent
scores=list(csv.DictReader((root/'competitors-score.csv').open()))
def faster(p): return float(p['combined_MBps'])
def smaller(p): return int(p['stored_bytes'])
def dominates(a,b):
    return faster(a)>=faster(b) and smaller(a)<=smaller(b) and (faster(a)>faster(b) or smaller(a)<smaller(b))
lines=['# Whole-process, single-thread product comparison','',
       'Apple M5. Matched warm input, eight shuffled product arms per cell, seven scored observations and one warmup. All outputs were decoded and checked against the source SHA-256. Four distinct Kolmo presets compete with LZ4 1, zstd 1 and 9, and xz 6. Both phases are charged; compressed byte counts include complete frames. A frontier entry means no other tested product simultaneously has smaller/equal output and faster/equal marginal median throughput, with one strict improvement. This descriptive frontier has no adjustment for measurement noise or multiple comparisons.','',
       '| Input | Fastest measured product | Smallest measured product | Nondominated Kolmo presets |','| --- | --- | --- | --- |']
for sample in sorted({r['input'] for r in scores}):
    group=[r for r in scores if r['input']==sample]
    fastest=max(group,key=faster);tiny=min(group,key=smaller)
    smallest_names=', '.join(r['product'] for r in group if smaller(r)==smaller(tiny))
    front=[r['product'] for r in group if r['product'].startswith('kolmo-') and not any(dominates(other,r) for other in group)]
    lines.append(f"| {sample} | {fastest['product']} ({faster(fastest):.2f} MB/s) | {smallest_names} ({smaller(tiny):,} B) | {', '.join(front) or 'None'} |")
lines+=['','The 16 KiB, 256 KiB and full Gaia cells share a producer. The full Gaia input is the whole 4,193,950-byte #48 corpus object, which is itself a normalized source excerpt per #48; this is not a full astronomical catalogue. Text and Python cells are prefixes. The WAV is a full recorded clip. None of these existing #48 workloads is a sealed source-disjoint qualification set. The raw observations, exact product arguments, version strings and input hashes are in the adjacent CSV/JSON files.']
(root/'competition.md').write_text('\n'.join(lines)+'\n')
