"""Score the completed transfer matrix and render a portable ratio/speed plot."""
import csv
import json
import math
import statistics as stats
from collections import defaultdict
from html import escape
from pathlib import Path

root = Path(__file__).resolve().parent
meta = json.loads((root/'manifest.json').read_text())
raw = list(csv.DictReader((root/'rounds.csv').open()))
grouped = defaultdict(dict)
for r in raw:
    assert r['input_sha256'] == r['restored_sha256'] == meta['sources'][r['input']]['input_sha256']
    key = (r['input'], r['level'], int(r['threads']))
    subkey = (int(r['rep']), r['arm'])
    assert subkey not in grouped[key]
    grouped[key][subkey] = r
assert len(grouped) == len(meta['sources'])*len(meta['levels'])*len(meta['requested_threads'])
N = meta['rounds']
def totals(row):
    return int(row['encode_ns']) + int(row['decode_ns'])
def speed(n, t):
    return 1e3*n/t
def pct(a,b):
    return (a/b-1)*100

summary = []
for (sample,level,t), trials in sorted(grouped.items()):
    assert len(trials) == (N+1)*3
    rows = list(trials.values())
    frame_digests = {r['frame_sha256'] for r in rows}
    lengths = {int(r['bytes_out']) for r in rows}
    assert len(frame_digests)==len(lengths)==1
    n = int(rows[0]['bytes_in'])
    size, = lengths
    reps = range(1,N+1)
    row = {'input':sample,'level':level,'requested_threads':t,'input_bytes':n,'baseline_bytes':size,'main_bytes':size,
           'ratio':n/size,'frame_sha256':next(iter(frame_digests)), 'scored_triplets':N}
    for arm in ('before','control','after'):
        cells=[trials[i,arm] for i in reps]
        for col,func in [('encode',lambda x:int(x['encode_ns'])),('decode',lambda x:int(x['decode_ns'])),('combined',totals)]:
            row[f'{arm}_{col}_MBps']=speed(n,stats.median(func(c) for c in cells))
        for stage in ('encode','decode'):
            row[f'{arm}_{stage}_peak_rss_B_median']=stats.median(int(c[f'{stage}_rss_B']) for c in cells)
    for other in ('before','control'):
        row[f'paired_main_speedup_pct_vs_{other}']=stats.median(pct(totals(trials[i,other]),totals(trials[i,'after'])) for i in reps)
    row['paired_control_speedup_pct_vs_before']=stats.median(pct(totals(trials[i,'before']),totals(trials[i,'control'])) for i in reps)
    summary.append(row)
with (root/'score.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=summary[0])
    w.writeheader()
    w.writerows(summary)
names = {'text16k':'Literature · 16 KiB prefix','python64k':'Python stdlib · 64 KiB prefix','gaia256k':'Gaia CSV · 256 KiB prefix','esc50-whole':'ESC-50 audio · 441,044 B whole'}
svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1180 1100" role="img"><title>Kolmo compression ratio and round-trip file throughput</title>',
     '<style>text{font-family:system-ui, sans-serif;fill:#192e3a}.axis{font-size:12px;fill:#3b5059}.name{font-size:17px;font-weight:600}.grid{stroke:#dde5e6}.old{fill:#fff;stroke:#19647e;stroke-width:1.8}.new{fill:#c5472b;fill-opacity:.82}</style>',
     '<rect width="100%" height="100%" fill="#fff"/>',
     '<text x="38" y="43" font-size="29" font-weight="700">Kolmo file compression across levels 1–9 and Ultra</text>',
     '<text x="38" y="73" font-size="17">Vertical axis: original ÷ compressed bytes. Horizontal axis: complete encode + decode throughput (MB/s, log scale).</text>',
     '<circle class="old" cx="46" cy="102" r="5"/><text x="59" y="107" font-size="15">Baseline 4db0425b</text><circle class="new" cx="260" cy="102" r="4"/><text x="273" y="107" font-size="15">Qualified main a1d39559</text>',
     '<text x="513" y="107" font-size="15">Each pair is one level. Hover over a point for details.</text>']
def item(s):
    svg.append(s)
def ticks(start,end,count):
    return [start+(end-start)*i/(count-1) for i in range(count)]
for index, sample in enumerate(names):
    both = [r for r in summary if r['input']==sample]
    x_values = [r[arm+'_combined_MBps'] for r in both for arm in ('before','after')]
    x_min,x_max=math.log10(min(x_values))-.08,math.log10(max(x_values))+.08
    ys=[r['ratio'] for r in both]
    lo,hi=min(ys),max(ys)
    pad=max((hi-lo)*.1,.02)
    y_min,y_max=lo-pad,hi+pad
    for t in (1,4):
        ax=70+(t==4)*573
        ay=159+index*229
        width,height=478,147
        x=lambda v: ax+(math.log10(v)-x_min)*width/(x_max-x_min)
        y=lambda v: ay+height-(v-y_min)*height/(y_max-y_min)
        item(f'<text class="name" x="{ax}" y="{ay-15}">{escape(names[sample])} · T{t}</text>')
        for v in ticks(y_min,y_max,4):
            item(f'<path class="grid" d="M{ax},{y(v)}h{width}"/><text class="axis" x="{ax-7}" y="{y(v)+4}" text-anchor="end">{v:.2f}×</text>')
        for log in ticks(x_min,x_max,5):
            v=10**log
            item(f'<path class="grid" d="M{x(v)},{ay}v{height}"/><text class="axis" x="{x(v)}" y="{ay+height+18}" text-anchor="middle">{v:.2g}</text>')
        for r in both:
            if r['requested_threads']!=t: continue
            y_pos=y(r['ratio'])
            a,b=x(r['before_combined_MBps']),x(r['after_combined_MBps'])
            item(f'<path stroke="#7f8990" d="M{a},{y_pos}H{b}"/>')
            for arm,cls,pos,rad in [('before','old',a,4.5),('after','new',b,3)]:
                tip=f"Level {r['level']} · {arm} · {r[arm+'_combined_MBps']:.2f} MB/s · {r['ratio']:.3f}×"
                item(f'<circle class="{cls}" cx="{pos}" cy="{y_pos}" r="{rad}"><title>{escape(tip)}</title></circle>')
item('<text x="39" y="1069" font-size="15">Warm-cache Apple M5, seven scored rounds per cell, randomized order with same-binary controls. Shared host; timings are descriptive.</text></svg>')
(root/'levels.svg').write_text('\n'.join(svg)+'\n')
q = lambda vals: [min(vals),stats.median(vals),max(vals)]
print(json.dumps({'settings':len(summary),'total_restores':len(raw),'scored_triplets':len(summary)*N,
                  'load1_range':q([float(r['load1']) for r in raw]),
                  'paired_main_pct_vs_before_range_median':q([r['paired_main_speedup_pct_vs_before'] for r in summary]),
                  'same_binary_pct_range_median':q([r['paired_control_speedup_pct_vs_before'] for r in summary])},indent=2))
