# Whole-process, single-thread product comparison

Apple M5. Matched warm input, eight shuffled product arms per cell, seven scored observations and one warmup. All outputs were decoded and checked against the source SHA-256. Four distinct Kolmo presets compete with LZ4 1, zstd 1 and 9, and xz 6. Both phases are charged; compressed byte counts include complete frames. A frontier entry means no other tested product simultaneously has smaller/equal output and faster/equal marginal median throughput, with one strict improvement. This descriptive frontier has no adjustment for measurement noise or multiple comparisons.

| Input | Fastest measured product | Smallest measured product | Nondominated Kolmo presets |
| --- | --- | --- | --- |
| esc50-whole | lz4-1 (100.91 MB/s) | kolmo-9, kolmo-ultra (203,429 B) | kolmo-3, kolmo-9 |
| gaia-whole | lz4-1 (345.98 MB/s) | kolmo-ultra (1,027,085 B) | kolmo-1, kolmo-9, kolmo-ultra |
| gaia16k | lz4-1 (3.25 MB/s) | kolmo-ultra (2,108 B) | kolmo-ultra |
| gaia256k | lz4-1 (66.80 MB/s) | kolmo-ultra (64,168 B) | kolmo-1, kolmo-9, kolmo-ultra |
| python64k | lz4-1 (17.91 MB/s) | kolmo-ultra (12,782 B) | kolmo-9, kolmo-ultra |
| text16k | lz4-1 (4.20 MB/s) | kolmo-ultra (4,408 B) | kolmo-ultra |

The 16 KiB, 256 KiB and full Gaia cells share a producer. The full Gaia input is the whole 4,193,950-byte #48 corpus object, which is itself a normalized source excerpt per #48; this is not a full astronomical catalogue. Text and Python cells are prefixes. The WAV is a full recorded clip. None of these existing #48 workloads is a sealed source-disjoint qualification set. The raw observations, exact product arguments, version strings and input hashes are in the adjacent CSV/JSON files.
