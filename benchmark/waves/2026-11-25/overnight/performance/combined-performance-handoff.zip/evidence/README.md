# Qualified main before and after the November 25 wave

The wave tracker pinned 4db0425b361012523d8074ca6f2a760d9466e9f4 as its original main baseline. Its first-parent path to a1d39559686a9ec17c8614b9154a64d7b5b98672 contains two commits, 8795bf1dcbea193581da6de3b36f9944b547f115 (Python buffer copy) and a1d39559 (archive walker and scoped RT store). Both were already integrated. Building those two trees includes their actual integration. Draft experiments have separate comparisons and are excluded from this baseline. The starting revision itself already contains earlier Claude work, including routing fixes and the #48 research harness. This comparison cannot isolate changes made before that revision.

## Ordinary file CLI

The native binaries were rebuilt on Apple M5 with Apple clang 21, the repository Makefile, and matching -O3 -mcpu=native -ffp-contract=off flags. Their SHA-256 digests match the previous direct-main archive handoff byte for byte. [Levels graph](levels.svg) · [per-setting scores](score.csv) · [all observations](rounds.csv) · [input and executable hashes](manifest.json) · [source records from the pinned #48 corpus](source-records.jsonl)

* 80 settings span all ten distinct presets (1–9 and Ultra), T1/T4, three source prefixes and one full WAV. The named fastest/light/balanced/compact/max options map to 1/3/5/7/9. The matrix does not cross every file type with every size. Sub-block inputs can use fewer active workers than requested.
* Each setting had one warmup and seven scored A/A/B triplets with shuffled order. A and AA invoke the identical baseline executable. The program checks every restored byte and records both original and compressed SHA-256. All **1,920** full CLI restores passed. For each setting every baseline and candidate compressed SHA matched.
* Median of the 80 cell-level median paired combined-speed changes was **−0.56%**. Cell results ranged from **−9.33% to +4.99%**. The same-binary control ranged from **−7.99% to +15.04%**. The ordinary file CLI reaches neither the Python copy nor the DDP archive improvement. The spread is insufficient evidence to attribute an ordinary codec speed change.
* The frame ratio uses source bytes divided by complete framed bytes. Throughput uses decimal MB divided by wall seconds. Each combined rate uses the median of observed encode-plus-decode wall times. Phase medians are independent. Timings include process startup, warm file reads and writes, and exclude post-run verification. This was a shared host with other work, no cache evictions and no p95 claims.
* Size/latency opportunities remain. On the 441,044-byte WAV, levels 2–7 stored 211,267 bytes each. L8/L9/Ultra stored 203,429 bytes each. On the 16 KiB literary prefix, level 9 gave 5,466 bytes, versus 5,205 at level 2. On the 256 KiB Gaia prefix, L2 beat L3 on both size and paired-workload rate. General routing changes need independent producers, size transfer, full frames, and immutable validation data.

## Where the integrated code improved

The executable digests reproduced the binaries in the earlier [pinned archive handoff](https://github.com/adnaneben/kolmo/tree/847f518313cd59565315b9374d0cf9e9c3de3c1e/benchmark/waves/2026-11-25/rc-review). The previous randomized T4 recheck used two independently sampled baseline arms, one warmup and fifteen scored triplets. The published within-pair combined speed gains were 3.6–4.6% on the two eligible large, unique stored gzip members, with identical output size. Phase medians below are from the original confirmation receipts. Marginal phase/combined rates need not yield the median within-pair change when divided.

| Eligible T4 workload | Archive bytes before/after | Encode MB/s before → after | Decode MB/s before → after | Combined MB/s before → after |
| --- | ---: | ---: | ---: | ---: |
| Complete Silesia gzip member | 68,289,672 | 835.53 → 875.91 | 3,621.90 → 3,596.62 | 678.91 → 699.73 |
| Complete enwik8 gzip member | 36,595,528 | 810.85 → 851.18 | 3,229.30 → 3,202.34 | 647.33 → 672.29 |

## Replay

Check out the two exact commits in isolated directories and run `make -j4 build/kolmo` in each. Supply #48's hash-matched corpus directory to the scripts. Output must be a new directory. The CSV writers refuse to overwrite existing benchmark results.

```sh
python3 transfer.py --before /path/to/4db0425b/build/kolmo --after /path/to/a1d39559/build/kolmo --corpus /path/to/impact/corpus/holdout --out /path/to/new-results
cp score.py /path/to/new-results/
python3 /path/to/new-results/score.py
python3 competitors.py --kolmo /path/to/a1d39559/build/kolmo --corpus /path/to/impact/corpus/holdout --out /path/to/new-results
```

The competitor measurements use a separate interleaved protocol with every product writing a redirected output descriptor. Use its Kolmo arm for product comparisons because its CLI flags and I/O boundary differ from the file-output binary transfer test.
