"""Prepare complete int32 field extracts and original integer WAV; NPY files are separate products."""
import ast,csv,hashlib,json,shutil,struct,sys
from pathlib import Path
out=Path(sys.argv[1]); old=Path(sys.argv[2]); csv_file=Path(sys.argv[3]); wav=Path(sys.argv[4]);work=out/'input';work.mkdir(parents=True,exist_ok=True)
def sha(v):return hashlib.sha256(v).hexdigest()
def wrap(raw):
 descr=repr({'descr':'<i4','fortran_order':False,'shape':(len(raw)//4,)})
 padded=(descr+' '*((-len(descr)-11)%64)+'\n').encode('ascii')
 return b'\x93NUMPY\x01\0'+struct.pack('<H',len(padded))+padded+raw
meta={}
def output(label,data,more):
 original=work/(label+'.i32');original.write_bytes(data)
 npy=wrap(data);(work/(label+'.npy')).write_bytes(npy)
 meta[label]={**more,'int32_bytes':len(data),'int32_sha256':sha(data),'npy_header_bytes':len(npy)-len(data),'npy_total_bytes':len(npy),'npy_sha256':sha(npy)}
for p in [old/'train/USW00014739.u32',*sorted((old/'test').glob('*.u32'))]:
 output(p.stem,p.read_bytes(),{'role':'development' if p.parent.name=='train' else 'station-transfer','source_field':'TMAX'})
vals=bytearray(); missing=0
with csv_file.open() as f:
 for row in csv.DictReader(f):
  v=row['smart_194_normalized'];value=int(v) if v else -2147483648
  if not v:missing+=1
  vals+=struct.pack('<i',value)
output('backblaze-194',vals,{'role':'independent-producer','source':csv_file.name,'source_sha256':sha(csv_file.read_bytes()),'source_bytes':csv_file.stat().st_size,'field':'smart_194_normalized','missing_rows':missing,'rows':len(vals)//4,'absent_sentinel':-2147483648})
data=wav.read_bytes();(work/'esc50.wav').write_bytes(data);meta['esc50.wav']={'role':'independent-full-file-control','source':wav.name,'source_sha256':sha(data),'source_bytes':len(data)}
(out/'inputs.json').write_text(json.dumps(meta,indent=2)+'\n')
