"""Score only fully completed transfer settings; keep exploratory dev screen separate."""
import csv,hashlib,json,statistics
from pathlib import Path
from collections import defaultdict
p=Path(__file__).resolve().parent
srcmeta=json.loads((p/'inputs.json').read_text())
rows=list(csv.DictReader((p/'rows.csv').open()))
cells=defaultdict(list)
for r in rows:
 assert r['source_sha256']==r['restore_sha256']
 if int(r['rep'])!=-1:cells[r['input'],r['arm']].append(r)
assert len(cells)==48
all_scores=[]
for (src,arm),rr in sorted(cells.items()):
 assert {int(r['rep']) for r in rr}==set(range(6)) and len(rr)==6
 assert len({r['frame_sha256'] for r in rr})==1
 valid=[r for r in rr if int(r['rep'])>0];v=rr[0]
 n=int(v['input_bytes']);typ='npy_total_bytes' if src.endswith('.npy') else 'int32_bytes'
 header=128 if src.endswith('.npy') else 0;whole=0
 if src.endswith('.wav'):whole=n
 a={'input':src,'arm':arm,'bytes_input':n,'complete_frame_bytes':int(v['frame_bytes']),'npy_header_in_original_B':header,
    'complete_WAV_bytes_if_applicable':whole,'external_model_B':0,'external_decoder_side_data_B':0,
    'ordinary_reader_verified':True,'codec_ids':v['codec_ids'],'frame_sha256':v['frame_sha256'],'input_sha256':v['source_sha256']}
 for fld in ['encode','decode','combined']:
  ns=[int(r['encode_ns'])+int(r['decode_ns']) if fld=='combined' else int(r[fld+'_ns']) for r in valid]
  a[fld+'_MBps']=n*1000/statistics.median(ns)
 if any(int(r['input_bytes'])!=n for r in rr):raise RuntimeError(src)
 all_scores.append(a)
with (p/'score.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=all_scores[0]);w.writeheader();w.writerows(all_scores)
lines=['# Integer routing gate · stock v12','',
 'Tested whether shipping presets or an inexpensive type declaration could close the untrained OpenZL7 gap. One separate development station was screened once (12 exact runs); the transfer panel then ran 48 settings with one warmup and five scored randomized rounds. All 288 transfer and 12 development encodes decoded exactly. All Kolmo frames, including the experimental encoder outputs, were decoded by the unmodified a1d39559 CLI. No model, dictionary or external side bytes were required for any tested route. The file-to-file phase times include spawn and I/O; every result checks complete decoded SHA-256 outside timing. The four weather stations were previously examined in B25 and are transfer controls, not a new sealed test set. The S.M.A.R.T. series is from a different producer, storage telemetry, never used to design the raw prototype.','',
 '| Matched input | OpenZL7 bytes / MB/s | Stock L3 bytes / MB/s | Stock L3 native-leaf bytes / MB/s | Stock L9 bytes / MB/s | Stock Ultra bytes / MB/s | Explicit raw-i32 or declared typed-huf bytes / MB/s |',
 '|---|---:|---:|---:|---:|---:|---:|']
for src in sorted({r['input'] for r in all_scores}):
 d={r['arm']:r for r in all_scores if r['input']==src}
 order=['openzl-7','stock-3','native-3','stock-9','stock-ultra','explicit-i32-3' if src.endswith('.i32') else 'typed-huf-3']
 cells0=' | '.join(f"{d[a]['complete_frame_bytes']:,} / {d[a]['combined_MBps']:.2f}" for a in order)
 lines.append(f'| {src} | {cells0} |')
lines+=['','## Representation and decisions','',
 'The four TMAX vectors contain every daily station row in order, signed little-endian int32 with INT32_MIN marking a missing value. The independent Backblaze score includes every one of 338,817 SMART-194 normalized values (439 missing) in the 133,373,544-byte daily report, yielding a complete 1,355,268-byte integer series. It does not represent the report’s other columns. The Miami and Backblaze NPY inputs are distinct lossless products with identical values and full 128-byte NPY headers charged to every compressor. Stock Kolmo decodes raw routes directly to headerless bytes; it decodes NPY routes to the original NPY including header, with no postprocessing. The 441,044-byte ESC-50 WAV control is an original whole PCM file, header and samples together. The WAV OpenZL arm uses its generic serial profile; it is a fallback/control rather than a comparison against the best possible audio-specific codec.','',
 'The research patch affects only an isolated build of the stock level-3 opt-in typed encoder. When the existing typed NPY/WAV parser has no match and the experiment supplies an aligned sequence of at least 4 KiB, its caller explicitly declares 32-bit elements and reuses the shipped integer forward/Huffman leaf and frame writer with header length zero. The shipping decoder, wire syntax, index and checksums are unchanged. It is an explicit representation hypothesis, not a proposed automatic classifier. This producer-independent test used the same frozen prototype for all raw vectors. No unrecognized input is enabled on main or the RC.','',
 'The single training-station screen tested stock levels 1, 2, 3, 5, 8, 9, Ultra, full analysis, native leaf, typed Huffman, the raw type-declaration patch and OpenZL7. The fixed transfer panel was chosen to expose the speed/size trade-off rather than fit a separate level per input. Fast-stock L3 and the native-leaf path remain useful speed-biased alternatives. The explicit raw-Huffman pass lacks a blanket size/speed win. Stock Ultra can approach or beat the rival frame size on selected vectors but pays much more time. Preserve the negative prototype and the complete frontier; do not promote a universal raw integer route.','',
 '## Replay','', 'Start from pinned main a1d39559686a9ec17c8614b9154a64d7b5b98672. Compile stock with make build/kolmo; in a separate copy apply explicit-i32.patch and build the same target with identical flags. Use prepare.py OUTPUT PRIOR_B25_DERIVED BACKBLAZE_CSV ORIGINAL_WAV. Run test.py STOCK_CLI PROTOTYPE_CLI OPENZL_ZLI OUTPUT and then score.py. The B25 receipt contains the station CSV-to-vector construction. inputs.json identifies the entire original Backblaze file, the control WAV, the raw series and the full NPY inputs. protocol.json pins binary hashes and options. rows.csv retains every raw observation, frame and restore hash. score.csv contains individual encode, decode and matched combined rates. Some short CLI launches run near scheduler noise; this single host does not establish tail latency or independent x86 behavior.']
(p/'README.md').write_text('\n'.join(lines)+'\n')
