"""Matched ordinary v12 routes, a bounded declared-i32 experiment, and OpenZL. macOS."""
import csv,hashlib,json,os,random,statistics,subprocess,sys,tempfile,time
from pathlib import Path
from collections import defaultdict
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def timed(args):
 start=time.perf_counter_ns();child=subprocess.Popen(list(map(str,args)),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 _,status,ru=os.wait4(child.pid,0);t=time.perf_counter_ns()-start;child.returncode=os.waitstatus_to_exitcode(status)
 if child.returncode:raise RuntimeError((args,status))
 return t,ru.ru_utime+ru.ru_stime,ru.ru_maxrss
def main():
 base,proto,z,out=map(lambda x:Path(x).resolve(),sys.argv[1:5])
 paths=out/'input'
 dev=paths/'USW00014739.i32'
 hold=sorted(p for p in paths.glob('*.i32') if p!=dev)
 controls=[paths/'USW00012839.npy',paths/'backblaze-194.npy',paths/'esc50.wav']
 settings={'stock-3':['-3'],'stock-3-full':['-3','--analysis','full'],'native-3':['-3','--native-leaf'],'typed-huf-3':['-3','--typed-huf'],'explicit-i32-3':['-3','--typed-huf'],'stock-1':['-1'],'stock-2':['-2'],'stock-5':['-5'],'stock-8':['-8'],'stock-9':['-9'],'stock-ultra':['--ultra']}
 zargs=lambda src:['-p','le-i32' if src.suffix=='.i32' else 'numpy' if src.suffix=='.npy' else 'serial','-l','7']
 rng=random.Random(6327143)
 meta={'binaries':{str(p.name)+'_'+name:sha(p) for p,name in [(base,'qualified-main'),(proto,'explicit-i32'),(z,'openzl')]},'options':settings,'OpenZL':'-p le-i32 (raw), numpy (.npy), serial (WAV); -l 7. No trained graph or external dictionary.', 'seed':6327143,'source_main':'a1d39559686a9ec17c8614b9154a64d7b5b98672','chosen_protocol':'One preliminary dev screen on USW00014739. Unconditional transfer of stock-3, native-3, stock-9, stock-ultra, OpenZL7 plus the direct-i32 experimental path on raw and stock typed-huf on NPY/WAV. All decode with original matching decoder. Default #48 v12 recovers complete original bytes for every Kolmo result.'}
 (out/'protocol.json').write_text(json.dumps(meta,indent=2)+'\n')
 with tempfile.TemporaryDirectory() as td,(out/'rows.csv').open('x',newline='',buffering=1) as fh:
  td=Path(td);frame=td/'frame';rec=td/'out';w=None
  for rep in range(-1,6):
   sources=[dev] if rep==-1 else hold+controls
   sources=list(sources);rng.shuffle(sources)
   for source in sources:
    arms=list(settings) if rep==-1 else (['stock-3','native-3','stock-9','stock-ultra','explicit-i32-3'] if source.suffix=='.i32' else ['stock-3','native-3','typed-huf-3','stock-9','stock-ultra'])
    arms+=['openzl-7'];rng.shuffle(arms)
    n=source.stat().st_size;sig=sha(source)
    for order,arm in enumerate(arms):
     if arm=='openzl-7':
      enc=[z,'compress',*zargs(source),'-f',source,'-o',frame];dec=[z,'decompress','-f',frame,'-o',rec]
     else:
      binary=proto if arm=='explicit-i32-3' else base
      enc=[binary,*settings[arm],'-T1','-q','-f',source,'-o',frame];dec=[base,'-d','-T1','-q','-f',frame,'-o',rec]
     en=timed(enc);de=timed(dec);rest=sha(rec);assert rest==sig
     raw=frame.read_bytes();cc=None if arm=='openzl-7' else [raw[44+16*i]&63 for i in range(int.from_bytes(raw[20:24],'little'))]
     outrow={'input':source.name,'source_sha256':sig,'input_bytes':n,'arm':arm,'order':order,'rep':rep,'frame_bytes':len(raw),'frame_sha256':hashlib.sha256(raw).hexdigest(),'codec_ids':str(cc),'restore_sha256':rest,'encode_ns':en[0],'decode_ns':de[0],'encode_cpu_s':en[1],'decode_cpu_s':de[1],'encode_peak_rss_B':en[2],'decode_peak_rss_B':de[2],'load1':os.getloadavg()[0]}
     if w is None:w=csv.DictWriter(fh,fieldnames=outrow);w.writeheader()
     w.writerow(outrow);frame.unlink();rec.unlink()
   print('pass',rep,'complete',flush=True)
if __name__=='__main__':main()
