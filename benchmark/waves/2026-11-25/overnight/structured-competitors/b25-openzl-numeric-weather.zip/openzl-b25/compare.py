"""Matched complete file processes with three OpenZL profiles and their encoder-side graphs."""
import csv,hashlib,json,os,random,statistics,subprocess,sys,tempfile,time
from pathlib import Path
from collections import defaultdict
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def timed(argv,d):
 t=time.perf_counter_ns();p=subprocess.Popen(list(map(str,argv)),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,cwd=d)
 _,status,res=os.wait4(p.pid,0);ns=time.perf_counter_ns()-t;p.returncode=os.waitstatus_to_exitcode(status)
 if p.returncode:raise RuntimeError((argv,p.returncode))
 return ns,res.ru_utime+res.ru_stime,res.ru_maxrss
def main():
 page,base,experiment,out=map(lambda a:Path(a).resolve(),sys.argv[1:5])
 z=page/'tools/openzl/build/cli/zli'; graphs=page/'results/work-panel';h=page/'data/holdout'
 graph={'csv':graphs/'ghcn-csv-p_csv.zlc','numpy':graphs/'ncep-npy-p_numpy.zlc','le-i32':out/'typed-weather.zlc'}
 old=json.loads((page/'results/panel.json').read_text())
 meta={'binaries':{k:{'size':v.stat().st_size,'sha256':sha(v)} for k,v in [('main',base),('experiment',experiment),('openzl',z)]},'openzl_commit':subprocess.check_output(['git','-C',page/'tools/openzl','rev-parse','HEAD'],text=True).strip(),'profiles':{},'sources':{},'seed':264512,'scored_repetitions':5}
 for kind,key in [('csv','ghcn-csv/-p csv'),('numpy','ncep-npy/-p numpy'),('le-i32',None)]:
  a=old['_training'][key] if key else json.loads((out/'training.json').read_text())
  path=graph[kind];meta['profiles'][kind]={'graph_bytes':path.stat().st_size,'graph_sha256':sha(path),'training_wall_s':a.get('seconds',a.get('elapsed_s')),'trainer_argv':a.get('args',a.get('argv')),'decoder_arguments':['decompress','-f','FRAME','-o','OUT']}
 files={f.stem+'-tmax':(f,'le-i32') for f in sorted((out/'derived/test').glob('*.u32'))}
 files['miami-csv']=(h/'ghcn-csv/test/USW00012839.csv','csv')
 files['air2023-npy']=(h/'ncep-npy/test/air.2023.npy','numpy')
 for name,(src,_) in files.items():meta['sources'][name]={'bytes':src.stat().st_size,'sha256':sha(src),'source':src.name}
 (out/'panel-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
 rng=random.Random(meta['seed'])
 with tempfile.TemporaryDirectory() as td,(out/'observations.csv').open('x',newline='',buffering=1) as fh:
  td=Path(td);frame=td/'payload';recovered=td/'recovered';w=None
  for rep in range(6):
   names=list(files);rng.shuffle(names)
   for name in names:
    src,profile=files[name]
    levels=[6,7,9] if profile=='le-i32' else [6,9] if profile=='csv' else [9]
    arms=[('main-'+str(l),[base,'-'+str(l),'-T1','-q','-f',src,'-o',frame],[base,'-d','-T1','-q','-f',frame,'-o',recovered],0) for l in levels]
    if profile=='csv':
     arms += [(label+'-1',[exe,'-1','-T1','-q','-f',src,'-o',frame],[base,'-d','-T1','-q','-f',frame,'-o',recovered],0) for exe,label in [(base,'main'),(experiment,'experiment')]]
    for mode in [*levels,'trained']:
     train=mode=='trained'
     opts=['-c',graph[profile]] if train else ['-p',profile,'-l',str(mode)]
     arms.append(('openzl-'+str(mode),[z,'compress',*opts,'-f',src,'-o',frame],[z,'decompress','-f',frame,'-o',recovered],graph[profile].stat().st_size if train else 0))
    rng.shuffle(arms)
    for order,(label,enc,dec,side) in enumerate(arms):
     en=timed(enc,td);de=timed(dec,td)
     recovered_hash=sha(recovered);expect=meta['sources'][name]['sha256'];assert recovered_hash==expect
     row={'input':name,'profile':profile,'arm':label,'repeat':rep,'order':order,'original_bytes':src.stat().st_size,'original_sha256':expect,'frame_bytes':frame.stat().st_size,'frame_sha256':sha(frame),'decoded_sha256':recovered_hash,'decoder_side_bytes':0,'encoder_graph_bytes':side,'encode_ns':en[0],'decode_ns':de[0],'encode_cpu_s':en[1],'decode_cpu_s':de[1],'encode_rss_B':en[2],'decode_rss_B':de[2],'load1':os.getloadavg()[0]}
     if not w:w=csv.DictWriter(fh,fieldnames=row);w.writeheader()
     w.writerow(row);frame.unlink();recovered.unlink()
   print('pass',rep,'complete',flush=True)
if __name__=='__main__':main()
