"""Separate frame-only, one-time encoder deployment, and amortized portfolio storage."""
import csv,hashlib,json,statistics,sys
from collections import defaultdict
from pathlib import Path
root=Path(__file__).resolve().parent
meta=json.loads((root/'panel-manifest.json').read_text())
raw=list(csv.DictReader((root/'observations.csv').open()))
g=defaultdict(list)
for r in raw:
 assert r['original_sha256']==r['decoded_sha256']==meta['sources'][r['input']]['sha256']
 g[r['input'],r['arm']].append(r)
s=[]
for (name,arm),allrows in sorted(g.items()):
 rows=[r for r in allrows if int(r['repeat'])>0]
 assert len(allrows)==6 and len(rows)==5 and len({r['frame_sha256'] for r in rows})==1
 v=rows[0]; n=int(v['original_bytes']);size=int(v['frame_bytes']);side=int(v['encoder_graph_bytes'])
 s.append({'input':name,'profile':v['profile'],'arm':arm,'input_bytes':n,'frame_bytes':size,'decoder_side_bytes':0,'encoder_graph_bytes':side,'frame_plus_encoder_once_B':size+side,'ratio_frame':n/size,'ratio_charge_graph_once':n/(size+side),'encode_MBps':n*1000/statistics.median(int(r['encode_ns']) for r in rows),'decode_MBps':n*1000/statistics.median(int(r['decode_ns']) for r in rows),'combined_MBps':n*1000/statistics.median(int(r['encode_ns'])+int(r['decode_ns']) for r in rows),'encoder_peak_rss_B_median':statistics.median(int(r['encode_rss_B']) for r in rows),'decoder_peak_rss_B_median':statistics.median(int(r['decode_rss_B']) for r in rows),'frame_sha256':v['frame_sha256']})
with (root/'score.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=s[0]);w.writeheader();w.writerows(s)
old=json.loads(Path(sys.argv[1]).read_text())
historical=[]
for profile,group in [('csv','ghcn-csv'),('numpy','ncep-npy')]:
 side=meta['profiles'][profile]['graph_bytes'];base_sum=trained_sum=0
 for name,v in old.items():
  if group+'/test/' not in name:continue
  b=next(r['size'] for r in v['rows'] if r['tool']=='kolmo -9')
  trained=next(r['size'] for r in v['rows'] if r.get('trained') is True)
  base_sum+=b;trained_sum+=trained
  historical.append({'set':group,'file':Path(name).name,'v002_level9_B':b,'openzl_trained_frame_B':trained,'encoder_once_B':side,'frame_smaller_pct':100*(1-trained/b),'including_graph_smaller_pct':100*(1-(trained+side)/b)})
 historical.append({'set':group,'file':'all-four-pooled','v002_level9_B':base_sum,'openzl_trained_frame_B':trained_sum,'encoder_once_B':side,'frame_smaller_pct':100*(1-trained_sum/base_sum),'including_graph_smaller_pct':100*(1-(trained_sum+side)/base_sum)})
with (root/'historical-size-correction.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=historical[0]);w.writeheader();w.writerows(historical)
lines=['# B25 · Typed numerical data and weather files','',
 'Measured the exact pinned-main CLI and the opt-in integration on the Apple M5 against OpenZL 0.3.0 (50f8789a) in a separate, matched CLI run. Every measured result includes a complete frame, full decode and an untimed SHA-256 check. The randomized records include one warmup and five scored observations. Both phases include process launch, file I/O and, for a trained encoder, reading its graph. Combined throughput uses the median of the observed encode-plus-decode wall times; the old panel’s independent best-phase timers cannot recover this statistic. This is a shared host, warm filesystem cache and requested Kolmo T1. OpenZL uses its normal CLI configuration. Flag numbers identify each codec’s own quality levels; equal flag numbers do not guarantee matching ratios or speed.','',
 '| Profile and file | Arm | Original B | Complete frame B | One-time encoder graph B | Encode MB/s | Decode MB/s | Combined MB/s |',
 '|---|---|---:|---:|---:|---:|---:|---:|']
for r in s:
 if not (r['input'] in ['miami-csv','air2023-npy','USW00012839-tmax']):continue
 lines.append('| '+ ' | '.join([r['input'],r['arm'],f"{r['input_bytes']:,}",f"{r['frame_bytes']:,}",f"{r['encoder_graph_bytes']:,}",f"{r['encode_MBps']:.2f}",f"{r['decode_MBps']:.2f}",f"{r['combined_MBps']:.2f}"])+' |')
lines+=['','## What the typed integer transfer shows','',
 'Derived a defined product from each station CSV: one signed little-endian int32 TMAX observation per data row, in order, using INT32_MIN for an empty field. The local input filenames carry the .u32 suffix, while both serialization and OpenZL profile are signed le-i32. Fixing this representation removes a parsing ambiguity. This lane verifies and compresses the derived observations only; missing flags, dates and other CSV columns are not recoverable from that vector. The full CSV lane separately verifies every byte of the original file. Four previously enumerated training stations and four different test stations share NOAA GHCN as producer. Their hashes and names are in splits.json. This is a station holdout, not an unseen-producer holdout. The same split had previously been used for a full CSV benchmark. The new le-i32 encoder has never trained on test station bytes.','',
 '| Test station | Kolmo L9 B | OpenZL untrained L9 B | OpenZL trained B | Trained + 1 full encoder graph B | Kolmo / untrained / trained combined MB/s |','|---|---:|---:|---:|---:|---:|']
for name in sorted({r['input'] for r in s if r['profile']=='le-i32'}):
 by={r['arm']:r for r in s if r['input']==name}
 arms=[by[a] for a in ['main-9','openzl-9','openzl-trained']]
 sizes=' | '.join(f"{a['frame_bytes']:,}" for a in arms); speeds=' / '.join(f"{a['combined_MBps']:.2f}" for a in arms)
 lines.append(f"| {name} | {sizes} | {arms[-1]['frame_plus_encoder_once_B']:,} | {speeds} |")
lines+=['','## Storage and workload boundaries','',
 'All OpenZL test frames decoded using only the built-in decoder (no profile, graph or dictionary argument). Decoder-side bytes beyond the complete frame were zero. The serialized compressor is a one-time encoder deployment cost, not part of the archived frame: CSV 36,560 B, NumPy 3,912 B, fresh signed int32 1,032 B. Shared binary code is not added to either codec’s frame size; executable digests and lengths are recorded. The trained CSV and NumPy graphs were reused from the original profile-specific run. Recorded training durations were 941.57 and 1,234.74 seconds. The fresh int32 graph trained in 10.33 seconds. The timing CSV excludes these offline training times. Warm invocations include graph loading. Across K files sharing one encoder, charge the graph once to the sum of complete frames.','',
 'In the historical v0.0.2 comparison, charging the 36,560-byte CSV graph in full per station changes the GHCN size advantage from 19.90–23.75% frame-only to 7.45–13.31%. Across four complete held-out stations it is 19.03% with one deployment. Across four 2023 NCEP grids the old trained NumPy frames plus one graph are collectively 11.12% larger than historical Kolmo L9. Relative humidity was the lone winning grid. These historical sizes are labeled separately from the current-main rows. NCEP training used 2022 and tests use 2023; variables and producer overlap. Fresh whole-file NumPy speed is for the air grid only.','',
 'Replay prepare.py with BENCH_PAGE and OUTPUT, then compare.py with BENCH_PAGE MAIN_KOLMO EXPERIMENTAL_KOLMO OUTPUT. Run score.py with the original results/panel.json to reproduce the historical size correction. Corpus retrieval, source revisions and data split recipe are in bench/repro on main. The two cached original encoder graphs and the fresh integer graph accompany the evidence. Re-training may generate a different graph; for exact speed/size replay use these binary artifacts by hash.']
lines+=['','## Decision on typed integer routing','', 'Across all four held-out TMAX vectors, Kolmo L9 used 78,690 bytes, OpenZL untrained L6 used 91,928 bytes, and both untrained L7 and L9 used 67,999 bytes. The trained frames used 67,902 bytes. Training saved only 97 further bytes on the four transferred vectors; charging its 1,032-byte encoder once yields 68,934 bytes, 935 more than the untrained L7/L9 total. The untrained L7 numeric graph is therefore the better model-free research target for this typed representation. Prototype explicit type admission and bounded numeric transforms, then test other signed/unsigned widths, missingness and unrelated producers. One weather field and four stations cannot qualify a shipping default.']
(root/'README.md').write_text('\n'.join(lines)+'\n')
