"""Make one fixed-width weather series per station; serialize observations with explicit missing sentinel."""
import csv,hashlib,json,shutil,struct,subprocess,sys,time
from pathlib import Path
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=Path(sys.argv[1]); out=Path(sys.argv[2]).resolve()
hold=d/'data/holdout'; zli=d/'tools/openzl/build/cli/zli'
paths={}
for group in ('ghcn-csv','ncep-npy'):
 for split in ('train','test'):
  items=sorted((hold/group/split).iterdir())
  paths[group+'/'+split]=[{'name':f.name,'bytes':f.stat().st_size,'sha256':sha(f)} for f in items if f.is_file()]
v={}
for split in ('train','test'):
 p=out/'derived'/split; p.mkdir(parents=True,exist_ok=True)
 for f in sorted((hold/'ghcn-csv'/split).glob('*.csv')):
  target=p/(f.stem+'.u32')
  vals=[]
  with f.open() as h:
   for row in csv.DictReader(h):
    value=row.get('TMAX','').strip()
    vals.append(int(value) if value else -2147483648)
  target.write_bytes(struct.pack('<%di'%len(vals),*vals))
  v[split+'/'+target.name]={'source':f.name,'source_sha256':sha(f),'field':'TMAX','missing_sentinel':-2147483648,'rows':len(vals),'bytes':target.stat().st_size,'sha256':sha(target)}
inputs=set(x['sha256'] for k,x in v.items() if k.startswith('train/'))
assert len(inputs)==4 and all(x['sha256'] not in inputs for k,x in v.items() if k.startswith('test/'))
(out/'splits.json').write_text(json.dumps({'source_splits':paths,'typed_station_inputs':v},indent=2)+'\n')
args=[str(zli),'train','-p','le-i32',str(out/'derived/train'),'-o',str(out/'typed-weather.zlc'),'-f','--max-time-secs','20']
start=time.monotonic()
with (out/'training.log').open('w') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
graph=out/'typed-weather.zlc';meta={'returncode':r.returncode,'elapsed_s':time.monotonic()-start,'argv':args[1:],'bytes':graph.stat().st_size if graph.exists() else None,'sha256':sha(graph) if graph.exists() else None}
(out/'training.json').write_text(json.dumps(meta,indent=2)+'\n')
if r.returncode:raise SystemExit(r.returncode)
