"""Collate per-cell matched ratios with independent same-binary controls."""
import csv,json,statistics,pathlib,sys,collections
p=pathlib.Path(sys.argv[1]);rows=list(csv.DictReader((p/'micro.csv').open())); med=statistics.median
out=[]
for n,shape in sorted(set((int(r['bytes']),r['shape']) for r in rows)):
    arms={a:[x for x in rows if x['bytes']==str(n) and x['shape']==shape and x['arm']==a] for a in ['base','base-AA','bounded','unlimited']}
    for arm in ['bounded','unlimited']:
        ar=arms[arm]; base=arms['base'];aa=arms['base-AA']
        item=dict(bytes=n,shape=shape,arm=arm,stored=ar[0]['stored'],trials=len(ar))
        vals=[((float(x['enc_ns'])+float(y['enc_ns']))/2,(float(x['dec_ns'])+float(y['dec_ns']))/2,float(z['enc_ns']),float(z['dec_ns'])) for x,y,z in zip(base,aa,ar)]
        item.update(base_enc_ns=med(x[0] for x in vals),base_dec_ns=med(x[1] for x in vals),new_enc_ns=med(x[2] for x in vals),new_dec_ns=med(x[3] for x in vals),
                    paired_encode_speedup=med(x[0]/x[2] for x in vals),paired_decode_speedup=med(x[1]/x[3] for x in vals),
                    paired_combined_speedup=med((x[0]+x[1])/(x[2]+x[3]) for x in vals),
                    new_dec_faster_pairs=sum(x[1]>x[3] for x in vals),aa_dec_ratio=med(float(x['dec_ns'])/float(y['dec_ns']) for x,y in zip(base,aa)))
        out.append(item)
with (p/'micro-summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=out[0]);w.writeheader();w.writerows(out)
if (p/'cli-times.csv').exists():
    rows=list(csv.DictReader((p/'cli-times.csv').open()));summ=[]
    for name in sorted({r['name'] for r in rows}):
        arms={a:[x for x in rows if x['name']==name and x['arm']==a] for a in ['base','base-AA','bounded']}
        q=dict(name=name,raw=arms['base'][0]['raw'],stored=arms['base'][0]['stored'],eligible=arms['base'][0]['eligible'])
        for arm in ['base','bounded']:
            rr=arms[arm]
            q[arm+'_enc_ms']=med(1000*float(r['encode_s']) for r in rr);q[arm+'_dec_ms']=med(1000*float(r['decode_s']) for r in rr)
            q[arm+'_combined_MB_s']=float(q['raw'])/1e6/med(float(r['encode_s'])+float(r['decode_s']) for r in rr)
        summ.append(q)
    with (p/'cli-summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=summ[0]);w.writeheader();w.writerows(summ)
