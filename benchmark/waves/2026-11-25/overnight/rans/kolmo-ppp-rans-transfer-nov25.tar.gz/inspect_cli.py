"""Observational decode, without timing the instrumented path. All inputs are valid project fixtures."""
import argparse,csv,hashlib,json,pathlib,re,subprocess,tempfile,random,statistics,time,os
from pathlib import Path
ap=argparse.ArgumentParser()
for k in ['main','candidate','trace','corpus','holdout','out']:ap.add_argument(k,type=Path)
args=ap.parse_args(); d=args.out
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(argv):return subprocess.run(argv,capture_output=True,check=True)
def timed(argv):
 t=time.monotonic();pid=os.posix_spawn(str(argv[0]),list(map(str,argv)),os.environ);_,rc,res=os.wait4(pid,0);assert os.waitstatus_to_exitcode(rc)==0
 return time.monotonic()-t,res.ru_utime+res.ru_stime,res.ru_maxrss
cases=[]; reps=[];fresh=[]
with tempfile.TemporaryDirectory() as tmp:
    tmp=Path(tmp);rest=tmp/'restored'
    def profile(tag,frame,source):
        r=run([args.trace,'-d','-T','1','-f','-q',frame,'-o',rest]);assert sha(rest)==sha(source)
        hits=[(int(a),int(b)) for a,b in re.findall(rb'RANS-OBS (\d+) (\d+)',r.stderr)]
        row=dict(name=tag,frame_sha256=sha(frame),source_sha256=sha(source),frame_bytes=frame.stat().st_size,raw=source.stat().st_size,chunks=hits,short_pairs=sum(n<=4096 and k==2 for n,k in hits))
        cases.append(row)
        return row
    for line in (args.corpus/'MANIFEST').open():
        frame,raw=line.split()
        profile(frame,args.corpus/frame,args.corpus/raw)
    # Two real text/binary mixtures and a typed source, plus an isolated numeric control.
    rng=random.Random(357);targets=[]
    for name in ['weights__smollm2-bf16','img16__mr','text__reymont']:
        src=tmp/name;src.write_bytes((args.holdout/name).read_bytes()[:262144]);targets.append(src)
    for name in ['f64.npy','bf16.st']:
        targets.append(args.corpus/name)
    for src in targets:
        for level in [3,6,9]:
            frame=tmp/(src.name+'-'+str(level)+'.kolmo'); cand=tmp/'candidate'
            run([args.main,'-'+str(level),'-T','1','-q','-f',src,'-o',frame])
            run([args.candidate,'-'+str(level),'-T','1','-q','-f',src,'-o',cand]);assert sha(frame)==sha(cand)
            rc=profile(frame.name,frame,src);fresh.append(rc['name'])
            for it in range(5):
                for arm in rng.sample(['base','base-AA','bounded'],3):
                    exe=args.candidate if arm=='bounded' else args.main
                    e,ec,er=timed([exe,'-'+str(level),'-T','1','-q','-f',src,'-o',cand])
                    assert sha(cand)==rc['frame_sha256']
                    de,dc,dr=timed([exe,'-d','-T','1','-q','-f',frame,'-o',rest]);assert sha(rest)==rc['source_sha256']
                    reps.append(dict(name=frame.name,rep=it,arm=arm,raw=src.stat().st_size,stored=frame.stat().st_size,
                        encode_s=e,decode_s=de,encode_cpu=ec,decode_cpu=dc,encode_rss=er,decode_rss=dr,eligible=rc['short_pairs']))
    (d/'cli-coverage.json').write_text(json.dumps(cases,indent=2)+'\n')
    with (d/'cli-times.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=reps[0]);w.writeheader();w.writerows(reps)
    (d/'cli-binaries.json').write_text(json.dumps({a:sha(getattr(args,a)) for a in ['main','candidate','trace']},indent=2)+'\n')
