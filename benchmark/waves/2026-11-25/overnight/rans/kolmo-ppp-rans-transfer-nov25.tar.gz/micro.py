"""Direct native graph-leaf rANS benchmark on valid deterministic short, medium and large streams."""
import argparse, collections, csv, ctypes as C, hashlib, json, pathlib, random, statistics, subprocess, tempfile, time
from pathlib import Path
ap=argparse.ArgumentParser()
ap.add_argument('main',type=Path);ap.add_argument('candidate',type=Path);ap.add_argument('out',type=Path)
args=ap.parse_args()
def build(root,d,label):
    # Compile the same graph rANS translation-unit fragment and varint helper as the shipping direct caller.
    s=(root/'src/codecs/rans.c').read_text().split('static size_t rans_codec_compress(')[0]
    if label=='unlimited':
        old='used == 2 && m <= 4096' if 'used == 2 && m <= 4096' in s else 'n && n <= 4096'
        assert s.count(old)==1
        s=s.replace(old,'used == 2' if old.startswith('used') else 'n')
    pre='#include <stdlib.h>\n#include <stdint.h>\n#include <string.h>\n#include <math.h>\n#include "varint.h"\n'
    wrappers='''
size_t enc(const uint8_t *s,size_t n,uint8_t *z,size_t cap) { return rans_compress_all_x(s,n,z,cap,1); }
int dec(const uint8_t *z,size_t cz,uint8_t *dst,size_t n){ return rans_decompress_all(z,cz,dst,n); }
int enc_loop(const uint8_t *s,size_t n,uint8_t *z,size_t cap,size_t expect,unsigned loops) {
    for(unsigned i=0;i<loops;++i) if(enc(s,n,z,cap)!=expect)return -1;
    return 0;
}
int dec_loop(const uint8_t *z,size_t cz,uint8_t *dst,size_t n,unsigned loops) {
    for(unsigned i=0;i<loops;++i) if(dec(z,cz,dst,n))return -1;
    return 0;
}
'''
    src=d/(label+'.c');dll=d/(label+'.dylib');src.write_text(pre+(root/'src/algo/hist.c').read_text()+s+wrappers)
    subprocess.run(['cc','-O3','-mcpu=native','-ffp-contract=off','-I'+str(root/'src/algo'),'-dynamiclib',src,'-o',dll],check=True)
    lib=C.CDLL(str(dll)); buf=C.c_void_p;u=C.c_size_t
    for fn,rt,types in [('enc',u,[buf,u,buf,u]),('dec',C.c_int,[buf,u,buf,u]),('enc_loop',C.c_int,[buf,u,buf,u,u,C.c_uint]),('dec_loop',C.c_int,[buf,u,buf,u,C.c_uint])]:
        f=getattr(lib,fn);f.restype=rt;f.argtypes=types
    return lib
def raw(n,shape):
    rng=random.Random(1009+n)
    data=rng.randbytes(n)
    if shape=='constant':return b'\xfd'*n
    if shape=='even':return bytes(241 if x&1 else 7 for x in data)
    if shape=='rare':return bytes(253 if (x==0 or i==n-1) else 11 for i,x in enumerate(data))
    if shape=='three':return bytes([11,71,233][x%3] for x in data)
    return data
def unique_data(size,shape):
    s=raw(size,shape)
    if shape in ('rare','even','three'):
        pre={'rare':bytes([11,253]),'even':bytes([7,241]),'three':bytes([11,71,233])}[shape]
        if size>=len(pre):s=pre+s[len(pre):]
    return s
def digest(s):return hashlib.sha256(s).hexdigest()
with tempfile.TemporaryDirectory() as tmp:
    d=Path(tmp)
    libs={k:build(source,d,k) for k,source in [('base',args.main),('bounded',args.candidate),('unlimited',args.candidate)]}
    rng=random.Random(17035); cells=[]; exact=[]; records=[]
    for n in [1,2,3,4,7,15,16,31,32,64,256,1024,4095,4096,4097,16384,65536,262144]:
        for sh in ['constant','rare','even','three','random']:
            s=unique_data(n,sh);capacity=max(4096,n*2+2048); streams={};scratch=C.create_string_buffer(n)
            for k,lib in libs.items():
                z=C.create_string_buffer(capacity);size=lib.enc(s,n,z,capacity)
                assert size>0
                streams[k]=z.raw[:size]
            assert len(set(streams.values()))==1
            z=streams['base']
            for lib in libs.values():
                assert lib.dec(z,len(z),scratch,n)==0 and scratch.raw==s
            exact.append(dict(n=n,shape=sh,distinct=len(set(s)),input_sha256=digest(s),stored_bytes=len(z),frame_sha256=digest(z)))
            if n in [32,256,1024,4096,16384,65536,262144] and sh in ['even','rare','three','random','constant']:
                cells.append((s,z,sh,capacity))
    (args.out/'micro-exact.json').write_text(json.dumps(exact,indent=2)+'\n')
    compound=[]
    for sizes in [(1,2),(3,5),(32,256),(2048,2048),(4095,1),(4096,1),(16384,63),(1048576,64),(1048577,63)]:
        bodies=[unique_data(size,'even' if i==0 else 'three') for i,size in enumerate(sizes)]
        frames=[]
        for body in bodies:
            cap=len(body)*2+2048; units=[]
            for lib in libs.values():
                dest=C.create_string_buffer(cap)
                count=lib.enc(body,len(body),dest,cap);assert count
                units.append(dest.raw[:count])
            assert len(set(units))==1;frames.append(units[0])
        joined=b''.join(bodies);stream=b''.join(frames)
        decoded=C.create_string_buffer(len(joined))
        for lib in libs.values():
            assert lib.dec(stream,len(stream),decoded,len(joined))==0 and decoded.raw==joined
        compound.append(dict(parts=sizes,joined_bytes=len(joined),stored_bytes=len(stream),input_sha256=digest(joined),frame_sha256=digest(stream)))
    (args.out/'multi-chunk.json').write_text(json.dumps(compound,indent=2)+'\n')
    for repeat in range(7):
        for s,z,sh,capacity in rng.sample(cells,len(cells)):
            n=len(s); loops=max(4,min(2048,262144//n)); scratch=C.create_string_buffer(n);zbuf=C.create_string_buffer(capacity)
            for arm in rng.sample(['base','base-AA','bounded','unlimited'],4):
                lib=libs['base' if arm=='base-AA' else arm]
                t=time.perf_counter_ns();ok=lib.enc_loop(s,n,zbuf,capacity,len(z),loops);e=time.perf_counter_ns()-t
                assert ok==0 and zbuf.raw[:len(z)]==z
                t=time.perf_counter_ns();ok=lib.dec_loop(z,len(z),scratch,n,loops);dd=time.perf_counter_ns()-t
                assert ok==0 and scratch.raw==s
                records.append(dict(repeat=repeat,arm=arm,bytes=n,shape=sh,loops=loops,enc_ns=e/loops,dec_ns=dd/loops,stored=len(z)))
    with (args.out/'micro.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=records[0]);w.writeheader();w.writerows(records)
