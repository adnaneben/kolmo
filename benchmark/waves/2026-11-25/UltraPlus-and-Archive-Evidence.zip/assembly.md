# Assembly and fast archives

## What the earlier reviews established

| Track | Verified state | Disposition |
| --- | --- | --- |
| Claude rc2 x86 dispatch | Generic x86 builds had lost a CSV decimal-formatting fast path. Historical runtime dispatch recovered 19–23% decode time on its numeric CSV, and exact frames were preserved. Silesia fast archive throughput did not show a consistent gain from dispatch alone. | Keep runtime dispatch; reproduce on native v12 before assigning the old throughput numbers to current builds. |
| Claude rc3 intrinsics | Historical x86 A/B used 17 inputs, one and four threads, and an A/A control. Across 136 cases its geometric mean was 1.043× encode and 1.083× decode, with 170 frame-identical configurations. On ARM64, image, integer and video inverses benefited most. | Prefer targeted intrinsics. The repository keeps the prior rejected VEX/AVX-512 inverse and NEON word-encode results. |
| Handwritten assembly | Both architecture histogram kernels exist. x86 uses the assembly kernel from 16 KiB, while AArch64 requires `-DKOLMO_HIST_AARCH64`. Its stock correctness suite passed on this Apple M5. The historical x86 histogram had material microbench wins on runs, and was below noise in the CLI. Claude's other handwritten loops were within 2% or slower. | Keep measured dispatch boundaries. Require an exact portable reference and a paired end-to-end win before introducing another assembly kernel. |
| Codex NEON mixer | PR #63 adds opt-in intrinsics for the integer CM4 dot product and weight update. The archive handoff contains 7 paired samples per input and identical frames. Combined throughput improved 10–17% on three direct mixer/codec cases. | Preserve opt-in. Confirm end-to-end Ultra and larger data at 1, 2, 4 and maximum threads on macOS and Linux ARM before changing default. |
| Machine-code data | The x86 E8/E9 filter already screens candidates with SSE2/NEON. R21 proposed 32-position AVX2 scanning with the original order; this is pending native measurements. PR #76 classifies sectionless AArch64 ELF to reuse an existing v12 instruction transform; it adds no handwritten assembly. PR #80 is an opt-in exact source-identifier dictionary. | Measure real COFF/PE, ELF and Wasm by architecture, size, opcode density, and stripping. Keep related compiler outputs together in holdout splits. |

`KOLMO_CPU=c` forces C for the selected dispatch table (on ARM, the CM4 mixer under test). It leaves direct compile-time paths alone. `NO_ASM=1` drops the `.S` objects and disables the table's SIMD entries. Several direct paths still select intrinsics from compiler macros, including x86 relative branches, word/transpose/table helpers, CRC32C, decimal formatting and vector KHash. A fully scalar reference requires separate explicit gates plus compiler auto-vectorization controls. The old `NO_ASM` comparisons establish frame parity for the covered paths, not all-scalar timings.

Primary project references: `benchmark/rc2/SIMD-ASM.md`, `benchmark/rc3/simd-arm/RESULTS.md`, `benchmark/rc3/simd-x86/RESULTS.md`, `benchmark/rc3/structure/RESULTS.md`, `src/arch/cpu.c`, `src/arch/cpu.h`, `src/algo/hist.c`, prior handoff PR #85.

## Verified Gear scan candidate

Compute two rolling Gear states directly from the incoming state. Test the first position before the second and carry the exact state across the same two mask regions. All original boundaries, including minimum length, the small/large-mask seam, odd tails and optional file line extension are preserved. The two-byte formulation is described in [Xia et al., IEEE TPDS 31(9), 2020](https://ieeexplore.ieee.org/abstract/document/9055082/).

The candidate is portable C. Its native Python and Rust mirrors are identical. All 3,708 feature checks passed. ASan/UBSan matched the old cuts under supported targets from 256 B through 4 MiB, line-cut options, short tails and constant data. The harness compiled for x86-64 Mach-O, without an x86 runtime measurement.

| Scope | Paired median speedup |
| --- | --- |
| Gear scan in isolation, Apple M5, Silesia and enwik8 prefixes, 1/16 MiB, 1/4/16 KiB targets | 1.277–1.302× over 12 cells; paired A/A 0.990–1.006× |
| Actual archive creation, 16 MiB copy-heavy Silesia, one/four threads | 1.080× / 1.083× |
| Actual archive creation, 16 MiB copy-heavy enwik8, one/four threads | 1.061× / 1.049× |
| Remaining 1/16 MiB disjoint or 1 MiB copy-heavy cells | 0.999–1.072×; use as controls pending additional workloads |

Creation runs are seven initial or fifteen stronger randomized A/B/A triplets after warmup, including process startup and output publication. Each input set contains eight deterministic members totaling 1 or 16 MiB with either disjoint source spans or exact copies. Fresh Wave 2 decoded each candidate archive exactly. Each cell had one archive SHA-256 across every arm. Preliminary Silesia cells suggested 2–5% losses for some 1 MiB duplicate and 16 MiB disjoint contexts. Their A/A controls drifted similarly. Those losses did not reproduce across the stronger two-source recheck. Keep every initial and repeat row. Prioritize this candidate on Apple ARM64 duplicate-heavy archives; verify native x86/Linux and naturally versioned assets before enabling it by default.

## High-speed archive priorities

1. Land the separate linear DDP1 parsed-index visitor after exact readback and bench named reads and listings by member count. Compare outputs and paths with the same atomic publication policy.
2. Keep the two-byte CDC scan as the first encode candidate. Next prototype bounded per-file cut and fingerprint jobs with a deterministic first-seen ID reduction. Run the same archives at T1, T4, T10 and default; preserve file-order bytes and restore all entries. The current dedup scan and distinct-set reduction are serial ahead of already-threaded codec work.
3. Profile the two seeded KHash passes and copying of the distinct store. On unique-heavy data, first try reuse of already-loaded stripes for both existing hashes and hash-on-copy. Avoid extra check hashing on duplicates and verify the exact stored checksum and archive bytes. Independently measure cache, syscall and memory bounds.
4. Build descriptors or staged spill into large archives so input maps, the full unique-chunk store and the full outgoing archive need not be resident together. Measure sequential warm and cold files, concurrent I/O, and equal atomicity. Benchmark any bounded extraction pipeline with cancellation, name validation and safe staged output.
5. Compare small-file metadata and random-list/extract latency with GNU tar plus zstd or lz4, seekable zstd, Zip, 7-Zip, and supported dedup backups such as Borg and restic. Use archive size, archive wall time, listing/first-member latency, full restore, peak RSS and exact bytes plus metadata. Split solid archives, snapshot repositories and compression-only API tests. [Zstandard seekable format](https://github.com/meta/zstd/blob/dev/contrib/seekable_format/README.md)
6. Investigate low-cost parser changes and offset-1 long-run copies only where profiling shows them. Add platform-specific SIMD on hot histogram, hash, and candidate scan loops after reproducible end-to-end wins; investigate accelerator batching only with transfers, synchronization, device availability and CPU fallback included. [NVIDIA nvCOMP](https://docs.nvidia.com/cuda/nvcomp/index.html)

Separate defensive note: the existing Gear table initialization is unsynchronized across simultaneous archive API calls. Use a one-time initialization primitive in a separate change and retain concurrent exact-frame tests.
