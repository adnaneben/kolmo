# High-speed archiving baseline and options

The Apple M5 screen separated same-byte tar compression from directory archive creation, full extraction, two named selections, and first recovered byte through a pipe. It used Wave 2 #73 from commit dcbf4831, Zstandard 1.5.7, LZ4 1.11.1, 7-Zip 26.06, and Apple bsdtar 3.5.3. It used three randomized repetitions per setting and requested 1 or 4 threads. Zstandard and LZ4 used their standard decoder paths, and the thread label describes the requested encode setting and Kolmo's requested decode setting. Host load was shared. Every accepted row recovered the same input SHA-256 or the same relative paths, sizes, and per-file hashes. Times include subprocess launch and file I/O. Median timings are directional, especially for short operations.

## Exact Silesia tar

Input 211,947,520 bytes. Encode and decode are file-to-file wall medians. Kolmo uses staged output, and other tools use their own standard output handling.

| Arm | Stored bytes | T1 encode ms | T1 decode ms | T4 encode ms | T4 decode ms |
| --- | ---: | ---: | ---: | ---: | ---: |
| Kolmo level 1 | 87,130,630 | 268.40 | 71.15 | 119.35 | 44.69 |
| Kolmo level 2 | 69,794,182 | 361.80 | 118.31 | 153.39 | 71.62 |
| Zstd fast=1 | 86,952,249 | 271.27 | 102.36 | 100.08 | 115.55 |
| Zstd level 1 | 73,292,646 | 276.08 | 126.63 | 126.00 | 152.05 |
| LZ4 level 1 | 100,338,346 | 215.71 | 73.32 | 84.58 | 98.89 |

Kolmo L1 is close to Zstd fast in stored bytes and T1 encode wall time on Silesia, with faster observed decode. Its T4 encode median ranged from 94.93 ms to 119.35 ms across the framed and streaming comparison groups. LZ4 retains the encode speed advantage and writes more bytes. Prior in-memory lzbench LZAV 7.1 measured 660.55/3,597.97 MB/s encode/decode and 83,147,688 bytes versus Kolmo L1 668.31/3,652.15 MB/s and 87,130,630 bytes. Keep the LZAV comparison in the original memory-only scope. The fresh matrix also includes the same operations on a 4 MiB Silesia prefix.

## Directory archives

The unique-small and duplicate-small fixtures each contain 768 generated regular files, each 8 KiB. The duplicate set uses 32 templates repeated across directories. The mixed case has four members totaling 28 MiB from public Silesia and enwik8 bytes. Named wall times select exact paths, lexicographically first and last. They measure product behavior including integrity checks and file extraction. Generic tar streams scan through the input when the tested tool requires it. Metadata beyond file names was outside this byte-preservation benchmark.

| Workload | Threads | Arm | Bytes | Create ms | Full extract ms | Named first / last ms |
| --- | ---: | --- | ---: | ---: | ---: | ---: |
| Duplicate small | 1 | Kolmo L1 | 162,266 | 34.45 | 166.60 | 19.64 / 20.15 |
| Duplicate small | 1 | 7-Zip solid, -mx1 | 122,067 | 53.54 | 57.32 | 3.20 / 8.29 |
| Duplicate small | 4 | Kolmo L1 | 162,266 | 33.03 | 171.25 | 19.22 / 19.71 |
| Duplicate small | 4 | 7-Zip solid, -mx1 | 723,366 | 43.58 | 51.32 | 2.97 / 8.98 |
| Unique small | 4 | Kolmo L1 | 3,685,057 | 39.61 | 167.51 | 31.38 / 31.26 |
| Unique small | 4 | 7-Zip nonsolid, -mx1 | 3,445,941 | 250.85 | 154.99 | 3.52 / 3.25 |
| Mixed large | 4 | Kolmo L1 | 13,249,884 | 62.99 | 15.53 | 7.54 / 5.77 |
| Mixed large | 4 | Tar and Zstd L1 | 10,786,274 | 29.61 | 31.64 | 28.10 / 27.56 |
| Mixed large | 4 | Tar and LZ4 L1 | 15,065,564 | 32.03 | 28.50 | 20.98 / 20.22 |
| Mixed large | 4 | 7-Zip nonsolid, -mx1 | 9,002,547 | 216.21 | 73.51 | 20.05 / 12.83 |

The stable archive bytes under Kolmo's thread settings and the 7-Zip solid byte change make single-thread and multithread archive sizing separate competitive measurements. A collection with high deduplication favors Kolmo creation throughput and size over the tested tar filters. The strongest solid archive may still write less at a given thread setting. Many-small full extraction is the clear Kolmo weakness in this test.

Retested archive chunk targets of 16 and 64 KiB against the 4 KiB default at both thread settings across the three directory cases. Bytes improved by 0.14–0.28% on duplicate/mixed cases, but worsened by 0.29–0.31% on unique small. Create time direction was consistently slower in this shared-host screen. Keep the default and the rejected receipts. A near-identical file and insertion stream from a separate source is needed before pursuing catalogue-level chunk parameter selection.

## First recovered byte

Full Silesia, four requested threads. First byte is time from pipe launch to the first recovered raw byte. The entire input is then verified with SHA-256. Watched completion includes the Python stream monitor, so it is a separate end-to-end wall metric.

| Arm | First ms | First 1 MiB ms | Watched completion ms |
| --- | ---: | ---: | ---: |
| Kolmo default | 163.25 | 163.50 | 305.50 |
| Kolmo fixed 1 MiB | 8.19 | 8.52 | 449.85 |
| Kolmo fixed 4 MiB | 12.01 | 12.76 | 250.29 |
| Kolmo fixed 64 MiB | 76.00 | 76.57 | 257.95 |
| Zstd fast=1 | 6.13 | 10.18 | 199.02 |
| LZ4 level 1 | 22.34 | 22.70 | 171.04 |

A standalone linked C harness wrote a 1 MiB CZNS member followed by ordinary 16 or 64 MiB streaming from the same input. A Wave 2 decoder recovered the concatenation exactly with ordinary decoding. The first-portion harness used two stream envelopes. A native single-envelope prototype may differ by the extra stream header plus terminator. The follow-up measured all 72 exact trials on two input families and 1/4 threads.

| Input | Threads | Fixed → 1+16 MiB first ms | Watched completion ms | Fixed → 1+16 MiB stored bytes |
| --- | ---: | ---: | ---: | ---: |
| Silesia | 1 | 51.78 → 7.92 | 435.59 → 402.15 | 91,290,723 → 91,212,643 |
| Silesia | 4 | 26.31 → 7.80 | 217.28 → 207.59 | 91,290,723 → 91,212,643 |
| enwik8 | 1 | 73.36 → 6.78 | 325.35 → 286.41 | 49,024,971 → 49,039,354 |
| enwik8 | 4 | 32.62 → 9.35 | 168.74 → 146.66 | 49,024,971 → 49,039,354 |

The enwik8 increase is +0.029% at both thread settings. The mixed-source Silesia improvement is -0.086%. Some other boundaries lose on size or total time. The evidence supports an explicit first-byte SLA experiment. Keep it out of the fixed-size default under a strict zero-growth rule.

## Priorities beyond the DDP1 reader and byte-scan lanes

1. Add a bounded overlap pipeline for input, compression and verified output. Test deterministic byte output, time to first bytes, throughput and memory at 1/4/10 threads on SSD, cold file cache and network streams. Vary a small first member independently of bulk block policy. Pin CPU quotas when comparing cloud runs.
2. Prototype file-backed dedup assembly using a spool of unique bytes in first-seen order and existing positional compression. Current archive creation maps all members, copies their distinct bytes to a full private store, and allocates a separate output bound. Compare peak RSS, first-output latency, and size across duplicate and unique populations. Preserve exact v12 byte output if the block plan is unchanged.
3. For new-directory restores, evaluate one private staged tree with a single root publish, bounded file writers and strict relative paths. Keep separate staged overwrite semantics when extracting into an existing destination. Measure metadata fidelity, failure behavior and throughput on short small-file jobs and large trees.
4. Add a matched indexed competitor baseline for selective reads. Compare equal member byte ranges and independently verified completeness using 7-Zip nonsolid, seekable Zstandard and, where useful, rapidgzip indexed streams. Separate index build amortization from warm point reads. Report read amplification, cold and warm median/p95, and index overhead.
5. Add corpus axes for actual ENOSPC/drop recovery, names and modes, incompressible prepacked files and inexpensive store routes, each independent of exact frame checksum and archive-semantic requirements. Complete a single-core and multicore same-host LZAV rerun, then check the result on an independently fingerprinted Linux host.

The first archive attempt retained 7-Zip auto-suffix failures. The exact-name option fixed them. The early-read bsdtar path closed its external filter and returned error, and a standard selected extraction validated the same archive cases. The first chunk-size wrapper had a misplaced CLI argument. The corrected attempt reran all three workloads at both thread settings. All failed attempts remain in the raw records.

[Zstandard seekable format](https://github.com/facebook/zstd/blob/dev/contrib/seekable_format/README.md) · [Rapidgzip](https://github.com/mxmlnkn/rapidgzip) · [LZAV](https://github.com/avaneev/lzav)


## Reproduction

Set the scratch output path to a fresh directory. The evidence directory must contain the pinned public files at `mkt/data/silesia.tar` and `mkt/data/enwik8`. Check their SHA-256 values against the manifest before running.

```sh
export KOLMO_RIVALS_WORKDIR=/absolute/path/to/fresh-scratch
export KOLMO_EVIDENCE_DIR=/absolute/path/to/pinned-corpus
export KOLMO_UNDER_TEST=/absolute/path/to/wave2/build/kolmo
mkdir -p "$KOLMO_RIVALS_WORKDIR"
python3 bench.py
python3 supplement.py
python3 corrected.py
cc -O3 -I /absolute/path/to/wave2/src first_segment.c \
    /absolute/path/to/wave2/build/libkolmo.a -lm -lpthread \
    -o "$KOLMO_RIVALS_WORKDIR/first_segment"
python3 first_matrix.py
```

The first two replay stages intentionally repeat the tested command forms that surfaced the retained harness errors. The third stage reruns corrected options. The final stage can run independently once the scratch harness is built.
