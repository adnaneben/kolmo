# Reviewer findings across both previous waves

## Original 40 reviewers

| Reviewer | Area | Findings and recommendation |
| --- | --- | --- |
| 01 | v12 frame envelope | Offset arrays and ordered decode scratch fall outside admission. Extend preflight to bound and charge metadata before allocating. Match file and memory extension structure validation. `src/core/decode.c:40–79,396–407`, `src/api/api.c:90–94,317–324`. |
| 02 | Native streams | Output windows reparse the full index and use a separate memory allowance from inner decode. Reuse a parsed frame and share the budget. `src/core/stream.c:139–165`. |
| 03 | Archive filesystem | Extract directly replaces existing files before write completion. Stage and publish atomically. Create archives from typed opened descriptors to keep bytes and metadata bound to one input. `src/cli/features.c:252–280,293–305,340–348`. |
| 04 | KLZ-family decode | Bound physical tail and match pointers, retaining the v12 lookahead semantics. Draft #50. `src/algo/klz.c:37–46,1040–1102`. |
| 05 | Learning lifecycle | The legacy tuner depends on removed build and CLI interfaces and tunes decoder-visible parameters. Begin with encoder policy and stock-decoder compatibility. Pin research prior hashes. `tune/ga.py:18,34–55,95–100`, `benchmark/impact/kprior.py:6`. |
| 06 | Benchmark CI | README results predate encoder changes. Label exact SHA, settings and units. Remove impact timing bias with paired runs. `README.md:14–40,253–265`, `.github/workflows/bench-x86.yml:10–51`. |
| 07 | Level-1 match search | Adjacent hash load sharing is byte-exact but fell short of the A/B adoption gate. Tiny-block allocation removal remains a separate candidate. `src/algo/klz.c:252–270`. |
| 08 | KLZH2 parsing | Parallel classes rescan and rehash the same chunks. Partition positions once and verify byte identity. Rebase #37 across the elastic entry point. `src/algo/klz.c:491–507,1036`, `src/codecs/native.c:67–70`. |
| 09 | BWT and QLFC | Bound physical range input and validate legacy sampled indexes before conversion. Avoid the output-sized staging copy on the serial path. `src/algo/rangecoder.h:33–36`, `src/codecs/bwt_stream.c:70–73`, `src/algo/qlfc.c:727–768`. |
| 10 | KLZMA | Separate virtual normalization bytes from pointer arithmetic. Reuse the matcher bucketing design with KLZH2 while testing both codecs independently. `src/algo/klzma.c:174–190,501,522,578`. |
| 11 | Context mixing | Numeric table limits are ignored by default Model 4. Reuse repeated initialization probabilities and skip unused rows. `src/codecs/cm.c:310–335,552–557,1137–1140`. |
| 12 | Huffman and rANS | KHUF tail lookahead leaves the input object. Bound the cursor and scale the two-symbol table for short codes. `src/algo/khuf.c:188–246`. |
| 13 | Images | Kimg admission omits predictor error rows, and initialization races. Img16 detection has unchecked allocations. `src/core/memneed.c:68`, `src/codecs/kimg.c:44–82,156–167,318–332`, `src/transforms/sci.c:110–164`. |
| 14 | Audio | Shared architecture-dispatched CRC32C in #55. Separately, reject invalid range segment lengths early and evaluate wider PCM coverage. `src/codecs/audio.c:53–72,1612–1615,1679–1798`. |
| 15 | Video | Whole-file Y4M compression can exceed its explicit decode budget. Validate predictors before scheduling inverse workers. `src/core/compress.c:14–24,68–87`, `src/codecs/video.c:117–150`. |
| 16 | FASTQ | Nested size and token checks in #56. Retain monotonic job cursors as a separate performance candidate. `src/codecs/fastq.c:624–654,852–856,913–935`. |
| 17 | CSV and TSV | Use the caller's bounded buffer and return to generic compression on allocation or size rejection. `src/transforms/table.c:359–617`. |
| 18 | Logs and word transforms | Propagate allocation failures in log serialization and avoid scanning/resetting unused word-table slots. `src/transforms/log.c:41–46,318–369`, `src/transforms/word.c:46–89`. |
| 19 | Typed graph | Bound intermediate inverse materialization and dispatch only format-admitted leaf codecs. Serialize directly where capacity permits. `src/transforms/graph.c:171–198,570–674,1341–1408`. |
| 20 | Floating point | Make DEC64 reconstruction independent of the caller's rounding mode. Cache decimal probes for repeated bit patterns. `src/transforms/graph.c:415–416,952–959`, `src/arch/aarch64/dec64_neon.c:49`. |
| 21 | Public C API | Fixed target chunk allocation in #49. Separately, exclude whole-file video from multi-chunk target merges and define overflow handling for `kolmo_bound`. `src/api/features.c:49–118`, `src/api/api.c:3–6`. |
| 22 | Python | Removed extra compressed output copy in #52. Extended and archive members need a shared native member walker. `bindings/python/kolmo.py:76–91,130–138,261–264`. |
| 23 | Rust | Make compressor bound reservation and concatenate metadata growth fallible. `bindings/rust/src/lib.rs:119–193,232–252`. |
| 24 | CLI I/O | Propagated source feeder errors before publication in #54. Ensure no-replace operation remains atomic in every staging path. `src/cli/cli.c:152–175,754–770,958–971`. |
| 25 | Thread scheduling | Shared tokens bound active work while each block creates parked helpers. Reuse a helper team and make pool trim submission atomic. `src/algo/par.c:276–305`, `src/core/pool.c:79–86,121–126`. |
| 26 | Native file output | Cancel new work on write failure and preserve the first I/O error. Consider vectored STORE output. `src/core/blocks.c:108–169,650–655`. |
| 27 | Memory governor | Account for cgroup ancestors and retained per-thread scratch. Separate automatic scheduler memory from output-affecting settings. `src/core/memory.c:148–202`, `src/core/pool.c:15–31,109–123`. |
| 28 | ARM64 SIMD | Add exact NEON CM mixing. Apply true reference-mode gating to the decimal kernel and consider runtime CRC on portable builds. `src/arch/cpu.c:19–47`, `src/arch/decimal.c:9–11`, `src/arch/crc32c.c:4–23`. |
| 29 | x86 SIMD | Honor forced C and ISA caps in handwritten helper routes outside the central function table. Test actual dispatch. `src/arch/cpu.c:53–59`, `src/arch/cpu.h:7–34`. |
| 30 | GPU research | Current shipping build is CPU-only. Retest warm/cold adaptive routing, copies and equal CPU worker budgets. `Makefile:48–54`, `src/experimental/krc_cli.c:33–44`. |
| 31 | Release provenance | Tie all artifacts and registries to the exact tag and verified complete SHA manifest. Publish signed drafts atomically and forbid released asset replacement. `.github/workflows/release.yml:17–43,141–163`, `.github/workflows/wheels.yml:69–97`. |
| 32 | HDF5, Blosc2, Zarr | Enforce per-stage output budgets where possible and test h5py wheel ABI. Finalize integration IDs before distribution. `integration/numcodecs-kolmo/src/numcodecs_kolmo/zarr3.py:50–58`, `integration/hdf5/H5Zkolmo.c:44–87`. |
| 33 | Sanitizer and test coverage | Instrumented native archive in #53. Complete bounded file-decoder parity and direct CM/image coverage. `Makefile:146–176`, `fuzz/build.sh:14–47`. |
| 34 | Dataset and splits | Fail on missing expected downloads and exact split mismatches. Pin upstream source and derived bytes and reserve a new source-family acceptance set. `bench/repro/fetch.py:141–172`, `bench/repro/panel.py:79–95`, `benchmark/impact/mkcorpus.py:9–97`. |
| 35 | Format and reference | Reconcile the leaf registry, verify exact reference inverse hashes and codify compatibility across APIs. Learned state required by a decoder needs an explicit format ID. `FORMAT.md:244–285,319–324`, `COMPATIBILITY.md:60–81`. |
| 36 | Detection catalogue | GGUF header bounds in #51. Pass exact, bounded dtype hints from recognition into eligible routes before extending the catalogue. `src/plan/meta.c:388–526`, `src/plan/parallel.c:131–136`. |
| 37 | Specialist public claims | Match ZipNN timing boundaries, keep calculated DFloat11 data out of measured rankings and preserve the OpenZL losses. `bench/repro/panel.py:22–125`, `site/build.py:340–346,448–450`. |
| 38 | Target policy | Report unmet floors. Restrict pruning to validated cost bounds and recalibrate against native settings including trial time. `src/plan/target.c:27–31,186–189,319–354`. |
| 39 | Archive performance | Avoid quadratic DDP1 member listing and selection. Benchmark archive tree fidelity and solid versus incremental workloads. `src/cli/features.c:383–409`, `src/core/dedup.c:162–240`. |
| 40 | Benchmark runner | Bind resumed results to source, tools, inputs and run mode. Reuse trained files only with a matching successful receipt. `bench/repro/run.sh:34–64`, `bench/repro/panel.py:84–99`, `site/build.py:466`. |

## Next 60 reviewers and 12 scoped follow-ups

Each numbered reviewer owned one implementation or research question. Static findings are engineering hypotheses until the relevant patch or paired test is complete. The acceptance matrix applies to each candidate independently by producer, format, size, level, thread count and architecture.

| Review | Scope and proposed action | Status |
| --- | --- | --- |
| 01 | Admit frame limits before decoder metadata allocations. Charge offsets and sorting. Keep frame checks allocation-free. | #72 |
| 02 | Stage each archive member relative to the held parent FD, verify data and close before commit. | #59 |
| 03 | Bind each release artifact to source and signed provenance. Verify the draft download and uploaded PyPI artifacts. | #60 |
| 04 | Version the format catalogue. Use opt-in encoder learning with a seal, immutable receipts and stock v12 decoding. | #61 prototype |
| 05 | Run a bit-identical opt-in NEON CM4 dot/train kernel. | #63 |
| 06 | Try raw KLZMA at level 9 only after three paired probes inside validated tensor regions. Compare full stored bytes. | #62 opt-in |
| 07 | Record benchmark mode, source, tools and inputs. Refuse stale results and concurrent writes. | #64 |
| 08 | Charge owned stream output windows against codec scratch. Limit tight-cap concurrency and release excess retained capacity. | #72 |
| 09 | Initialize shared Kimg entropy tables before parallel access. | #68 |
| 10 | Bound CSV/TSV output assembly, remove intermediate copy and handle optional allocation failure. | #65 |
| 11 | Make DEC64 conversion deterministic under caller rounding modes. Preserve caller environment. | #66 |
| 12 | Resolve Linux cgroup mount/root and ancestry. Check leaf hard cap and shared parent headroom, preserving v1/v2 distinctions. | Open |
| 13 | Hash and verify trained benchmark artifacts, preserve untrained rows on training failure. | #64 |
| 14 | Honor NO_ASM throughout x86 SIMD/intrinsic dispatch. Verify scalar paths including decimal, graph, word and CRC. | Open |
| 15 | Review Rust wrapper fallible allocation and 32-bit narrowing. | Fixed by R18 |
| 16 | Check QLFC alphabet header writes and reduce serial staging. Verify exact entropy streams. | #81 |
| 17 | Add a versioned strict target-policy ABI and diagnostics. Evaluate arbitrary costs fully unless an audited bound permits pruning. | Open |
| 18 | Make Rust compression reservation fallible, avoid pre-zeroing and validate return lengths. | #67 |
| 19 | Evaluate exact repeated source identifier tokens via existing word dictionary entries. Charge dictionary/header costs. | Research |
| 20 | Reuse the stream parser's CZNS index and block span throughout window decoding. Avoid repeated index traversal. | #79 |
| 21 | Prototype one-time AVX2 dispatch and 32-position scan for x86 branch deltas. Preserve update order and exact frames. | Research |
| 22 | Route validated executable load ranges from sectionless ARM64 ELF to existing BL/ADRP transform. | Research |
| 23 | Separate large Wasm code, data and debug byte ranges under the existing v12 block model. Preserve exact LEB encodings. | Research |
| 24 | Align existing BF16 exponent rANS table resets to selected tensor boundaries. Include ZipNN on the exact same model-family splits. | Research |
| 25 | Add OpenZL 0.3.0 numeric Transformer level 7 and typed producer-disjoint inputs. Keep trained rows distinct. | Benchmark gap |
| 26 | Probe the committed typed layout on each sample against plain/stored, using matched offsets and headers. Measure selection regret. | Research |
| 27 | Trial validated KV-cache page layout, lane-preserving transforms and independent page blocks. Track first-page latency and read amplification. | Research |
| 28 | Skip the hash table for valid tiny KLZ inputs. Evaluate on-demand initialization separately at 14–512 bytes. | #74, ≤13 bytes |
| 29 | Benchmark exact-length fills for long distance-1 matches on run-heavy frames. Keep unrelated controls. | Research |
| 30 | Keep existing FASTQ quality representation and move job cuts to sampled quality-distribution changes at complete read boundaries. | Research |
| 31 | Charge video packed FD input before allocation. Release it before inverse. Account for per-frame inverse arrays by phase. | #83 |
| 32 | Check optional IMG16 detector allocations. Evaluate direct stores and a bounded predictor ring for decode. | Detector fixed in #69, inverse open |
| 33 | Track actual graph live capacity, including retained views and temporary decimal buffers. Enforce intermediate and root bounds. | Open |
| 34 | Bound Huffman short-tail refill to the real quarter stream. Reuse decoded bit-count invariants. | #71 |
| 35 | Switch short graph rANS inputs to a compact bucket map with fallback search. Benchmark before picking crossover. | Research |
| 36 | Reuse classified KLZH2 hashes and replace runtime modulus with exact reciprocal remainder. Check per-thread exactness. | Research |
| 37 | Wake only requested persistent helpers. Test after larger thread counts and concurrent/forked calls. | Research |
| 38 | Count KLZMA synthesized padding separately. Preserve the existing four-byte allowance. | #70 |
| 39 | Use one bounded IMG16 detector scratch buffer and cleanly decline after allocation failure. | #69 |
| 40 | Score bounded CSV grouping keys plus no-group on sampled residuals before formula discovery. Use existing group descriptor. | Research |
| 41 | Try grouping JSONL records by top-level layout, preserving nested values verbatim in existing text columns. | Research, #75 allocation fix |
| 42 | Keep one loaded archive member index and scan selected or listed members in order. Avoid reopen and quadratic traversal. | Open |
| 43 | Close staged regular-path output before publication, require exclusive creation, preserve intended alias/special destination semantics. | #84 |
| 44 | Add independent compressed-member limits and bounded input buffering with spill. Handle CZN1-first pipes in the streaming parser. | Open |
| 45 | Cancel pending parallel compression after output failure, wake waiters and release queued buffers. Preserve first error. | #82 |
| 46 | Make C compression bounds conservative and checked across small blocks, memory-limited and metadata-split routes. Propagate unrepresentable sizes. | Open |
| 47 | Implement and test KLZMA cursor change in native core and bindings. | #70 |
| 48 | Implement and test Huffman quarter-refill change in native core and bindings. | #71 |
| 49 | Rebase #37 candidate selection onto elastic KLZH2. Try one budgeted runner-up on validated strata. | Research |
| 50 | Use existing decimal layouts for header-confirmed rank-1 NumPy arrays, with bounded rows and exact special values. Test Arrow limbs separately. | Research |
| 51 | On archival text, sample alternate existing CM4 context masks for markup and prose. Keep only a fully measured smaller frame. | Research |
| 52 | Shed large repeated-unused TPQ/TLS buffers and measure idle RSS, page faults and tail latency after large-to-small calls. | Research |
| 53 | Limit concurrency under cgroup-local memory pressure, observing hard and soft headroom and preserving one-job progress. | Open |
| 54 | Bind production policy activation to independently approved receipts and active-policy ID. Make previous approved ID an atomic rollback target. | Prototype follow-up |
| 55 | Run installed-binary and installed-wheel v12 comparisons on every supported release architecture and oldest declared runtime. | Release follow-up |
| 56 | Start Windows support with a native UCRT x86-64 memory-only build and fresh installed DLL checks. | Portability research |
| 57 | Start browser support with single-threaded buffer-only wasm32 decode, explicit JS/Wasm memory limits and exact v12 across engines. | Portability research |
| 58 | Keep in-memory rivals and CLI measurements on distinct panels. Record paired CPU/wall and optional power counters. | Benchmark gap |
| 59 | Time first recovered byte and prefix latency with paced producers. Test explicit short first member then ordinary bulk. | Research |
| 60 | Add named allocation fault sites and worker-safe counters. Validate all decoder entry points on valid sealed fixtures at documented caps. | Test coverage gap |
| 61 | Implement regular output atomic publication safeguards after integration build freeze. | #84 |
| 62 | Implement tiny KLZ literal path with output and destination-capacity parity. | #74 |
| 63 | Check optional log/JSON encoder allocations and retain normal-route fallback. | Follow-up |
| 64 | Add opt-in AArch64 branch filtering for validated sectionless ELF and a three-probe screen. | #76 research |
| 65 | Verify integration compatibility and preserve declaration-free codec budget when considering optional sorting. | #79 |
| 66 | Reuse the validated member index across stream windows and charge it once. | #79 |
| 67 | Add archive publication, permission, alias, controlled write failure and cleanup tests. | #77 |
| 68 | Recognize bounded CSV/TSV, JSONL and FASTQ, with binary precedence and catalogue revision 2. | #78 |
| 69 | Encode exact ASCII source identifiers through the existing v12 dictionary with explicit opt-in. | #80 research |
| 70 | Stop new compression work promptly after an output failure and preserve the first error. | #82 |
| 71 | Check QLFC alphabet-header writes in both models. | #81 |
| 72 | Account for C_VID packed input and bounded per-frame inverse metadata by phase. | #83 |

Work gates and the timed scope are in [acceptance.md](acceptance.md). Cursor fixes #70 and #71 were independently verified with 357 frozen frames under ASan/UBSan after the benchmark build froze. Evaluate follow-up code together, on the integrated branch, before merge consideration.