# GR6 levels and precedence across Kolmo Ultra and level 9

## What the levels mean

These layer labels describe GR6 internals. Kolmo CLI presets 1, 2 and 3 are separate tuning choices.

| Historical GR6-L3 layer | Operation | Experiment controls |
| --- | --- | --- |
| L1 | Byte/letter spelling with a 62-entry alphabet, escaped bytes, prefix and character contexts | `LEVEL1=1` drops word and numeric selection. |
| L2 | Full-field repeat, graph and column ranks, dictionary references, numeric predictors and formulas | `FLAT=1` leaves a literal fallback but removes letter contexts. |
| L3 | Phrases from two previous field IDs (dictionary-free LZP) or a transmitted phrase dictionary | `lzp`, `all`, deterministic rules or external selection. L3-only still requires flat literals on misses. |

The stock precedence is a verified L3 match, then the L2 field model, then L1 spelling on misses. Reversing L1 and L2 unconditionally only invokes the always-available literal fallback. The tested alternative gives exact-row repeat and column ranks 0–1 first priority, followed by L3 and the ordinary L2/L1 choices. These gates change precedence inside one block’s field model.

Claude's GR6-L3 decision routine works in the standalone historical format. Its header flags, phrase references and optional Huffman stream differ from native codec 26. Kolmo v12 already decodes codec 26, whose existing use is the gated Ultra GR6+ L1+L2 model on line-structured tables. The impact harness can explicitly try stock-compatible codec 26 below Ultra without introducing a new payload format. A shipped decoder would need a new, reviewed representation for historical L3 and alternate entropy streams.

Source of historical implementation and distinctions is Claude commit `b23a5dc5d3ceb90b455d591dcb8fb8ffeee915da`, especially `research/FINDINGS.md` §§9–10, `research/gr6/gr6l3.c` and `research/gr6/bench_matrix.py`. Native baseline is Wave 2 `dcbf483184e77e465c02e33bd1aae674ca26b5bc`. See its `src/codecs/gr6.c`, `SPEC.md` codec 26, `benchmark/rc3/router/RESULTS.md` §4 and `benchmark/impact/RESULTS.md`.

## Evidence from Claude's earlier work

- The historical x86 Linux router matrix compared exact round trips on logs, prose, JSON and tables. L3 improved stand-alone GR6+ on logs, but results were 18.7%–100.1% larger than native Ultra on those datasets and its Ultra wins were 0.06% and 0.54% on two tables, both from the word-level changes. Against the ratio preset, L3 was 29.8%, 9.3% and 7.0% smaller on Apache, HDFS and Linux logs, but only 2–8 MB/s to decode against that preset's 20–130 MB/s.
- The later v12 impact matrix decodes native GR6+ at 3–11 MB/s on the cells where it saved size below Ultra, versus 100–620 MB/s for incumbent levels. It also reported 6–25× the decoder memory. This is evidence for retaining a gated Ultra lane and for evaluating a faster structured transform below it under independent decode gates.
- Claude's standalone dictionary selector added work and was near break-even with the LZP-only alternative even with oracle labels on the tested data. Do not infer a whole-corpus gain from the few model-selected wins.

## Local ablations

The local run uses pinned source bytes from the existing impact corpus, ending slices at a line boundary. All source and slice SHA-256 hashes are recorded in `corpus.json`. These are prior development/holdout sources in the repository benchmark sense. Their reuse here is a replay, and fresh sealed holdouts would be required to promote anything.

Standalone measurements include formula discovery in encode time. Combined CPU is encode CPU plus decode CPU. The standalone decoder compares full output bytes, and the Wave 2 CLI decoder compares input/recovered SHA-256. CLI measurements include process initialization and file I/O. GR6-L3 measures in one process with prepared input, and its reported size has a standalone header. Show timings at those boundaries and do not compare them as native production timings. Timing cells run one benchmark process at a time on the shared Apple Silicon host. RSS is per benchmark process on macOS. Formula and level routing changes are explicit opt-ins in the research patch.

The table shows exact sizes for all 120 single-thread 256 KiB-or-smaller cells. All round trips passed.

| Input | Native 9 | Ultra | L1 | L2 + flat | L3 + flat | L1+L2 | L1+L3 | L2+L3 + flat | L1+L2+L3 | L2 cheap first | L3 dictionary | Huffman L1+L2+L3 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Backblaze CSV | 20,414 | 19,057 | 30,521 | 21,528 | 60,894 | 19,977 | 29,004 | 21,522 | 19,971 | 19,905 | 32,848 | 42,347 |
| BGL log | 4,646 | 4,358 | 9,797 | 21,260 | 106,450 | 8,141 | 9,800 | 21,256 | 8,138 | 8,141 | 9,223 | 26,145 |
| Energy 130-column CSV | 25,460 | 24,868 | 52,224 | 31,496 | 78,290 | 30,465 | 48,276 | 31,259 | 30,229 | 30,236 | 41,636 | 50,197 |
| GH Archive JSONL | 37,048 | 27,956 | 50,258 | 95,824 | 145,258 | 43,979 | 47,888 | 95,684 | 43,815 | 43,830 | 48,266 | 107,299 |
| GHCN TSV | 15,691 | 11,508 | 25,342 | 15,593 | 87,451 | 13,359 | 25,566 | 15,287 | 13,050 | 13,000 | 24,681 | 28,487 |
| NASA log | 17,642 | 11,258 | 22,253 | 40,824 | 120,979 | 17,250 | 20,730 | 38,121 | 14,520 | 17,243 | 20,047 | 47,177 |
| OWID CO2 CSV | 23,088 | 22,056 | 50,198 | 23,482 | 84,069 | 22,965 | 50,238 | 23,514 | 22,997 | 22,992 | 39,114 | 43,282 |
| Reymont prose | 47,474 | 41,139 | 56,300 | 130,247 | 147,950 | 55,661 | 55,928 | 130,176 | 55,589 | 55,595 | 55,216 | 137,056 |

### Promotion decisions from the small replay

- Native gated L1+L2 remains the GR6 choice for Ultra and Ultra+. Every complete small standalone candidate was larger than native Ultra. Preserve L3 as research and reject broad adoption for both tiers. Adding it to codec 26 would introduce format cost and compatibility work without a confirmed Ultra gain.
- NASA shows that L3-first can matter for repeated long records. At 256 KiB it is 15.8% smaller than standalone L1+L2. Trying cheap L2 first loses almost all that reduction and retains the cost. GHCN prefers the opposite order by 50 bytes in the same matrix. Production acceptance requires comparison with the native format and decoder on each workload.
- Standalone L1 plus flat L3, L2 plus flat L3, unrestricted dictionary, and static Huffman final have no default promotion case here. The direct GR6 encoder always attempted formula discovery even on the historical letter-only ablation and Huffman final tests. Formula-free follow-ups make that prep cost visible separately.
- The sample race compares only L1, L1+L2, and all three with LZP. It cannot pick L1+L3 or L2-cheap-first even if they would win. Reuse its data for hypothesis discovery before making its extra whole-time cost part of a production preset.

Run `prepare.py` against a copy of the existing benchmark input tree. Build from the historical commit with `clang -O3 -mcpu=native -ffp-contract=off -I PATH_TO_ZSTD_LIB gr6l3.c PATH_TO_LIBZSTD_A` after applying the research-only `gr6l3-experiment.patch`. The replay used zstd 1.5.7 for the historical phrase dictionary and Huffman implementation. `replay.py` lists every available profile and emits JSONL with exact binary and input hashes, phase limits and thread counts. Use `summarize.py` on complete receipts for detailed encode, decode, CPU and RSS tables.

## Larger slices and independent blocks

All 120 rows on the roughly 2.5 MiB slices passed exact reconstruction. T1 uses one GR6-L3 block and T4 uses two independent line-aligned blocks by that prototype’s block-count rule. T4 does not imply four active block workers. Native level 9 kept its own normal block policy.

| Input | Threads | Level 9 bytes | Best GR6 profile | GR6 bytes | Size vs level 9 | Combined CPU, level 9 → GR6 |
| --- | ---: | ---: | --- | ---: | ---: | ---: |
| backblaze.large | 1 | 207,751 | L1+L2 | 201,797 | -2.87% | 0.258 → 15.549 s |
| backblaze.large | 4 | 207,751 | L1+L2 | 205,456 | -1.10% | 0.237 → 14.217 s |
| bgl.large | 1 | 57,914 | L1+L2+L3 | 90,705 | +56.62% | 0.175 → 0.843 s |
| bgl.large | 4 | 57,914 | L1+L2+L3 | 84,857 | +46.52% | 0.137 → 0.688 s |
| ghcn.large | 1 | 124,454 | L2-cheap-first | 106,888 | -14.11% | 0.504 → 0.820 s |
| ghcn.large | 4 | 124,454 | L2-cheap-first | 109,017 | -12.40% | 0.535 → 1.083 s |
| nasa.large | 1 | 131,048 | L1+L2+L3 | 101,965 | -22.19% | 0.346 → 1.235 s |
| nasa.large | 4 | 131,048 | L1+L2+L3 | 109,304 | -16.59% | 0.470 → 0.963 s |
| owid.large | 1 | 211,940 | L1+L2 | 199,960 | -5.65% | 0.379 → 3.008 s |
| owid.large | 4 | 211,940 | L1+L2 | 203,346 | -4.05% | 0.493 → 3.440 s |
| reymont.large | 1 | 398,978 | L1+L2+L3 | 524,581 | +31.48% | 0.181 → 2.560 s |
| reymont.large | 4 | 398,978 | L1+L2+L3 | 530,954 | +33.08% | 0.195 → 1.959 s |

NASA and GHCN replicated the relative size winners across cuts and threads. NASA’s LZP-first path is 19.4% smaller than standalone L1+L2 on the T1 large cut and 18.3% smaller on T4. Giving short L2 ranks priority discards most of that benefit. The GHCN cutoff instead favors the L2-cheap-first experimental ordering by 0.5% over LZP-first at both thread counts. Both still cost more CPU than native level 9.

OWID’s combined L1+L2 beats adding LZP at both thread counts. The wide Backblaze control retains around 1–3% size against level 9 while charging tens of times its combined CPU. BGL and Reymont were larger and slower than native level 9 across this larger panel. The tested GR6 sequences are therefore unsuitable as broad lower-tier presets.

## Formula preparation and final coder

All 32 added single-thread probes reconstructed exactly. Disabling formula discovery preserved L1 payload sizes on the five cases where the original prepared no formulas. On Energy, OWID and Backblaze, it shortened the L1 streams because formulas had been serialized even though letter-only L1 never invokes them.

On Backblaze, Energy and OWID, skipping formula prep cut the standalone LZP+Huffman combined CPU from roughly 2.37, 2.53 and 0.58 s to 0.016, 0.018 and 0.034 s respectively. The resulting outputs were 44,329, 58,311 and 53,498 bytes, still far above native level 3 at 24,186, 27,889 and 25,869 bytes. On each of the eight samples this formula-free Huffman route exceeded level 3 in bytes. Process load and different timing boundaries limit small speed comparisons. There is no fast-archiving promotion from this ablation.

## Stock v12 decoder boundary below Ultra

All 48 impact/stock baseline and trial frames passed on six 256 KiB-or-smaller inputs at levels 3 and 9 with one and four threads. The harness uses the existing codec-26 bitstream and retains an extra frame candidate only when smaller. Every result came back through the stock Wave 2 decoder with the original SHA-256. The same bytes were selected at both thread counts.

| Input | Level | Native bytes → gated GR6+ bytes | Stock decode CPU, T1 | Peak stock decode RSS, T1 |
| --- | ---: | ---: | ---: | ---: |
| GHCN TSV | 3 | 24,829 → 13,401 | 2.7 → 39.0 ms | 2.9 → 40.7 MiB |
| GHCN TSV | 9 | 15,691 → 13,401 | 3.1 → 38.3 ms | 2.8 → 40.6 MiB |
| NASA log | 3 | 27,442 → 17,306 | 2.3 → 38.0 ms | 2.8 → 40.4 MiB |
| NASA log | 9 | 17,642 → 17,306 | 5.7 → 35.2 ms | 6.4 → 40.4 MiB |
| OWID CO2 CSV | 3 | 25,869 → 22,606 | 2.9 → 57.7 ms | 3.2 → 41.6 MiB |
| OWID CO2 CSV | 9 | 23,088 → 22,606 | 3.7 → 52.3 ms | 3.1 → 41.6 MiB |

The wide Energy and Backblaze controls failed the codec gate and stayed byte-identical. BGL was tried and declined. This confirms Claude's v12 conclusion that the existing format can support a smaller opt-in output below Ultra, while the proven decode CPU and RSS regressions rule it out of default faster presets. The T4 values and lane logs are in `native.jsonl`. Use `native_replay.py` with a Wave 2-derived `make kolmo-impact` binary and the pinned stock `kolmo`.

## Acceptance for another GR6 design

Keep existing GR6+ L1+L2 as an Ultra+ candidate for validated tables. Leave pattern-mined dictionaries, alternative phrase precedence and additional trial search out of defaults. For a new high-speed structured lane, start from one bounded record scanner, stream separation using existing v12 transforms and native entropy coders. Compare that result with each current preset at identical bytes, threads, memory caps and format boundaries. Use sealed independent representatives of both wide and narrow tables, repetitive and varied logs, small and full-file inputs, and producer/platform CPU groups. The full penalty must include formula discovery, model reset and dictionary data. Preserve raw results for eliminated variants.

## Larger Ultra controls

All four additional controls at roughly 2.5 MiB passed exactly. Native Ultra stayed smaller than every GR6-L3 variant on NASA and GHCN at both thread counts. This confirms the small-panel decision for those two inputs.

| Input | Threads | Native Ultra bytes | Best GR6 bytes | Difference | Ultra CPU | Best GR6 CPU |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| nasa.large | 1 | 76,059 | 101,965 | +34.1% | 5.531 s | 1.235 s |
| nasa.large | 4 | 76,059 | 109,304 | +43.7% | 5.365 s | 0.963 s |
| ghcn.large | 1 | 93,050 | 106,888 | +14.9% | 5.418 s | 0.820 s |
| ghcn.large | 4 | 93,050 | 109,017 | +17.2% | 5.327 s | 1.083 s |

Replays across all five receipts recovered the exact input in 324 of 324 trials.
