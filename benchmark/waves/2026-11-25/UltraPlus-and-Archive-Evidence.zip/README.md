# Kolmo Ultra+ and high-speed archiving handoff

25 November 2026. The implementation baseline is Wave 2 at dcbf4831. The original 40 reviewers and the subsequent 60+12 reviewers are summarized individually in [reviewers.md](reviewers.md). Eleven additional scoped agents ran this round across Ultra modelling, Lexi, GR6, archive creation/indexing, assembly, competitor tests, streaming and security. Review sources and measured behavior separately before changing a preset.

## What passed and what was dropped

| Candidate | Result and disposition |
| --- | --- |
| Single-open DDP1 traversal, #87 | 1,024 × 4 KiB listing 47.26 → 3.55 ms. Selecting first and last at T1/T4/auto moved from 45.7–52.3 ms to 3.5–4.3 ms. Early small and 32-member apparent regressions failed the 25-pair retest and warm in-process controls. |
| Large single-member store, #89 | Level 1 and at least 32 MiB, duplicate-free, one member, disjoint source/destination. 1.04–1.31× wall throughput and 18–71 MiB less peak RSS across all admitted cases. Earlier smaller/level-3 mixed results are retained. |
| Verified archive integration, #90 | Combines #87 and #89, passed 357 frozen v12 frames and CLI features. Separately tested normal and ASan archive suites. |
| Paired Gear scan, #86 | Identical cut positions and encoded bytes. 1.28–1.30× faster kernel, 1.05–1.08× faster creation in 16 MiB duplicate-heavy T1/T4 on both sources. Gate for native Linux/x86 and naturally versioned inputs. |
| Ultra+ native research prototype, #88 | CLI and native encoder experiment emits ordinary v12. The first alternate CM4 mask did not shrink any of 12 tested settings and added CPU. Exclude this mask from release and retain the complete experiment. |
| Rolling CM4 hash | Exact frames and stock decoding. The original slowdown failed reproduction. Positive and negative timing cells remain, so drop it from the eligible path. |
| Lexi and priors | A new v12 research stream model or prior changed the decoder. Historical median size gain was 0.91% for Lexi and 1.64% combined. Known size reversals reproduced. A byte-exact lexer hot-path rewrite also failed across sizes, inputs and threads. Preserve both records. |
| GR6+ | 324 exact runs. Keep gated native L1+L2 for validated structured tables in Ultra-class modes. In standalone research, L3-first helped NASA and L2-cheap-first helped GHCN, while native Ultra was still smaller. Native codec 26 below Ultra repeatedly regressed speed and RSS. |
| XML leaf separation, page ordering and fixed sparse match | Byte-exact structural round trips, no stable size gain. Fixed sparse match measured only predictive coverage and reversed across producers. Drop these algorithms from the proposed product changes and keep the evidence. |
| Initial smaller CZNS segment | 504 exact native trials. First byte improved. The 15-pair 8 MiB T4 retest reproduced complete-MiB/total time regressions and small output growth. Drop the default candidate. The released 0.0.2 CLI's stdin buffering also erased its first-byte benefit. |

[Promotion policy](promotion.md) · [Claude verification](claude-verification.md) · [Security plan](security.md)

## Next experiments in priority order

1. **Archive creation.** Introduce parallel per-file or per-range CDC and checksums with a bounded ordered merge for deterministic chunk IDs. Preserve DDP1 frames and compare natural snapshots, duplicate-heavy directories, unique tiny files and mixed large inputs. Then evaluate concurrent source I/O and codec work and a file-backed unique store. Measure solid-stream, directory, named extraction and cold first-byte paths separately.
2. **Ultra+ probability modelling.** Make actual CM4 per-bit loss and time attributable by byte class. Screen a confidence-gated sparse second-match expert and bounded XML record-path context in source order. If they earn enough held-out bits per byte, test a small fixed-point recurrent predictor on the remaining hard spans. Compare portable scalar, NEON and AVX2 probability traces. Any model that changes decoded probabilities needs an explicit research model version and a separate compatibility design.
3. **Ratio and time.** Prior Kolmo Ultra wrote 18,651,472 bytes on full enwik8. Matching the published cmix v21 result requires 21.59% fewer bytes and matching published PAQ8PX v206fix1 needs 15.02% fewer. Same-host comparisons should use current PAQ8PX and cmix builds with options, budgets and dictionaries pinned. One local PAQ8PX v217 -8L check is a constrained prefix comparison, not a full-corpus result.
4. **Semantics and memory.** Keep format compatibility, memory admission, actual peak RSS, output metadata and stage lifetimes explicit. Fix the incomplete forced-scalar reference dispatch before publishing cross-ISA assembly conclusions. Use the codec admission budget and an actual worker/OS limit independently.
5. **Security.** Start with a maintained authenticated outer envelope, worker isolation, and verified release artifacts. Consider indexed authenticated chunks only when needed to preserve seekability. Use an attested confidential VM when the deployment threat includes the cloud host.

Local comparisons ran on the 10-core Apple M5 with parallel research and shared-host timing qualification. GitHub Actions accepted the draft CI jobs. There was no attached Codex Cloud execution environment, and neither a large-memory hosted cmix run nor native Linux/x86 timing was completed here.

## Evidence packs

Each pack contains text reports, replay harnesses, patches where applicable, and raw results. Initial exploratory results and verified repetitions remain available. A paper reference, a size-only oracle, and a simulated or rejected run are labelled as such.

- Ultra+ matrix, same-binary regression recheck, PAQ8PX prefix control, structurally rejected candidates and model experiments.
- GR6 levels, precedence, native v12 and Huffman/formula ablations.
- Lexi historical trail and fresh CPU/size reversals.
- Archive index reuse and direct-store qualification, with old and final timings.
- Gear kernel and full archive CDC scope with A/A controls.
- Competing archive implementations and bounded stream first-byte trials.
- Prior ARM64 assembly details and direct/current CLI replay where available.

Human-readable results are in [Ultra+ mask replay](ultra-plus-results.md), [ARM64 CLI NEON](neon.md), [GR6 decision matrix](gr6.md), [fast archive comparisons](fast-archives.md), and [assembly and Gear CDC](assembly.md).
