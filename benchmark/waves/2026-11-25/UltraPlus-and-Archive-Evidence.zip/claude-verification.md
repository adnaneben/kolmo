# Claude Code claims checked against source and receipts

| Claim | Verified source | Disposition |
| --- | --- | --- |
| Native GR6+ reduced some structured CSV sizes and increased encode time on some wide-table losses. | Commit 708dd6ed, rc3 GR6 results and checked-in rows. Commit 732024f8 already gates by field count and sample agreement. Commit f005eeef already adds parallel formula search with bounded fallback. | Keep the existing gated native L1+L2 route. Study L3 separately. |
| Lexi is the token-class model in the research branch. | Port 680b0914 and PR #48. The lexical hash uses six of eight stored history classes. The grep feature is a separate search operation. | Current replay confirmed earlier size exceptions and stock-v12 refusal of research-only context and prior IDs. Keep the experiments for reproduction. |
| Assembly benefits were specific to kernels and ISA. | Claude's rc3 and x86/ARM reports. Handwritten ARM histogram and scalar parity were freshly checked. AVX2/SSE mixer paths remain useful on their measured scope. | Preserve #63 NEON research. Current scalar flag names still leave compile-time intrinsic paths in parts of the tree. |
| An unmerged KLZH2 schedule saves some bytes with expensive retries. | Prior Wave 1/2 evidence and PR #37. Level 7 shrank 0.183% in aggregate at about 2.1 times encode CPU. | Drop broad promotion. A narrow candidate needs a fresh prespecified benchmark. |
| Release preparation passed 64 CM reference streams. | PR #47 comment reports this check on its rebased branch. | Keep release preparation separate from these changes. |

Consulted Claude-authored commits, project notes and GitHub discussions for #37, #47, #48, #57, #58, #62, #63, #73, #76, #79, #80 and #85. A separate Claude chat or Space containing additional comments was unavailable.
