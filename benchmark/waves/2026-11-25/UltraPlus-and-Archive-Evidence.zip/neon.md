# ARM64 NEON mixer on the pinned Wave 2 CLI

Tested ARM64 on the user's Apple M5 using one exact binary for both dispatches. Comparison is explicit scalar `KOLMO_CPU=c` versus the opt-in `KOLMO_CPU=neon`. The archive format, presets, planner and decoder are held fixed. The NEON candidate is the CM4 dot and training kernel in [#63](https://github.com/adnaneben/kolmo/pull/63). A scalar dispatch label covers this runtime mixer switch only. Other compiler-emitted or compile-time SIMD is common to both arms.

- Wave 2 CLI SHA-256 is `b5c968708777f3bce882ceeddea7107dde46bbde86d9959cefe31acaa280f9f3`.
- Released stock v0.0.2 CLI SHA-256 is `e7f58f11fe2eb5f296bcd71a9ef9331d154723709ca6822e3cb110acd376e328`.
- Sources are prefixes from the frozen independent corpus files for JPEG XL C++ source, Reymont prose and GHArchive JSONL. Prefix lengths and input/frame digests appear in every raw row.
- Each run compressed with Ultra into exactly four physical untransformed CM4 blocks and decoded in a separate process. Requested threads were one or four. Four blocks make all four workers eligible. Read the separate CPU and wall measurements for effective work. Randomized and interleaved paired commands timed wall and process CPU using wait4 on the shared host. Warm-ups were excluded from metrics. Every result recovered the exact original SHA-256, and every warm-up was also decoded by the released stock CLI. Both dispatches and both thread settings produced the same frame hash.
- Overall this includes 190 timed pairs, 31 scalar/scalar pairs among them, plus 36 warm-up arms. Full client results show 9.55%–13.63% less paired median combined CPU, with 6.28%–13.80% less combined wall time in the primary 64/256 KiB matrix. Transfer runs at 1 MiB also improve.
- Small C++ T1 decode median RSS remained 27.23 MiB. A transient maximum increased 4.56 MiB in the first replay and 5.23 MiB in its 15-pair replication. It did not occur at T4. In 31 scalar/scalar pairs the decode RSS maxima differed by 5.23 MiB. Another 31 scalar/NEON pairs reversed direction by 7.69 MiB. Per-process RSS tails varied comparably without the candidate, and no stable RSS increase was isolated. Repeat on a controlled host before relying on a tight RSS cap.
- Keep the exact NEON kernel candidate for the measured Apple M5 CM4 scope. Continue to gate an ARM64-wide default on larger natural block sizes, other ARM processors, and the controlled memory check.

## Primary matrix

| Input | KiB | Workers | CM4 blocks | Frame bytes | Pairs | E CPU Δ | D CPU Δ | E+D CPU Δ | E+D wall Δ | Paired E+D CPU range | E/D RSS max delta |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| code__jxl-cc | 64 | 1 | 4/4 | 14,344 | 7 | -9.57% | -7.21% | -9.55% | -9.33% | -19.01% to -3.85% | +3.08/+4.56 MiB |
| code__jxl-cc | 64 | 4 | 4/4 | 14,344 | 7 | -11.61% | -8.42% | -10.13% | -8.87% | -32.20% to -5.87% | -0.44/+0.00 MiB |
| code__jxl-cc | 256 | 1 | 4/4 | 43,606 | 7 | -13.06% | -11.05% | -11.34% | -11.27% | -14.00% to -8.23% | +0.00/+0.70 MiB |
| code__jxl-cc | 256 | 4 | 4/4 | 43,606 | 7 | -12.32% | -8.23% | -11.21% | -12.62% | -20.61% to +0.39% | -0.39/+0.00 MiB |
| json__gharchive | 64 | 1 | 4/4 | 11,512 | 7 | -12.54% | -13.14% | -12.43% | -12.18% | -22.70% to -1.59% | +0.08/+0.00 MiB |
| json__gharchive | 64 | 4 | 4/4 | 11,512 | 7 | -9.39% | -13.93% | -13.03% | -9.74% | -17.16% to -9.13% | -0.12/+0.02 MiB |
| json__gharchive | 256 | 1 | 4/4 | 34,073 | 7 | -13.73% | -12.13% | -11.47% | -11.37% | -19.39% to -8.47% | +0.02/+0.00 MiB |
| json__gharchive | 256 | 4 | 4/4 | 34,073 | 7 | -6.96% | -13.96% | -12.44% | -6.46% | -20.77% to +14.87% | +0.62/+0.00 MiB |
| text__reymont | 64 | 1 | 4/4 | 14,442 | 7 | -10.80% | -12.20% | -13.02% | -12.92% | -16.89% to -10.13% | +0.00/+0.00 MiB |
| text__reymont | 64 | 4 | 4/4 | 14,442 | 7 | -11.94% | -11.28% | -11.00% | -6.28% | -14.64% to -1.23% | +0.31/-0.02 MiB |
| text__reymont | 256 | 1 | 4/4 | 48,262 | 7 | -13.78% | -12.89% | -13.58% | -13.23% | -27.16% to +19.18% | -0.55/+0.00 MiB |
| text__reymont | 256 | 4 | 4/4 | 48,262 | 7 | -12.48% | -15.51% | -13.63% | -13.80% | -18.20% to -5.55% | -0.16/+0.00 MiB |

84 completed timed pairs, 24 warm-ups cross-checked with stock v0.0.2, 12 cases checked. Negative Δ means less time.
The binary was identical across the two arms. All timed commands were on the shared host.

## Larger T4 transfer

| Input | KiB | Workers | CM4 blocks | Frame bytes | Pairs | E CPU Δ | D CPU Δ | E+D CPU Δ | E+D wall Δ | Paired E+D CPU range | E/D RSS max delta |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| json__gharchive | 1024 | 4 | 4/4 | 94,383 | 7 | -11.44% | -12.52% | -11.54% | -11.31% | -15.18% to -3.17% | -0.33/+0.00 MiB |
| text__reymont | 1024 | 4 | 4/4 | 166,683 | 7 | -17.92% | -18.51% | -17.25% | -16.31% | -28.98% to -8.44% | +2.88/+0.00 MiB |

14 completed timed pairs, 4 warm-ups cross-checked with stock v0.0.2, 2 cases checked. Negative Δ means less time.
The binary was identical across the two arms. All timed commands were on the shared host.

## 15-pair targeted size and thread retest

| Input | KiB | Workers | CM4 blocks | Frame bytes | Pairs | E CPU Δ | D CPU Δ | E+D CPU Δ | E+D wall Δ | Paired E+D CPU range | E/D RSS max delta |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| code__jxl-cc | 64 | 1 | 4/4 | 14,344 | 15 | -10.04% | -10.38% | -10.48% | -10.23% | -14.81% to +17.05% | -0.09/+5.23 MiB |
| code__jxl-cc | 64 | 4 | 4/4 | 14,344 | 15 | -9.15% | -6.07% | -8.42% | -5.26% | -15.13% to +8.28% | +0.09/+0.00 MiB |

30 completed timed pairs, 4 warm-ups cross-checked with stock v0.0.2, 2 cases checked. Negative Δ means less time.
The binary was identical across the two arms. All timed commands were on the shared host.

## 31-pair scalar/scalar memory control

| Input | KiB | Workers | CM4 blocks | Frame bytes | Pairs | E CPU Δ | D CPU Δ | E+D CPU Δ | E+D wall Δ | Paired E+D CPU range | E/D RSS max delta |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| code__jxl-cc | 64 | 1 | 4/4 | 14,344 | 31 | -0.11% | -0.38% | -0.50% | -0.20% | -19.84% to +9.22% | -4.89/-5.23 MiB |

31 completed timed pairs, 2 warm-ups cross-checked with stock v0.0.2, 1 cases checked. Negative Δ means less time.
The binary was identical across the two arms. All timed commands were on the shared host.

## 31-pair scalar/NEON memory replay

| Input | KiB | Workers | CM4 blocks | Frame bytes | Pairs | E CPU Δ | D CPU Δ | E+D CPU Δ | E+D wall Δ | Paired E+D CPU range | E/D RSS max delta |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| code__jxl-cc | 64 | 1 | 4/4 | 14,344 | 31 | -8.24% | -10.12% | -8.72% | -8.51% | -22.02% to +6.64% | +2.44/-7.69 MiB |

31 completed timed pairs, 2 warm-ups cross-checked with stock v0.0.2, 1 cases checked. Negative Δ means less time.
The binary was identical across the two arms. All timed commands were on the shared host.

## Replay

From the evidence directory, replace both binary variables and the corpus path with the corresponding checked snapshots.

```sh
python3 replay.py --cli "$WAVE2" --stock "$STOCK" -- "$CORPUS/code__jxl-cc" "$CORPUS/text__reymont" "$CORPUS/json__gharchive" > receipt.jsonl
python3 replay.py --cli "$WAVE2" --stock "$STOCK" --repeats 15 --sizes 65536 --threads 1 4 -- "$CORPUS/code__jxl-cc" > retest-rss.jsonl
python3 replay.py --cli "$WAVE2" --stock "$STOCK" --repeats 31 --a-a --sizes 65536 --threads 1 -- "$CORPUS/code__jxl-cc" > aa-rss.jsonl
python3 replay.py --cli "$WAVE2" --stock "$STOCK" --repeats 31 --sizes 65536 --threads 1 -- "$CORPUS/code__jxl-cc" > ab-rss.jsonl
python3 replay.py --cli "$WAVE2" --stock "$STOCK" --repeats 7 --sizes 1048576 --threads 4 -- "$CORPUS/text__reymont" "$CORPUS/json__gharchive" > large.jsonl
python3 summarize.py receipt.jsonl
```
