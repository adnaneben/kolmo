# Ultra+ first CM4 mask disposition

Archive research source is PR #88. All 128 CLI arms recovered the same bytes and every Ultra+ output decoded on stock v0.0.2. The levels test and 357 frozen v12 frames passed. Separate direct aliases, stream and archive smoke tests passed. Native compression is unchanged in scope when the optional mask trial declines.

The initial balanced comparison used the Wave 2 baseline and prototype; the targeted retest used the prototype binary on both arms. The screens ran on a shared M5, paired and randomized. CPU and wall include process I/O. All tested size/worker settings used the same frame bytes. The alternate mask is rejected from release; the evidence and source remain available.

## Initial simultaneous size and worker matrix

| Input | Bytes | Threads | Blocks | Stored bytes | Paired combined CPU change | Paired combined wall change |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| log__bgl | 1,114,112 | 1 | 1 | 21,718 | +0.65% | +1.11% |
| log__bgl | 1,114,112 | 4 | 1 | 21,718 | +2.71% | +7.63% |
| log__bgl | 3,407,872 | 1 | 2 | 65,542 | -0.78% | -0.68% |
| log__bgl | 3,407,872 | 4 | 2 | 65,542 | +0.66% | +0.77% |
| text__reymont | 1,114,112 | 1 | 1 | 157,935 | +18.23% | +50.58% |
| text__reymont | 1,114,112 | 4 | 1 | 157,935 | +14.60% | +14.93% |
| text__reymont | 3,407,872 | 1 | 2 | 470,208 | +4.15% | +4.73% |
| text__reymont | 3,407,872 | 4 | 2 | 470,208 | +4.50% | +3.93% |
| xml__enwik8 | 1,114,112 | 1 | 1 | 242,650 | +3.40% | +0.38% |
| xml__enwik8 | 1,114,112 | 4 | 1 | 242,650 | -4.04% | -1.76% |
| xml__enwik8 | 3,407,872 | 1 | 2 | 754,747 | +2.67% | +3.57% |
| xml__enwik8 | 3,407,872 | 4 | 2 | 754,747 | +7.27% | +7.23% |

## Seven-pair same-binary size and worker retest

| Input | Bytes | Threads | Blocks | Stored bytes | Paired combined CPU change | Paired combined wall change |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| text__reymont | 524,288 | 1 | 1 | 79,341 | -4.34% | -4.38% |
| text__reymont | 524,288 | 4 | 1 | 79,341 | -1.74% | -1.79% |
| text__reymont | 1,114,112 | 1 | 1 | 157,935 | +2.46% | +7.83% |
| text__reymont | 1,114,112 | 4 | 1 | 157,935 | +0.52% | +0.56% |

