# Promotion and regression replay

Adopt a candidate after it improves the named workload consistently, with ordinary v12 decoding wherever claimed. Keep candidate and baseline commits, rejected patch, raw receipts, input digests, exact commands and the reason for disposition.

1. Register the intended workload and boundaries before viewing the holdout. Record stored size, encode wall and CPU, decode wall and CPU, combined time and peak RSS. For archives, also record p95 first verified byte or member and create/extract latency.
2. Pair on the same bytes and hardware. Randomize order. Verify SHA-256 or complete archive trees, including named access and empty files. Count physical blocks and effective threads. Use at least seven pairs per promoted context and A/A controls on startup-sized cases.
3. Cross two independent source groups, small and large sizes, and one and at least four threads. Include automatic thread selection and tight-memory routes when affected. Use a second hardware class before a broad fast-path default. Keep cache state explicit and measure RSS separately from codec admission.
4. Rerun each suspected regression in its original and adjacent size, thread and source contexts. Keep wall and CPU separate and record paired intervals where sample size permits. For p95 first-byte claims, use at least 30 independent pairs with warm and cold passes.
5. Drop a candidate when a genuine regression is confirmed in its proposed scope. A narrower candidate needs a fresh scope and holdout. Keep rejected implementations and measurements. Aggregate gains cannot qualify a change that regresses an eligible cell.
6. Keep accepted source in its own draft. Connect branch, evidence, stock-reader compatibility, CI and portability gates. Recheck when upstream changes the baseline.

Report solid-stream throughput, true directory archiving, named-member retrieval and bounded-stream latency separately. For Ultra+, report the fastest tested point at equal size and the smallest at equal time. Include dictionaries, model state and side information. The previous [workload targets](https://github.com/adnaneben/kolmo/blob/8485feecc5ab0890e8d68fa2e47bb461d6fa93f4/benchmark/waves/2026-11-25/acceptance.md) set separate metric thresholds.
